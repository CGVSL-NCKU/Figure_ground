#include "stdafx.h"
#include "JC_type.h"
#include "CV_Rigid.h"
#include "JC_functions.h"
#include <fstream>
#ifndef _JC_TRANSFORMATION_H_
#define _JC_TRANSFORMATION_H_
fstream ofile;


namespace Transformation{

	
	
	void printMatrix(cv::Mat _matrix){
		std::cout << _matrix.at<double>(0, 0) <<" "<< _matrix.at<double>(0, 1)<<" " << _matrix.at<double>(0, 2)<< std::endl;
		std::cout << _matrix.at<double>(1, 0) <<" "<< _matrix.at<double>(1, 1)<<" " << _matrix.at<double>(1, 2)<< std::endl;
	}

	bool getRigidTransform(std::vector<cv::Point> &_target, std::vector<cv::Point> &_source ,TransformedType &tempData)
	{
		

		int _error_flag=0;		
		int _theta_test = 0;
		cv::Mat _transform_matrix;
		double _scale_factor = 0;
		float _drift_x, _drift_y; 

		_transform_matrix = Rigid::estimateRigidTransform(_target, _source, false); 

// 		ofile << "1  " << _transform_matrix.at<double>(0, 0) << std::endl;
// 		ofile  << "2  "<<_transform_matrix.at<double>(0, 1)  << std::endl;
// 		ofile << "3  " <<_transform_matrix.at<double>(1, 0) << std::endl;
// 		ofile << "4  " <<_transform_matrix.at<double>(1, 1) << std::endl;
// 		ofile  << "5  "<<_transform_matrix.at<double>(0, 2)<< std::endl;
// 		ofile  << "6  "<<_transform_matrix.at<double>(1, 2)<< std::endl;

		_scale_factor = sqrt( pow(_transform_matrix.at<double>(1, 0), 2) + pow( _transform_matrix.at<double>(0, 0), 2) );

		if( abs(_transform_matrix.at<double>(1, 0))!= abs(_transform_matrix.at<double>(0, 1))  
			|| abs(_transform_matrix.at<double>(0, 0))!= abs(_transform_matrix.at<double>(1, 1)) ) _theta_test = 1;

		//std::cout <<_scale_factor << std::endl; 
		if( _scale_factor <= 0 || _theta_test!=0 ){
			_error_flag = 1;
			//std::cout << "error" << std::endl; 
		}else{
			_transform_matrix.at<double>(0, 0) /= _scale_factor;
			_transform_matrix.at<double>(0, 1) /= _scale_factor;
			_transform_matrix.at<double>(1, 0) /= _scale_factor;
			_transform_matrix.at<double>(1, 1) /= _scale_factor;
			_transform_matrix.at<double>(0, 2) /= _scale_factor;
			_transform_matrix.at<double>(1, 2) /= _scale_factor;

		}
		_transform_matrix.convertTo(_transform_matrix,CV_32FC1,1,0); 

		float tempx = 0,tempy = 0;
		for(int i = 0 ; i < _target.size() ; i++){
			cv::Mat _result;
			float vers[] = { _target[i].x, _target[i].y, 1 }; 
			cv::Mat ver = cv::Mat(3,1, CV_32FC1, vers );
			_result = _transform_matrix * ver ;
			tempx += _source[i].x-_result.at<float>(0,0);
			tempy += _source[i].y-_result.at<float>(1,0);
		}
		_drift_x = tempx / _target.size();
		_drift_y = tempy / _target.size();
// 		_drift_x = 0;
// 		_drift_y = 0;

		double _cos, _sin, _theta;
		_cos = _transform_matrix.at<float>(0, 0);
		_sin = _transform_matrix.at<float>(1, 0);
		_theta = acos(_cos)*(180/(3.14159)); 

		if( (_sin < 0) && (_cos < 0) ){
			_theta = 360 - _theta;
		}else if( (_sin < 0) && (_cos >= 0) ){
			_theta = 360 - _theta;
		}

		if(_theta <=360 && _theta >0){

		}else{
			_theta = 0;
		}


		if(_error_flag == 0){

			TransformedType _tempInfo;
			_tempInfo.transformed_matrix = _transform_matrix;

			_tempInfo.translate_x = (int)_drift_x + (int)_transform_matrix.at<float>(0,2);
			_tempInfo.translate_y = (int)_drift_y + (int)_transform_matrix.at<float>(1,2);
			_tempInfo.add_x = _drift_x;
			_tempInfo.add_y = _drift_y;
			_tempInfo.theta = (float)_theta;
			_tempInfo.cos_theta = (float)_cos;

			tempData = _tempInfo;
			return true;
		}

		return false;
		
	}
	void rigidTransform(MatchType &matchPairData, std::vector<MatchType> &transform_data){
		
		std::vector<cv::Point> _target = matchPairData.match_IS_target;
		std::vector<cv::Point> _source = matchPairData.match_IS_source;

		/* test: calculate the center of the target contour */
		cv::Point centerT;
		for(int i =0; i < matchPairData.target.contour.size(); i ++){
			centerT.x += matchPairData.target.contour[i].x;
			centerT.y += matchPairData.target.contour[i].y;
		}
		centerT.x /=  matchPairData.target.contour.size();
		centerT.y /=  matchPairData.target.contour.size();

		//std::cout << centerT.x << ","<< centerT.y << std::endl;


// 		TransformedType _test_match;
// 		std::vector<cv::Point> _target_test;
// 		_target_test.resize(matchPairData.match_IS_target.size());
// 		for(int i =0; i < _target_test.size(); i++){
// 			_target_test[i].x = matchPairData.match_IS_target[i].x-centerT.x;
// 			_target_test[i].y =matchPairData.match_IS_target[i].y-centerT.y;
//   			//std::cout << _target_test[i].x << ","<< _target_test[i].y << std::endl;
// 		}
// 		bool test_getrigid = getRigidTransform(_target_test, _source, _test_match); 

		/* test */


		TransformedType _rigidData_match;
		TransformedType _rigidData;
		bool getrigid = getRigidTransform(_target, _source, _rigidData_match); 

		//std::cout << test_getrigid<<" " << getrigid <<std::endl;

		if(getrigid){


			matchPairData.target.contour_t = JC::transformContour(
				_rigidData_match.transformed_matrix,
				matchPairData.target.contour,
				_rigidData_match.add_x,
				_rigidData_match.add_y
				);

			bool getrigid_global = getRigidTransform(matchPairData.target.contour, matchPairData.target.contour_t, _rigidData);

			if(getrigid_global){
// 				if(test_getrigid){
// 					std::cout << " test matrix " << std::endl;
// 					printMatrix(_test_match.transformed_matrix);
// 					std::cout << "translate "<<_test_match.translate_x<<","<<_test_match.translate_y << std::endl;
// 
// 					std::vector<cv::Point> TContour;
// 
// 					
// 						cv::Mat results;
// 						float vers[] = { _target_test[1].x , _target_test[1].y, 1 }; 
// 						cv::Mat ver = cv::Mat( 3, 1, CV_32FC1, vers );
// 						results = _test_match.transformed_matrix * ver;
// 						std::cout << "new "<<results.at<float>(0,0) + _test_match.add_x<<","<<results.at<float>(1,0) + _test_match.add_y << std::endl;
// 					
// 
// 					std::cout << " global matrix " << std::endl;
// 					printMatrix(_rigidData.transformed_matrix);
// 					std::cout << "translate "<<_rigidData.translate_x<<","<<_rigidData.translate_y << std::endl;
// 
// 					cv::Mat results2;
// 					float vers2[] = { _target[1].x , _target[1].y, 1 }; 
// 					cv::Mat ver2 = cv::Mat( 3, 1, CV_32FC1, vers2 );
// 					results2 = _rigidData.transformed_matrix * ver2;
// 					std::cout << "new "<<results2.at<float>(0,0) + _rigidData.add_x<<","<<results2.at<float>(1,0) + _rigidData.add_y << std::endl;
// 				}
// 				std::cout << " local matrix " << std::endl;
// 				printMatrix(_rigidData_match.transformed_matrix);
// 				std::cout << " global matrix " << std::endl;
// 				printMatrix(_rigidData.transformed_matrix);

				matchPairData.transformData = _rigidData;

				matchPairData.transformed_interested_IS_target = JC::transformContour(
					_rigidData.transformed_matrix,
					matchPairData.interested_IS_target,
					_rigidData.add_x,
					_rigidData.add_y
					);

				matchPairData.transformed_match_IS_target = JC::transformContour(
					_rigidData.transformed_matrix,
					matchPairData.match_IS_target,
					_rigidData.add_x,
					_rigidData.add_y
					);

				matchPairData.transformed_match_target = JC::transformContour(
					_rigidData.transformed_matrix,
					matchPairData.match_target,
					_rigidData.add_x,
					_rigidData.add_y
					);

				matchPairData.target.contour_t = JC::transformContour(
					_rigidData.transformed_matrix,
					matchPairData.target.contour,
					_rigidData.add_x,
					_rigidData.add_y
					);

				/* remaining source points */
				for( int k = 0 ; k < matchPairData.source.contour.size() - ( matchPairData.match_IS_index_source.size()-1)*7 ; k++ )
				{
					int index_src =  matchPairData.match_IS_index_source[0]*7 -k;
					index_src = (index_src + matchPairData.source.contour.size()) % matchPairData.source.contour.size();

					matchPairData.remaining_source.push_back(matchPairData.source.contour[index_src]);
					matchPairData.FG_contour.push_back(matchPairData.source.contour[index_src]);
				}

				/* whole FG_contour : add the transformed_match_target */
				std::vector<cv::Point>  _reverse_match_target;
				_reverse_match_target = matchPairData.transformed_match_target;
				reverse(_reverse_match_target.begin(), _reverse_match_target.end());
				for( int k = 0; k < _reverse_match_target.size(); k++ )
				{
					matchPairData.FG_contour.push_back(_reverse_match_target[k]);
				}


//     				if (matchPairData.match_source.size()<40)
//    				{
					transform_data.push_back(matchPairData);
				//}
				

				

			} /* end getrigid_global */
		
		} /* getrigid */

	} /* end function */


	void find_transformation(std::vector<MatchType> &matchData, std::vector<MatchType> &transform_data)
	{
		ofile.open("1.txt", ios::out);

		std::vector<MatchType> _transform_data;

		std::cout << matchData.size() << std::endl;

		std::ostringstream oss;

		for( int i = 0; i < matchData.size() ; i++ ){
			ofile << i << "---------------------------------" << std::endl;
			ofile << matchData[i].match_IS_source.size()  << std::endl;
			ofile << matchData[i].match_IS_target.size()  << std::endl;
			rigidTransform( matchData[i], _transform_data);

		}
		std::cout << "T "<< matchData.size() << std::endl;
		ofile << "T sizeb"<<_transform_data.size() << std::endl;
		ofile.close();
		transform_data = _transform_data;

		int maxLength = 0;
		

// 		for( int i = 0; i < transform_data.size() ; i++ ){
// 
// 			if(transform_data[i].match_source.size()>60) {
// 			
// 				cv::Mat canvas(1000, 1000, CV_8UC3);
// 				canvas.setTo(255);
// 			 
// 				JC::drawContour(canvas, transform_data[i].source.contour, cv::Scalar(0,0,0) , 1, 2);
// 				JC::drawContour(canvas, transform_data[i].match_IS_source, cv::Scalar(0,0,255) , 6, 3);	 
// 				ostringstream oss;
// 				oss << i ;
// 				imwrite("../cost/"+ oss.str()+"1.png", canvas);
// 
// 				canvas.setTo(255);
// 				JC::drawLineContour(canvas, transform_data[i].target.contour, cv::Scalar(0,0,0) ,  2);
// 				//JC::drawContour(canvas, transform_data[i].match_IS_target, cv::Scalar(0,0,255) , 6, 3);	 
// 
// 				imwrite("../cost/"+ oss.str()+"2.png", canvas);
// 
// 				canvas.setTo(255);
// 				JC::shiftPoint(transform_data[i].target.contour_t, cv::Point(-350,-350));
// 				JC::shiftPoint(transform_data[i].source.contour, cv::Point(-350,-350));
// 				JC::shiftPoint(transform_data[i].match_source, cv::Point(-350,-350));
// 				JC::shiftPoint(transform_data[i].match_target, cv::Point(-350,-350));
// 				JC::drawLineContour(canvas, transform_data[i].target.contour_t, cv::Scalar(255,0,0), 4);
// 				JC::drawLineContour(canvas, transform_data[i].source.contour, cv::Scalar(0,0,0) , 4);
// 				JC::drawLineContourN(canvas, transform_data[i].match_source, cv::Scalar(255,0,255) , 4);
// 				JC::drawLineContour_idx(canvas, transform_data[i].target.contour_t,transform_data[i].match_index_target, cv::Scalar(255,255,0) , 4);
// 
// 				imwrite("../cost/"+ oss.str()+"3.png", canvas);
// 
// 				JC::drawMatch(canvas, transform_data[i].source.contour, transform_data[i].target.contour_t,
// 					transform_data[i].match_index_source, transform_data[i].match_index_target,cv::Scalar(0,0,255) , 1);
// 
// 				imwrite("../cost/"+ oss.str()+"4.png", canvas);
// 
// 				fstream file;
// 				file.open("../cost/"+ oss.str()+".txt", ios::out);
// 
// 				file << transform_data[i].transformData.translate_x << std::endl;
// 				file << transform_data[i].transformData.translate_y << std::endl;
// 				file << transform_data[i].transformData.theta << std::endl;
// 
// 			}
// 
// 		}

//		std::cout << "max Len " << maxLength << std::endl;
	}
}

#endif
