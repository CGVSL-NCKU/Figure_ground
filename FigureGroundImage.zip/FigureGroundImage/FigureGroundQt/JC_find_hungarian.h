#include "stdafx.h"
#include <fstream>
#include "JC_type.h"
#include "JC_functions.h"
#include "JC_List.h"
#include "JC_LIS.h"
#include "JC_find_transformation.h"
#include "HungarianLib.h"
#include "JC_svgParser.h"
//#include "JC_GaussianDistribution.h"
#ifndef _JC_FIND_HUNGARIAN_H_
#define _JC_FIND_HUNGARIAN_H_



namespace Hungarian{

	float weight_length;
	float weight_orientation;
	float weight_deformation;
	float weight_convexity;	 

	static bool compareLongestf( std::pair<float,int> x, std::pair<float,int> y ) { return x.first > y.first; }

	const int Max = 999999;

	void drawClusterResults(std::vector<std::vector<MatchType> > &cluster_results, int size){

		std::ostringstream oss, oss2, oss_file;
		for(int i = 0 ; i < cluster_results.size() ; i++){

			int r = 255 * (rand()/(1.0 + RAND_MAX));
			int g = 255 * (rand()/(1.0 + RAND_MAX));
			int b = 255 * (rand()/(1.0 + RAND_MAX));
			if(cluster_results[i].size() < 3) continue;

			for(int j = 0 ; j < cluster_results[i].size(); j++){

				vector<cv::Point> twoContour;
				twoContour = cluster_results[i][j].source.contour;
				for(int k =0; k < cluster_results[i][j].target.contour_t.size(); k++){
					twoContour.push_back(cluster_results[i][j].target.contour_t[k]);
				}

				cv::Rect boundRect;
				boundRect = boundingRect( cv::Mat(twoContour) );
				cv::Point shiftP = boundRect.tl() - cv::Point(5,5); 
				JC::shiftPoint(cluster_results[i][j].target.contour_t, shiftP);
				JC::shiftPoint(cluster_results[i][j].match_source, shiftP);
				JC::shiftPoint(cluster_results[i][j].FG_contour, shiftP);
				JC::shiftPoint(cluster_results[i][j].transformed_match_target, shiftP);

				int rWidth = boundRect.br().x - boundRect.tl().x;
				int rHeight =boundRect.br().y - boundRect.tl().y;

				cv::Mat canvas(rHeight+5, rWidth+5 , CV_8UC3, cv::Scalar(255,255,255));
				oss.str("");
				oss<<size<<"_"<<i<<"_"<<j<<"_";

				oss2.str("");
				oss2<<i;

				int draw_radius = 1, draw_thickness = 2;
				/* draw whole target points */
				JC::drawLineContour( canvas, cluster_results[i][j].target.contour_t, cv::Scalar(0, 0, 0), draw_thickness );

				/* draw whole source points */
				//JC::drawContour( canvas, kmean_results[i][j].source.contour, cv::Scalar(255, 255, 255), draw_radius, draw_thickness );

				/* draw match source */
				JC::drawContour( canvas, cluster_results[i][j].match_source, cv::Scalar(255, 0, 255), draw_radius, draw_thickness );

				/* draw IS match source */
				//JC::drawContour( canvas, cluster_results[i][j].match_IS_source, cv::Scalar(255, 255, 0), draw_radius*3, draw_thickness );

				/* draw IS match target */
				//JC::drawContour( canvas, cluster_results[i][j].transformed_match_IS_target, cv::Scalar(255, 0, 255), draw_radius*3, draw_thickness );

				/* draw remaining source */
				JC::drawLineContourN( canvas, cluster_results[i][j].remaining_source, cv::Scalar(0, 0, 0), draw_thickness );

				/*draw line whole FG contour */
				//JC::drawLineContour( canvas, cluster_results[i][j].FG_contour, cv::Scalar(0, 0, 0), draw_thickness );

				/* draw match target */
				//JC::drawContour( canvas, cluster_results[i][j].transformed_match_target, cv::Scalar(0, 0, 0), draw_radius, draw_thickness );


				// 				cv::putText(canvas, oss2.str(), cv::Point(10, 75), cv::FONT_HERSHEY_DUPLEX, 3, cv::Scalar(r, g, b), 3);
				// 				
				// 				oss2.str("");
				// 				/*oss2 << kmean_results[i][j].transformData.theta <<" " << kmean_results[i][j].transformData.cos_theta;*/
				// 				oss2 << cluster_results[i][j].transformData.theta ;
				// 				cv::putText(canvas, oss2.str(), cv::Point(10, 150), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 255, 0), 1);
				// 
				// 				oss2.str("");
				// 				oss2 << cluster_results[i][j].transformData.translate_x ;
				// 				cv::putText(canvas, oss2.str(), cv::Point(10, 180), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 255, 0), 1);
				// 
				// 				oss2.str("");
				// 				oss2 << cluster_results[i][j].transformData.translate_y;
				// 				cv::putText(canvas, oss2.str(), cv::Point(10, 210), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 255, 0), 1);

				// 				oss2.str("");
				// 				oss2 <<"src " <<kmean_results[i][j].match_index_source[0] << " - "<< kmean_results[i][j].match_index_source[kmean_results[i][j].match_index_source.size()-1] ;
				// 				cv::putText(canvas, oss2.str(), cv::Point(10, 240), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 255, 0), 1);
				// 				
				// 				oss2.str("");
				// 				oss2 <<"tar " <<kmean_results[i][j].match_index_target[0] << " - "<< kmean_results[i][j].match_index_target[kmean_results[i][j].match_index_target.size()-1] ;
				// 				cv::putText(canvas, oss2.str(), cv::Point(10, 270), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 255, 0), 1);

				std::string filePath = "../kmeans/size"+oss.str()+".png";
				cv::imwrite(filePath, canvas );




			}
		}
	}

	int** vector_to_matrix(std::vector<std::vector<double> > &cost, int rows, int cols) {
		int i,j;
		int** r;
		r = (int**)calloc(rows,sizeof(int*));
		for(i=0;i<rows;i++)
		{
			r[i] = (int*)calloc(cols,sizeof(int));
			for(j=0;j<cols;j++)
				r[i][j] = (int)cost[i][j];
		}
		return r;
	}

	void unionListAverageMatirx( std::vector<MatchType> &clusterPair ,HungarianType &hData){

		/* average Matrix */
		float m[6]={0};
		cv::Mat M(2, 3, CV_32FC1, m);
		hData.averageMatrix = M;
		hData.addx = 0;
		hData.addy = 0;

		/* add list */
		for (int j = 0; j < clusterPair.size(); j++ )
		{
			hData.averageMatrix += clusterPair[j].transformData.transformed_matrix;
			hData.addx += clusterPair[j].transformData.add_x;
			hData.addy += clusterPair[j].transformData.add_y;
			std::vector<int>  reverse_index_target =  clusterPair[j].match_index_target;
			std::reverse(reverse_index_target.begin(), reverse_index_target.end());

			JC_List::addList(clusterPair[j].match_index_source, hData.list_src, clusterPair[j].source.contour);
			JC_List::addList(reverse_index_target, hData.list_tar, clusterPair[j].target.contour);

		}

		/* average matrix */
		hData.averageMatrix /= clusterPair.size();
		hData.addx /= clusterPair.size();
		hData.addy /= clusterPair.size();

		/* assign original source and target_t contour */
		std::vector<cv::Point> contour_t;
		contour_t = JC::transformContour(
			hData.averageMatrix,
			clusterPair[0].target.contour,
			hData.addx,
			hData.addy
			);
		
		std::vector< std::vector<cv::Point> > inner_contours_tar;

		for(int j=0; j< clusterPair[0].target.inner_contours.size(); j++){
			std::vector<cv::Point> contour_2nd_t;
			contour_2nd_t = JC::transformContour(
				hData.averageMatrix,
				clusterPair[0].target.inner_contours[j],
				hData.addx,
				hData.addy
				);
			inner_contours_tar.push_back(contour_2nd_t);
		}

		
		hData.source = clusterPair[0].source.contour;
		hData.inner_contours_src = clusterPair[0].source.inner_contours;
		hData.target = contour_t;
		hData.inner_contours_tar = inner_contours_tar;
		hData.oriTarget = clusterPair[0].target.contour;
		hData.feature_index_src = clusterPair[0].source.feature_index_contour;
		hData.feature_index_tar = clusterPair[0].target.feature_index_contour;
		hData.interested_IS_index_target = clusterPair[0].interested_IS_index_target;

	}

	void initialHungCost(std::vector<MatchType> &clusterPair, HungarianType &hData){

		/* initial cost */
		hData.cost.resize(hData.list_src.size());
		hData.countNum.resize(hData.list_src.size());
		for (int j = 0; j < hData.cost.size(); j++)
		{
			hData.cost[j].resize(hData.list_tar.size(), Max);
			hData.countNum[j].resize(hData.list_tar.size(), 0);
		}

		hData.twoContour = hData.target;
		for(int j = 0; j < hData.source.size(); j++){
			hData.twoContour.push_back(hData.source[j]); 
		}

		hData.curveSource = clusterPair[0].source.curve_contour;
		hData.curveTarget = clusterPair[0].target.curve_contour;
		hData.IS_idx_src = clusterPair[0].IS_idx_src;
		hData.IS_idx_tar = clusterPair[0].IS_idx_tar;

		std::vector<std::vector<int> > _countNum = hData.countNum;
		std::vector<std::vector<double> > _cost = hData.cost;

		std::vector<double>  _cos2t;
		/* calculate cost */
		for (int j = 0; j < clusterPair.size(); j++ )
		{
			for(int k = 0 ; k < clusterPair[j].match_index_source.size(); k++)
			{
				double diff_x = clusterPair[j].source.contour[clusterPair[j].match_index_source[k]].x - hData.target[clusterPair[j].match_index_target[k]].x ;
				double diff_y = clusterPair[j].source.contour[clusterPair[j].match_index_source[k]].y - hData.target[clusterPair[j].match_index_target[k]].y ;
				double tempDist = sqrt( pow(diff_x,2) + pow(diff_y,2) );	

				int costIndexSrc = (clusterPair[j].match_index_source[k] - hData.list_src[0] + clusterPair[0].source.contour.size()) % clusterPair[0].source.contour.size();
				int costIndexTar = (clusterPair[j].match_index_target[k] - hData.list_tar[0] + clusterPair[0].target.contour.size()) % clusterPair[0].target.contour.size();

				_countNum[costIndexSrc][costIndexTar]++;
				int cn = _countNum[costIndexSrc][costIndexTar];

				//Equation 7 : minimize


				_cost[costIndexSrc][costIndexTar] = tempDist - (double)cn * 5 - (clusterPair[j].IS_cost/15000)*5;
				//std::cout << _cost[costIndexSrc][costIndexTar] << std::endl;

				if(costIndexTar>_countNum[costIndexSrc].size()) {				
					std::cout <<"find_hungarian::initialHungarianCost::costIndexTar>_countNum[costIndexSrc].size()"<< std::endl;
				}

			}
		}

		hData.countNum = _countNum;
		hData.cost = _cost;

	}

	void hungarianCall(HungarianType &hData, std::vector<int> &intputLis, std::vector<int> &outputLis){

		/* hungarian lib */
		int** hungM = vector_to_matrix(hData.cost, hData.cost.size(),hData.cost[0].size());
		hungarian_problem_t p;

		/* initialize the hungarian_problem using the cost matrix*/
		int matrix_size = hungarian_init(&p, hungM , hData.cost.size(), hData.cost[0].size(), HUNGARIAN_MODE_MINIMIZE_COST) ;

		//fprintf(stderr, "assignment matrix has a now a size %d rows and %d columns.\n\n",  matrix_size, matrix_size);

		/* solve the assignment problem */
		hungarian_solve(&p);

		hData.srcToTar.resize(hData.source.size());
		hData.tarToSrc.resize(hData.target.size());
		/* results of hungarian */
		for(int j = 0; j < p.num_rows ; j++){
			for(int k = 0; k < p.num_cols ; k ++){
				if( (j < hData.cost.size()) && (k < hData.cost[0].size()) && (p.assignment[j][k]==1) &&  (hungM[j][k]!= Max) ){
					int srcIndex = hData.list_src[j];
					int tarIndex = hData.list_tar[k];

					hData.srcToTar[srcIndex] = tarIndex;
					hData.tarToSrc[tarIndex] = srcIndex;
					intputLis.push_back(k);
				}
			}	
		}

		std::reverse(intputLis.begin(), intputLis.end());
		JC_LIS::find_lis(intputLis, outputLis);

		/* free used memory */
		hungarian_free(&p);
		free(hungM);
	}

	void newCorrespondence(HungarianType &hData, std::vector<int> &intputLis, std::vector<int> &outputLis, std::vector<std::pair<float, int > > &rank, int i, std::vector<std::pair<float, HungarianType > > &candidate, int size,std::vector<int> &user_defined_index){
		/*for bezier*/
		// 		std::vector<cv::Point> src;
		// 		std::vector<cv::Point> tar;

		std::vector<int> srcIndexs;
		std::vector<int> tarIndexs;

		int lastSrc = -1;
		int lastTar = -1;
		for (int j =0; j < outputLis.size(); j++)
		{
			int tarIndex = hData.list_tar[intputLis[outputLis[j]]]; /* increase */
			int srcIndex = hData.tarToSrc[tarIndex]; /* decrease */
			srcIndexs.push_back(srcIndex);
			tarIndexs.push_back(tarIndex);
			// cv::line(canvas_lis, HungarianData[i].source[srcIndex], 
			// HungarianData[i].target[tarIndex], cv::Scalar(0,0,255) );
			// src.push_back(HungarianData[i].source[srcIndex]);
			// tar.push_back(contour_t[tarIndex]);
		}

		int notFind = 0;
		int lastT = -1;
		std::vector<int> srcIndexsToTar;
		std::vector<int> srcIndexs2;

		for(int j = srcIndexs[srcIndexs.size()-1]; j!=srcIndexs[0]; j = (j+1)% hData.source.size()){
			std::vector<int>::iterator it;
			it = find(srcIndexs.begin(), srcIndexs.end(), j);
			srcIndexs2.push_back(j);
			if(it==srcIndexs.end()){
				notFind++;
				srcIndexsToTar.push_back(lastT);
			}else{
				srcIndexsToTar.push_back(hData.srcToTar[j]);
				lastT = hData.srcToTar[j];
			}
		}

		/* remove end points (the max between start or end) */
		int newStartIndex= 0;
		int newEndIndex = srcIndexs2.size()-1;
		for(int j=0; j< notFind; j++){
			int tempS = newStartIndex;
			int tempE = newEndIndex;
			int idxTarS = srcIndexsToTar[tempS];
			int idxTarE = srcIndexsToTar[tempE];

			double diffS_x = hData.source[srcIndexs2[tempS]].x - hData.target[idxTarS].x ;
			double diffS_y = hData.source[srcIndexs2[tempS]].y - hData.target[idxTarS].y ;
			double tempDistS = sqrt( pow(diffS_x,2) + pow(diffS_y,2) );	

			double diffE_x = hData.source[srcIndexs2[tempE]].x - hData.target[idxTarE].x ;
			double diffE_y = hData.source[srcIndexs2[tempE]].y - hData.target[idxTarE].y ;
			double tempDistE = sqrt( pow(diffE_x,2) + pow(diffE_y,2) );	

			if(tempDistS > tempDistE){
				newStartIndex ++;
			}else{
				newEndIndex--;
			}
		}

		int indexTarS = (srcIndexsToTar[newEndIndex] + (newEndIndex - newStartIndex +1))% hData.target.size() ;
		std::vector<int> newSrcIndex;
		std::vector<int> newTarIndex;

		std::vector<cv::Point> newSrcPoint;
		std::vector<cv::Point> newTarPoint;
		for(int j = newStartIndex; j <= newEndIndex; j++){

			int T = (indexTarS - (j-newStartIndex) + hData.target.size()-1) % hData.target.size();
			newSrcIndex.push_back(srcIndexs2[j]);
			newTarIndex.push_back(T);

			newSrcPoint.push_back(hData.source[srcIndexs2[j]]);
			newTarPoint.push_back(hData.oriTarget[T]);
		}

		TransformedType rigidData;
		bool tSuccess;

		/* transformation */
		tSuccess = Transformation::getRigidTransform(newTarPoint, newSrcPoint, rigidData);

		if(tSuccess){
			std::vector<cv::Point> contour_t_new;
			contour_t_new = JC::transformContour(
				rigidData.transformed_matrix,
				hData.oriTarget,
				rigidData.add_x,
				rigidData.add_y
				);
			hData.target = contour_t_new;
			hData.averageMatrix = rigidData.transformed_matrix;
			hData.addx = rigidData.add_x;
			hData.addy = rigidData.add_y;

		}


		// calculate new cost //
		int newLength = 0;
		double newCost = 0;
		double curveS = 0;
		double curveT = 0;
		double curveMSum = 0;
		double curveSum = 0;
		double curveAbsS = 0;
		double curveAbsT = 0;
		hData.featureNumSrc = 0;
		hData.featureNumTar = 0;
		for(int j = 0; j < hData.source.size(); j++){
			std::vector<int>::iterator it;
			it = find(newSrcIndex.begin(), newSrcIndex.end(), j);
			if(it!=newSrcIndex.end()){
				int indexNewSrc = std::distance(newSrcIndex.begin(), it);
				int idxTar = newTarIndex[indexNewSrc];
				hData.compositeContour.push_back(hData.target[idxTar]);
				hData.match_src.push_back(hData.source[j]);
				hData.match_tar.push_back(hData.target[idxTar]);
				hData.match_index_src.push_back(j);
				hData.match_index_tar.push_back(idxTar);

				/* add the cost */
				double diffS_x = hData.source[j].x - hData.target[idxTar].x ;
				double diffS_y = hData.source[j].y - hData.target[idxTar].y ;
				double tempDistS = sqrt( pow(diffS_x,2) + pow(diffS_y,2) );	

				curveS += hData.curveSource[j];
				curveT += hData.curveTarget[idxTar];
				curveMSum =  hData.curveSource[j]* hData.curveTarget[idxTar];
				curveAbsS += abs(hData.curveSource[j]);
				curveAbsT += abs(hData.curveTarget[idxTar]);

				newCost += tempDistS;
				newLength++;


				std::vector<int>::iterator itFS;
				itFS = find(hData.feature_index_src.begin(), hData.feature_index_src.end(), j);
				if(itFS!=hData.feature_index_src.end()){
					hData.featureNumSrc++;
					hData.match_src_feature.push_back(hData.source[j]);
				}


				std::vector<int>::iterator itFT;
				itFT = find(hData.feature_index_tar.begin(), hData.feature_index_tar.end(), idxTar);
				if(itFT!=hData.feature_index_tar.end()){
					hData.featureNumTar++;
					hData.match_tar_feature.push_back(hData.target[idxTar]);
				}


			}else{
				hData.compositeContour.push_back( hData.source[j]);
				hData.remainingSource.push_back(hData.source[j]);
			}


		}

		hData.curveSourceCost = curveS;
		hData.curveTargetCost = curveT;
		hData.curveMSum = curveMSum;
		hData.curveSum = curveSum; 
		hData.curveAbsSrc = curveAbsS;
		hData.curveAbsTar = curveAbsT;
		hData.curveAbsSum = curveAbsS + curveAbsT;
		// 		std::cout << "curvature" << std::endl;
		// 		std::cout << curveS<< std::endl;
		// 		std::cout << curveT<< std::endl;
		// 		std::cout << curveMSum<< std::endl;
		// 		std::cout << curveSum<< std::endl;
		// 		std::cout << curveAbsS<< std::endl;
		// 		std::cout << curveAbsT<< std::endl;
		// 		std::cout << hData.curveAbsSum<< std::endl;


		// new two contour //
		hData.outContour = hData.remainingSource;
		hData.twoContour = hData.compositeContour;
		for(int j = 0; j < hData.target.size(); j++){
			std::vector<int>::iterator it;
			it = find(newTarIndex.begin(), newTarIndex.end(), j);
			if(it==newTarIndex.end()){
				hData.remainingTarget_t.push_back(hData.target[j]);
				hData.twoContour.push_back(hData.target[j]);
				hData.outContour.push_back(hData.target[j]);
				//cv::circle(canvas_replace, contour_t[j], 2, cv::Scalar(0, 255, 255), 8 );
			}
		}

		//shift points

		// 		cv::Point shiftP = boundRect.tl() - cv::Point(0,0); 
		// 		JC::shiftPoint(hData.source, shiftP);
		// 		JC::shiftPoint(hData.remainingSource, shiftP);
		// 		JC::shiftPoint(hData.target, shiftP);
		// 		JC::shiftPoint(hData.match_src, shiftP);
		// 		JC::shiftPoint(hData.match_tar, shiftP);
		// 		JC::shiftPoint(hData.compositeContour, shiftP);
		// 		JC::shiftPoint(hData.remainingTarget_t, shiftP);
		// 		JC::shiftPoint(hData.twoContour, shiftP);
		// 		JC::shiftPoint(hData.outContour, shiftP);
		// 		JC::shiftPoint(hData.match_src_feature, shiftP);
		// 		JC::shiftPoint(hData.match_tar_feature, shiftP);
		// 		hData.boundRect_shift = boundRect; 
		//  		boundRect = boundingRect( cv::Mat(hData.twoContour) );
		// 		hData.boundRect = boundRect;

		//find ist match length

		hData.interested_length = 0;
		for(int i =0; i < user_defined_index.size(); i++){
			std::vector<int>::iterator it;
			it = find(hData.match_index_tar.begin(), hData.match_index_tar.end(),  user_defined_index[i]);
			if (it != hData.match_index_tar.end() )
			{
				hData.interested_length++;
				hData.interested_target.push_back(hData.target[user_defined_index[i]]);
			}
		}

		/* orientation term */
		hData.averageMatrix.convertTo(hData.averageMatrix,CV_32FC1,1,0); 
		double _cos, _sin, _theta;
		_cos = hData.averageMatrix.at<float>(0, 0);
		_sin = hData.averageMatrix.at<float>(1, 0);
		_theta = acos(_cos)*(180/(3.14159)); 
		newCost = newCost/newLength;
		hData.distCost = newCost;
		hData.lengthCost = (double) newLength / (double)hData.source.size();
		hData.tarlengthCost = (double) newLength / (double)hData.target.size();
		hData.orientationCost = _cos;
		hData.size = size;
		hData.curveAbsAve = hData.curveAbsSum /  (double)newLength;

		hData.curveRatio = (double)( hData.featureNumTar)/ (double)newLength;
		float cost = (float)newCost*weight_deformation + (float)_cos*-weight_orientation +(float) hData.lengthCost*-weight_length -  hData.curveRatio*5*weight_convexity/*+ (float)hData.tarlengthCost*-70*/;

		//std::cout << newCost << " " << _cos <<"  theta" << _theta <<  " " << hData.lengthCost << " " <<  hData.curveRatio << std::endl;
		hData.totalCost = (double)cost;

		std::vector<cv::Point> outContour;
		outContour = hData.source;
		for(int i =0; i < hData.target.size(); i++){
			outContour.push_back(hData.target[i]);
		}

		cv::Rect boundRect;
		boundRect = boundingRect( cv::Mat(outContour) );

		int rWidth = boundRect.br().x - boundRect.tl().x;
		int rHeight = boundRect.br().y - boundRect.tl().y;
		cv::Mat boundImg(rHeight+15,  rWidth+15, CV_8UC3);	
		boundImg.setTo(0);
		cv::Point shiftP = boundRect.tl() - cv::Point(5,5); 
		JC::shiftPoint(hData.source, shiftP);
		JC::shiftPoint(hData.target, shiftP);
		/*draw whole source */
		JC::drawContour( boundImg, hData.source, cv::Scalar(255, 255, 0), 1 ,2);

		/* draw whole target */
		JC::drawContour( boundImg, hData.target, cv::Scalar(255, 0, 0), 1, 2 );

		/* draw match source */
		JC::drawContour_idx( boundImg, hData.source, hData.match_index_src, cv::Scalar(0, 0, 255), 1, 2 );

		/* draw match target */
		JC::drawContour_idx( boundImg, hData.target, hData.match_index_tar, cv::Scalar(0, 255, 0), 1, 2 );

		//  [5/1/2015 jollytrees]

		cv::Scalar color_red(0,0,255);
		cv::Scalar color_green(0,255,0);
		cv::Scalar color_blue(255,0,0);

		cv::Scalar color_yellow(0,255,255);
		cv::Scalar color_lightBlue(255,255,0);
		cv::Scalar color_purple(255,0,255);

		cv::Scalar color_white(255,255,255);
		cv::Scalar color_black(0,0,0);

		ostringstream oss;
		oss << i << hData.target.size();
		boundImg.setTo( cv::Scalar(255, 255, 255));

// 		JC::drawContour( boundImg, hData.source, color_black, 1 ,2);
// 		JC::drawContour( boundImg, hData.target, color_blue, 1, 2 );
// 		JC::drawContour_idx( boundImg, hData.source, hData.feature_index_src, color_red, 5, 2 );
// 		JC::drawContour_idx( boundImg, hData.target, hData.feature_index_tar, color_red, 5, 2 );

		/*draw whole source */
		JC::drawContour( boundImg, hData.source, color_black, 1 ,2);

		/* draw whole target */
		JC::drawContour( boundImg, hData.target, color_blue, 1, 2 );

		/* draw match source */
		JC::drawContour_idx( boundImg, hData.source,  hData.match_index_src, color_purple, 1, 2 );

		/* draw match target */
		JC::drawContour_idx( boundImg, hData.target,  hData.match_index_tar, color_lightBlue, 1, 2 );


		imwrite("../cost/"+oss.str()+"match_.png", boundImg);

		hData.rankMat = boundImg.clone();

		JC::shiftPoint(hData.source, -shiftP);
		JC::shiftPoint(hData.target, -shiftP);
		candidate.push_back(std::make_pair(cost,hData));
		rank.push_back(std::make_pair(cost,i));

	}

	void findHungarian(FG_Type *_FG, int size, std::vector<int> &user_defined_index){

		clusterType &_cluster_results =  _FG->kmeans_data; 
		std::vector<std::pair<float, int > > &rank = _FG->rank;
		std::vector<HungarianType> &HungarianData = _FG->HungarianData;
		std::vector<std::pair<float, HungarianType > > &candidate = _FG->candidate;
		std::vector<std::vector<MatchType> > cluster_results = _cluster_results.clusters;

		weight_length = _FG->w_length; 
		weight_orientation = _FG->w_orientation; 
		weight_deformation = _FG->w_deformation;
		weight_convexity = _FG->w_convexity;


		//drawClusterResults(_cluster_results.clusters, size);

		HungarianData.resize(cluster_results.size());

		/* find cost & rank */
		for( int i = 0; i < cluster_results.size(); i++ ){

			if(cluster_results[i].size() < 3)
				continue;

			unionListAverageMatirx(cluster_results[i], HungarianData[i]);

			initialHungCost(cluster_results[i], HungarianData[i]);

			std::vector<int> intputLis;
			std::vector<int> outputLis;
			hungarianCall(HungarianData[i], intputLis, outputLis);			
			newCorrespondence(HungarianData[i], intputLis, outputLis, rank, i, candidate, size, user_defined_index);


		}/* end clustering_results[i] */


	}


}

#endif