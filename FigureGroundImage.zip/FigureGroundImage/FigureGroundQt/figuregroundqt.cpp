﻿#include "stdafx.h"
#include "figuregroundqt.h"
#include "JC_FG_main_procedure.h"
#include "JC_functions.h"
#include "JC_crop.h"
#include "JC_window_edit.h"
#include "JC_find_contour.h"
#include "JC_watched.h"
#include "JC_IS_Match.h"
#include "JC_find_transformation.h"
#include "JC_find_cluster.h"
#include "JC_find_hungarian.h"
#include "JC_svgParser.h"
#include "JC_find_warping.h"
#include "JC_user_cropping.h"
#include "JC_powell.h"
#include <iostream>
#include <fstream>
#include <time.h>
#include <QThread>
#include <string>
#include <QInputDialog>
#include <QFormLayout>
#include <QDialogButtonBox>
#include <QListWidget>
#include <QRadioButton>
#include <QDir>
#include <QFileDialog>
static bool compareShortestf( std::pair<float,HungarianType> x, std::pair<float,HungarianType> y ) { return x.first < y.first; }

FigureGroundQt::FigureGroundQt(QWidget *parent) : QMainWindow(parent)
{
	
	w_length = 60;
	w_orientation = 15;
	w_deformation = 1;
	w_convexity = 20;

	clickCount = 0;
	processDone = 0;
	warp_type = 2;

	lockDrop_src = 0;
	lockDrop_tar = 0;

	size_src = 1;
	size_tar = 1;

	ui.setupUi(this);
	this->setAcceptDrops(true);

	ui.label->installEventFilter(this);
	ui.label->setAcceptDrops(true);

	ui.label_2->installEventFilter(this);
	ui.label_2->setAcceptDrops(true);

	ui.label_3->installEventFilter(this);
	ui.label_4->installEventFilter(this);
	ui.label_5->installEventFilter(this);
	ui.label_6->installEventFilter(this);
	ui.label_7->installEventFilter(this);

	ui.label_8->installEventFilter(this);


	ui.tabWidget->setTabIcon(0, QIcon("../icons/input.png"));
	ui.tabWidget->setTabIcon(1, QIcon("../icons/sort.png"));
	ui.tabWidget->setTabIcon(2, QIcon("../icons/finish.png"));

	ui.pushButton->setIcon(QIcon("../icons/next.png"));
	ui.pushButton_2->setIcon(QIcon("../icons/previous.png"));
	ui.pushButton_3->setIcon(QIcon("../icons/edit.png"));
	ui.pushButton_edit_warp->setIcon(QIcon("../icons/edit.png"));
	ui.pushButton_edit_warp->setIconSize(QSize(48,48));
	ui.pushButton_save->setIcon(QIcon("../icons/save.png"));
	ui.pushButton_save->setIconSize(QSize(48,48));
	ui.tabWidget->setCurrentIndex(0);

	/* delete */
	std::string delTransform = "RMDIR /S/Q ..\\transform"; 
	system(delTransform.c_str());
	std::string MDTransform = "MD ..\\transform"; 
	system(MDTransform.c_str());

	std::string delMatchData = "RMDIR /S/Q ..\\matchData"; 
	system(delMatchData.c_str());
	std::string MDMatchData = "MD ..\\matchData"; 
	system(MDMatchData.c_str());

	std::string delKmeans = "RMDIR /S/Q ..\\kmeans"; 
	system(delKmeans.c_str());
	std::string MDKmeans = "MD ..\\kmeans"; 
	system(MDKmeans.c_str());

	std::string delCost = "RMDIR /S/Q ..\\cost"; 
	system(delCost.c_str());
	std::string MDCost = "MD ..\\cost"; 
	system(MDCost.c_str());

	std::string delCrop = "RMDIR /S/Q ..\\cropping"; 
	system(delCrop.c_str());
	std::string MDCrop = "MD ..\\cropping"; 
	system(MDCrop.c_str());


	//layout->addWidget(listWidget, 3, 1);
	createActions();
	createMenus();

}


FigureGroundQt::~FigureGroundQt()
{

}


void FigureGroundQt::createActions(){
	aboutQtAct = new QAction(tr("&Parameter..."), this);
	connect(aboutQtAct, SIGNAL(triggered()), this, SLOT(parameter()));
	
}


void FigureGroundQt::createMenus(){

	window = new QWidget;
	window->setWindowTitle("QLineEdit");

	QLabel *lengthLabel = new QLabel("length weight");
	QLabel *orientationLabel = new QLabel("orientation weight");
	QLabel *deformationLabel = new QLabel("deformation weight");
	QLabel *convexityLabel = new QLabel("convexity weight");
	QLabel *autoWarpingLabel = new QLabel("auto warping");
	QLabel *toSourceLabel = new QLabel("warp to source");
	QLabel *toTargetLabel = new QLabel("warp to target");

	length_para = new QLineEdit;
	orientation_para = new QLineEdit;
	deformation_para = new QLineEdit;
	deformation_para->setValidator(new QIntValidator(deformation_para));
	convexity_para = new QLineEdit;

	QPushButton *btn1 = new QPushButton("set");	
	QObject::connect(btn1, SIGNAL(clicked()), this, SLOT(setWeight()));

	auto_warping = new QRadioButton;
	auto_warping->setChecked(true);
	warp_to_target = new QRadioButton;
	warp_to_source = new QRadioButton;
	QObject::connect(auto_warping, SIGNAL(clicked()), this, SLOT(radio_auto()));
	QObject::connect(warp_to_target, SIGNAL(clicked()), this, SLOT(radio_target()));
	QObject::connect(warp_to_source, SIGNAL(clicked()), this, SLOT(radio_source()));

	ui.listWidget->setViewMode(QListView::IconMode);


	ui.listWidget->insertItem(1, new QListWidgetItem(
		QIcon("../inputs/obj01.bmp"), "obj01"));
	ui.listWidget->insertItem(1, new QListWidgetItem(
		QIcon("../inputs/obj02.bmp"), "obj02"));
	ui.listWidget->insertItem(1, new QListWidgetItem(
		QIcon("../inputs/obj03.bmp"), "obj03"));
	ui.listWidget->insertItem(1, new QListWidgetItem(
		QIcon("../inputs/obj04.bmp"), "obj04"));
	ui.listWidget->insertItem(1, new QListWidgetItem(
		QIcon("../inputs/obj05.bmp"), "obj05"));
	ui.listWidget->insertItem(1, new QListWidgetItem(
		QIcon("../inputs/obj06.bmp"), "obj06"));
	ui.listWidget->insertItem(1, new QListWidgetItem(
		QIcon("../inputs/obj07.bmp"), "obj07"));
	ui.listWidget->insertItem(0, new QListWidgetItem(
		QIcon("../inputs/obj08.bmp"), "obj08"));
	ui.listWidget->insertItem(0, new QListWidgetItem(
		QIcon("../inputs/obj09.bmp"), "obj09"));

	QLabel *label = new QLabel;
	label->setFixedWidth (100);

	ui.listWidget->setDragEnabled(true);
	ui.listWidget->setDragDropMode(QAbstractItemView::DragDrop);

	QObject::connect(ui.listWidget, SIGNAL(currentTextChanged (const QString &)),
		label, SLOT(setText(const QString &)));


	QGridLayout *layout = new QGridLayout;
	layout->addWidget(convexityLabel, 0, 0);
	layout->addWidget(convexity_para, 0, 1);
	layout->addWidget(deformationLabel, 1, 0);
	layout->addWidget(deformation_para, 1, 1);
	layout->addWidget(lengthLabel, 2, 0);
	layout->addWidget(length_para, 2, 1);
	layout->addWidget(orientationLabel, 3, 0);
	layout->addWidget(orientation_para, 3, 1);
	
	layout->addWidget(autoWarpingLabel, 4, 0);
	layout->addWidget(auto_warping, 4, 1);
	layout->addWidget(toSourceLabel, 5, 0);
	layout->addWidget(warp_to_source, 5, 1);
	layout->addWidget(toTargetLabel, 6, 0);
	layout->addWidget(warp_to_target, 6, 1);
	layout->addWidget(btn1);


	window->setLayout(layout);

	fileMenu = new QMenu(tr("&Setting"), this);
	fileMenu->addAction(aboutQtAct);

	menuBar()->addMenu(fileMenu);
}

void FigureGroundQt::setWeight(){
	QString length_str = length_para->text();
	w_length = length_str.toDouble();

	QString ori_str = orientation_para->text();
	w_orientation = ori_str.toDouble();

	QString deformation_str = deformation_para->text();
	w_deformation = deformation_str.toDouble();

	QString convexity_str = convexity_para->text();
	w_convexity = convexity_str.toDouble();

	window->close();
}

void FigureGroundQt::parameter(){
	
	ostringstream oss;
	oss << w_length;
	QString str = QString::fromStdString(oss.str());
	length_para->setText(str);

	oss.str("");
	oss << w_orientation;
	str = QString::fromStdString(oss.str());
	orientation_para->setText(str);

	oss.str("");
	oss << w_deformation;
	str = QString::fromStdString(oss.str());
	deformation_para->setText(str);

	oss.str("");
	oss << w_convexity;
	str = QString::fromStdString(oss.str());
	convexity_para->setText(str);

	window->show();
	/*bool ok;
	int newWidth = QInputDialog::getInt(this, tr("Scribble"),
		tr("Select pen width:"),
		1,
		1, 50, 1, &ok);*/
}

void FigureGroundQt::click_edit1(){

	if (processDone==1)
	{
		std::string a = "results_";
		JC_user_crop::user_crop(g_candidate, a, g_cropData[click_candidate], click_candidate);

		QImage image0 = JC::Mat2QImage(g_cropData[click_candidate].cropMat, QImage::Format_RGB888);

		image0 = image0.scaled(ui.label_8->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		ui.label_8->setPixmap(QPixmap::fromImage(image0));

		imwrite("../results.png", g_cropData[click_candidate].cropMat);
	}
	
}

/* main procedure */
void FigureGroundQt::click_next1(){

	processDone = 0;
	click_candidate = -1;

	/* delete */
	std::string delFinal = "RMDIR /S/Q ..\\FinalRank"; 
	system(delFinal.c_str());
	std::string MDFinal = "MD ..\\FinalRank"; 
	system(MDFinal.c_str());

	//////////////////////////////////////////////////////////////////////////

	fstream fileDatabase ;
	fileDatabase.open("..\\database\\list.txt", ios::in);

	vector<std::string> SDatabase;
	std::string stringD;

	while (fileDatabase >> stringD)
		SDatabase.push_back(stringD);

	//////////////////////////////////////////////////////////////////////////
	if((lockDrop_src ==1) && (lockDrop_tar==0)){

		std::vector<std::pair<float, HungarianType > > _candidate;
		g_candidate = _candidate;

		for(int mi =0; mi < 5; mi++){
			std::vector<std::pair<float, HungarianType > > candidate_temp;

			CropType _cropData[5];
			FG_Type _FG[10];
			

			for(int i=0; i < 5; i++)
				g_cropData[i] = _cropData[i];

			for(int i =0; i < 10; i++)
				_FG[i].setWeight(w_length, w_orientation, w_deformation, w_convexity);

			for(int i =0; i < 10; i++)
				FG[i] = _FG[i];

			clock_t t1, t2;
			t1 = clock();

			FileType fileData;
	

			std::cout << mi<<" "<< SDatabase[mi] << std::endl;
			std::string pathGround = "..//database//" + SDatabase[mi];	

			JC::findFileName(Figure_Contours[0].fileName, fileData.nameF, fileData.extF, fileData.pathF);
			JC::findFileName(pathGround, fileData.nameG, fileData.extG, fileData.pathG);
			
			std::cout<<  fileData.nameF<<"."<< fileData.extF<< std::endl;
			std::cout<<  fileData.nameG<<"."<< fileData.extG<< std::endl;

			JC::readContour(Ground_Contours , pathGround, 1);

			int tSize = 8;
			std::vector<FG_procedure*> threads(tSize);

			for(int v=0; v < tSize; v++)
				threads[v] = new FG_procedure(Figure_Contours[0], Ground_Contours[v], FG[v], v);

			for(int v=0; v < tSize; v++)
				threads[v]->start();

			for(int v=0; v < tSize; v++)
				threads[v]->wait();

			for(int v=0; v < tSize; v++)
				delete threads[v];

			for(int i =0; i < tSize; i++)
				candidate_temp.insert (candidate_temp.begin(), FG[i].candidate.begin(), FG[i].candidate.end());
			sort( candidate_temp.begin(), candidate_temp.end(), compareShortestf );

			g_candidate.push_back(candidate_temp[0]);

		}
		sort( g_candidate.begin(), g_candidate.end(), compareShortestf );

		QImage image0 = JC::Mat2QImage(g_candidate[0].second.rankMat, QImage::Format_RGB888);
		QImage image1 = JC::Mat2QImage(g_candidate[1].second.rankMat, QImage::Format_RGB888);
		QImage image2 = JC::Mat2QImage(g_candidate[2].second.rankMat, QImage::Format_RGB888);
		QImage image3 = JC::Mat2QImage(g_candidate[3].second.rankMat, QImage::Format_RGB888);
		QImage image4 = JC::Mat2QImage(g_candidate[4].second.rankMat, QImage::Format_RGB888);
		image0 = image0.scaled(ui.label_3->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image1 = image1.scaled(ui.label_4->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image2 = image2.scaled(ui.label_5->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image3 = image3.scaled(ui.label_6->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image4 = image4.scaled(ui.label_7->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		ui.label_3->setPixmap(QPixmap::fromImage(image0));
		ui.label_4->setPixmap(QPixmap::fromImage(image1));
		ui.label_5->setPixmap(QPixmap::fromImage(image2));
		ui.label_6->setPixmap(QPixmap::fromImage(image3));
		ui.label_7->setPixmap(QPixmap::fromImage(image4));

		ui.tabWidget->setCurrentIndex(1);

		
		processDone = 1;
	
	}else if((lockDrop_src ==0) && (lockDrop_tar==1)){

		std::vector<std::pair<float, HungarianType > > _candidate;
		g_candidate = _candidate;

		for(int mi =0; mi < 10; mi++){
			std::vector<std::pair<float, HungarianType > > candidate_temp;

			CropType _cropData[5];
			FG_Type _FG[10];
			

			for(int i=0; i < 5; i++)
				g_cropData[i] = _cropData[i];

			for(int i =0; i < 10; i++)
				_FG[i].setWeight(w_length, w_orientation, w_deformation, w_convexity);

			for(int i =0; i < 10; i++)
				FG[i] = _FG[i];

			FileType fileData;


			std::cout << mi<<" "<< SDatabase[mi] << std::endl;
			std::string pathFigure = "..//database//" + SDatabase[mi];	

			
			JC::findFileName(pathFigure, fileData.nameG, fileData.extG, fileData.pathG);
			JC::findFileName(Ground_Contours[0].fileName, fileData.nameF, fileData.extF, fileData.pathF);

			std::cout<<  fileData.nameF<<"."<< fileData.extF<< std::endl;
			std::cout<<  fileData.nameG<<"."<< fileData.extG<< std::endl;

			JC::readContour(Figure_Contours , pathFigure, 0);

			int tSize = 4;
			std::vector<FG_procedure*> threads(tSize);

			for(int v=0; v < tSize; v++)
				threads[v] = new FG_procedure(Figure_Contours[0], Ground_Contours[v], FG[v], v);

			for(int v=0; v < tSize; v++)
				threads[v]->start();

			for(int v=0; v < tSize; v++)
				threads[v]->wait();

			for(int v=0; v < tSize; v++)
				delete threads[v];

			for(int i =0; i < tSize; i++)
				candidate_temp.insert (candidate_temp.begin(), FG[i].candidate.begin(), FG[i].candidate.end());
			sort( candidate_temp.begin(), candidate_temp.end(), compareShortestf );

			g_candidate.push_back(candidate_temp[0]);

			for(int i=0; i < 5; i ++){
				ostringstream oss;
				oss << i ; 
				string aa = "..//" + SDatabase[mi] + oss.str() + ".png"; 
				imwrite(aa, candidate_temp[i].second.rankMat);

			}


		}
		sort( g_candidate.begin(), g_candidate.end(), compareShortestf );

		QImage image0 = JC::Mat2QImage(g_candidate[0].second.rankMat, QImage::Format_RGB888);
		QImage image1 = JC::Mat2QImage(g_candidate[1].second.rankMat, QImage::Format_RGB888);
		QImage image2 = JC::Mat2QImage(g_candidate[2].second.rankMat, QImage::Format_RGB888);
		QImage image3 = JC::Mat2QImage(g_candidate[3].second.rankMat, QImage::Format_RGB888);
		QImage image4 = JC::Mat2QImage(g_candidate[4].second.rankMat, QImage::Format_RGB888);
		image0 = image0.scaled(ui.label_3->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image1 = image1.scaled(ui.label_4->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image2 = image2.scaled(ui.label_5->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image3 = image3.scaled(ui.label_6->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image4 = image4.scaled(ui.label_7->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		ui.label_3->setPixmap(QPixmap::fromImage(image0));
		ui.label_4->setPixmap(QPixmap::fromImage(image1));
		ui.label_5->setPixmap(QPixmap::fromImage(image2));
		ui.label_6->setPixmap(QPixmap::fromImage(image3));
		ui.label_7->setPixmap(QPixmap::fromImage(image4));

		ui.tabWidget->setCurrentIndex(1);

		processDone = 1;
	
	}
	else if((lockDrop_src ==1) && (lockDrop_tar==1)){

		std::vector<std::pair<float, HungarianType > > _candidate;
		CropType _cropData[5];
		FG_Type _FG[10];
		g_candidate = _candidate;

		for(int i=0; i < 5; i++)
			g_cropData[i] = _cropData[i];
		
		for(int i =0; i < 10; i++)
			_FG[i].setWeight(w_length, w_orientation, w_deformation, w_convexity);

		for(int i =0; i < 10; i++)
			FG[i] = _FG[i];

		clock_t t1, t2;
		t1 = clock();

		FileType fileData;

		JC::findFileName(Figure_Contours[0].fileName, fileData.nameF, fileData.extF, fileData.pathF);
		JC::findFileName(Ground_Contours[0].fileName, fileData.nameG, fileData.extG, fileData.pathG);

		std::cout<<  fileData.nameF<<"."<< fileData.extF<< std::endl;
		std::cout<<  fileData.nameG<<"."<< fileData.extG<< std::endl;

		int tSize = 1;
		int startIdx = 0;
		std::vector<FG_procedure*> threads(tSize);

		for(int v=startIdx; v < tSize; v++)
			threads[v] = new FG_procedure(Figure_Contours[0], Ground_Contours[v], FG[v], v);

		for(int v=startIdx; v < tSize; v++)
			threads[v]->start();
		
		for(int v=startIdx; v < tSize; v++)
			threads[v]->wait();
		
		for(int v=startIdx; v < tSize; v++)
			delete threads[v];

		for(int i =startIdx; i < tSize; i++)
			g_candidate.insert (g_candidate.begin(), FG[i].candidate.begin(), FG[i].candidate.end());
		sort( g_candidate.begin(), g_candidate.end(), compareShortestf );
		std::cout << "rank done" << std::endl;

		// [4/30/2015 jollytrees]
		for(int i =0; i < 5; i++){
			HungarianType &hData = g_candidate[i].second;

			cv::Rect boundRect;
			boundRect = boundingRect( cv::Mat(g_candidate[i].second.outContour) );
			cv::Point shiftP = boundRect.tl() - cv::Point(-200,5); 
			int rWidth = boundRect.br().x - boundRect.tl().x;
			int rHeight = boundRect.br().y - boundRect.tl().y;
			cv::Mat boundImg(600,  600, CV_8UC3);	
			boundImg.setTo(0);
			cv::Scalar color_red(0,0,255);
			cv::Scalar color_green(0,255,0);
			cv::Scalar color_blue(255,0,0);

			cv::Scalar color_yellow(0,255,255);
			cv::Scalar color_lightBlue(255,255,0);
			cv::Scalar color_purple(255,0,255);

			cv::Scalar color_white(255,255,255);
			cv::Scalar color_black(0,0,0);

			ostringstream oss;
			oss << i << hData.target.size();
			boundImg.setTo( cv::Scalar(255, 255, 255));
			JC::shiftPoint(hData.remainingSource, -shiftP);
			JC::shiftPoint(hData.remainingTarget_t, -shiftP);
			JC::shiftPoint(hData.source, -shiftP);
			JC::shiftPoint(hData.target, -shiftP);
			JC::drawContour( boundImg, hData.remainingSource, color_black, 1 ,2);
			JC::drawContour( boundImg, hData.remainingTarget_t, color_blue, 1, 2 );
			JC::drawContour_idx( boundImg, hData.source, hData.match_index_src, color_purple, 1, 2 );
			JC::drawContour_idx( boundImg, hData.target, hData.match_index_tar, color_lightBlue, 1, 2 );


// 			for(int i=0; i < hData.match_index_src.size(); i++){
// 
// 				cv::Point a = (hData.source[hData.match_index_src[i]] + hData.target[hData.match_index_tar[i]]);
// 				a.x /=2;
// 				a.y /=2;
// 
// 				cv::circle(boundImg, a, 1, color_red, 2 );
// 			}
			imwrite("../cost/"+oss.str()+".png", boundImg);

			boundImg.setTo( cv::Scalar(255, 255, 255));
			
			JC::drawContour( boundImg, hData.source, color_black, 1 ,2);
			JC::drawContour( boundImg, hData.target, color_blue, 1, 2 );
			JC::drawContour_idx( boundImg, hData.source, hData.feature_index_src, color_red, 5, 2 );
			JC::drawContour_idx( boundImg, hData.target, hData.feature_index_tar, color_red, 5, 2 );

// 			for(int k =0 ; k < hData.feature_index_src.size(); k++){
// 				for(int n =0; n < hData.match_index_src.size(); n++){
// 					if(hData.feature_index_src[k]==hData.match_index_src[n]){
// 						cv::circle(boundImg,hData.source[hData.feature_index_src[k]], 3, color_red, 2);
// 					}
// 				}
// 			}
// 			for(int k =0 ; k < hData.feature_index_tar.size(); k++){
// 				for(int n =0; n < hData.match_index_tar.size(); n++){
// 					if(hData.feature_index_tar[k]==hData.match_index_tar[n]){
// 						cv::circle(boundImg,hData.target[hData.feature_index_tar[k]], 3, color_red, 2);
// 					}
// 				}
// 			}


			imwrite("../cost/"+oss.str()+"match_.png", boundImg);
			
		}
		



		QImage image0 = JC::Mat2QImage(g_candidate[0].second.rankMat, QImage::Format_RGB888);
		QImage image1 = JC::Mat2QImage(g_candidate[1].second.rankMat, QImage::Format_RGB888);
		QImage image2 = JC::Mat2QImage(g_candidate[2].second.rankMat, QImage::Format_RGB888);
		QImage image3 = JC::Mat2QImage(g_candidate[3].second.rankMat, QImage::Format_RGB888);
		QImage image4 = JC::Mat2QImage(g_candidate[4].second.rankMat, QImage::Format_RGB888);
		image0 = image0.scaled(ui.label_3->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image1 = image1.scaled(ui.label_4->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image2 = image2.scaled(ui.label_5->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image3 = image3.scaled(ui.label_6->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		image4 = image4.scaled(ui.label_7->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		ui.label_3->setPixmap(QPixmap::fromImage(image0));
		ui.label_4->setPixmap(QPixmap::fromImage(image1));
		ui.label_5->setPixmap(QPixmap::fromImage(image2));
		ui.label_6->setPixmap(QPixmap::fromImage(image3));
		ui.label_7->setPixmap(QPixmap::fromImage(image4));

		ui.tabWidget->setCurrentIndex(1);

		processDone = 1;
		t2 = clock();
		std::cout << (t2-t1)/(double)(CLOCKS_PER_SEC) << std::endl;

		first_step_time = (t2-t1)/(double)(CLOCKS_PER_SEC);

		//ui.menuSetting->
		//outputTime();
		//JC::outputData(cropData, fileData, 0, bn);

	}else{

		CvRNG rng = cvRNG(-1);
		double m[6]={0};
		CvMat M = cvMat( 2, 3, CV_64F, m );
		int good_count = 0;
		CvRect brect;

		std::cout << cvRandInt(&rng) << std::endl;
		std::cout << cvRandInt(&rng) << std::endl;
		std::cout << cvRandInt(&rng) << std::endl;
		std::cout << "--------" << std::endl;
	}

}

void FigureGroundQt::outputTime(){
	fstream file;
	file.open("..//logFile.txt", std::ios::out);

	double total_IS = 0;
	double total_meaan_shift = 0;
	double total_hung = 0;
	double total_transformation = 0;

	for(int i =0; i < 10; i++)
	{
		if(total_IS < FG[i].run_time_IS_match)                    total_IS = FG[i].run_time_IS_match;
		if(total_meaan_shift < FG[i].run_time_mean_shift)         total_meaan_shift = FG[i].run_time_mean_shift;
		if(total_hung < FG[i].run_time_hungarian)                 total_hung = FG[i].run_time_hungarian;
		if(total_transformation < FG[i].run_time_transformation)  total_transformation = FG[i].run_time_transformation;


		file << i <<"  ---------------------------------" << std::endl;
		file << "IS match "<< FG[i].size_IS_match << std::endl;
		file << "transformation  "<< FG[i].size_transformation << std::endl;
		file << "mean-shift " << FG[i].size_mean_shift << std::endl;
		file << "hungarian "<<FG[i].size_hungarian << std::endl;
		file << "IS match "<<FG[i].run_time_IS_match << std::endl;
		file << "transformation  "<<FG[i].run_time_transformation << std::endl;
		file << "mean-shift " <<FG[i].run_time_mean_shift << std::endl;
		file << "hungarian "<< FG[i].run_time_hungarian << std::endl;
	}

	std::cout << "total_IS " <<  total_IS << std::endl;
	std::cout << "total_meaan_shift " <<  total_meaan_shift << std::endl;
	std::cout << "total_hung " <<  total_hung << std::endl;
	std::cout << "total_transformation " <<  total_transformation << std::endl;
}

void FigureGroundQt::clickCandidte(int idx, QLabel *label,  QTabWidget *tabWidget){

	
	clock_t t1, t2;
	t1 = clock();
	click_candidate = idx;
	JC_warping::opt_warp(g_candidate, idx, warp_type);
	t2 = clock();

	warp_time = (t2-t1)/(double)(CLOCKS_PER_SEC);



	std::string a = "results_"; 
	t1 = clock();
	FG_cropping::CroppingProcess( g_candidate, a ,g_cropData[idx], idx);
	t2 = clock();
	crop_time = (t2-t1)/(double)(CLOCKS_PER_SEC);

	QImage image = JC::Mat2QImage(g_cropData[idx].cropMat, QImage::Format_RGB888);
	image = image.scaled(label->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
	label->setPixmap(QPixmap::fromImage(image));
	tabWidget->setCurrentIndex(2);
}

void FigureGroundQt::click_previous(){
	ui.tabWidget->setCurrentIndex(1);
}

void FigureGroundQt::radio_auto(){
	warp_type = 2;
}
void FigureGroundQt::radio_source(){
	warp_type = 0;
}
void FigureGroundQt::radio_target(){
	warp_type = 1;
}

void FigureGroundQt::editWarp(){
	if (processDone==1)
	{
		HungarianType &Hdata = g_candidate[click_candidate].second;
		JC_powell::edit_warp(Hdata, warp_type);

 		std::string a = "results_"; 
 		FG_cropping::CroppingProcess( g_candidate, a ,g_cropData[click_candidate], click_candidate);
 		//std::string a = "results_";
		//JC_user_crop::crop_by_rect(g_candidate, a, g_cropData[click_candidate], click_candidate);


		QImage image = JC::Mat2QImage(g_cropData[click_candidate].cropMat, QImage::Format_RGB888);
		image = image.scaled(ui.label_8->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		ui.label_8->setPixmap(QPixmap::fromImage(image));
		ui.tabWidget->setCurrentIndex(2);
	}
	
}

void FigureGroundQt::saveImg(){
	if (processDone==1)
	{
		QString string;
		string = string.fromStdString("png");
		QByteArray fileFormat = string.toLocal8Bit();

		QString initialPath = QDir::currentPath() + "/untitled." + fileFormat;

		QString fileName = QFileDialog::getSaveFileName(this, tr("Save As"),
			initialPath,
			tr("%1 Files (*.%2);;All Files (*)")
			.arg(QString::fromLatin1(fileFormat.toUpper()))
			.arg(QString::fromLatin1(fileFormat)));

		QImage image = JC::Mat2QImage(g_cropData[click_candidate].cropMat, QImage::Format_RGB888);

		image.save(fileName, fileFormat) ;

		fstream file;
		file.open(fileName.toStdString() + ".txt", std::ios::out);
		file << "source " << Figure_Contours[0].fileName << endl;
		file << "target " << Ground_Contours[0].fileName << endl;
		file << "source size : " <<  size_src <<endl;
		file << "target size : " <<  size_tar <<endl;
		file << "first_step_time " << first_step_time << endl;
		file << "warp_time       " << warp_time << endl;
		file << "crop_time       " << crop_time << endl;

	}

}

void FigureGroundQt::figure_change(){
	QString qStr = ui.spinBox_src->text();
	double size = qStr.toDouble();
	size_src = size/100.0;

	if(lockDrop_src==1){
		Watched::renew_label( ui.label, cropping_src, Figure_Contours, 0 ,size_src);
	}
}
void FigureGroundQt::ground_change(){
	QString qTar = ui.spinBox_tar->text();
	double size = qTar.toDouble();
	size_tar = size/100.0;

	if(lockDrop_tar==1){
		Watched::renew_label( ui.label_2, cropping_tar, Ground_Contours, 1 ,size_tar);
	}
}

bool  FigureGroundQt::eventFilter( QObject *watched, QEvent *event) {

	if (watched == ui.label_3) {

		if (event->type() == QEvent::MouseButtonPress) {
			if(processDone == 1)
				clickCandidte(0, ui.label_8, ui.tabWidget);
			return true;
		} 
	}

	if (watched == ui.label_4) {

		if (event->type() == QEvent::MouseButtonPress) {
			if(processDone == 1)
				clickCandidte(1, ui.label_8, ui.tabWidget);
			return true;
		} 
	}

	if (watched == ui.label_5) {

		if (event->type() == QEvent::MouseButtonPress) {
			if(processDone == 1)
				clickCandidte(2, ui.label_8, ui.tabWidget);
			return true;
		} 
	}
	if (watched == ui.label_6) {

		if (event->type() == QEvent::MouseButtonPress) {
			if(processDone == 1)
				clickCandidte(3, ui.label_8, ui.tabWidget);
			return true;
		} 
	}
	if (watched == ui.label_7) {

		if (event->type() == QEvent::MouseButtonPress) {
			if(processDone == 1)
				clickCandidte(4, ui.label_8, ui.tabWidget);
			return true;
		} 
	}

	//for crop
	if (watched == ui.label_8) {

		if (event->type() == QEvent::MouseButtonPress) {
			std::string a = "results_";
			JC_user_crop::user_crop(g_candidate, a, g_cropData[click_candidate], click_candidate);
				
			QImage image0 = JC::Mat2QImage(g_cropData[click_candidate].cropMat, QImage::Format_RGB888);
		
			image0 = image0.scaled(ui.label_8->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
			ui.label_8->setPixmap(QPixmap::fromImage(image0));

			imwrite("../results.png", g_cropData[click_candidate].cropMat);

			return true;
		} 

	}


	//figure image
	if (watched == ui.label) {
		QString qStr = ui.spinBox_src->text();
		double size = qStr.toDouble();
		size_src = size/100.0;
		Watched::watched_label(event, ui.label, cropping_src, lockDrop_src, Figure_Contours, 0 ,size_src);
	}

	//ground image
	if (watched == ui.label_2) {	
		QString qTar = ui.spinBox_tar->text();
		double size = qTar.toDouble();
		size_tar = size/100.0;
		Watched::watched_label(event, ui.label_2, cropping_tar, lockDrop_tar, Ground_Contours, 1 ,size_tar);
	}
	return QWidget::eventFilter(watched, event);
}
