#include "stdafx.h"
#include <fstream>
#include "Utils_Ocv.h"
#include "JC_find_contour.h"
#ifndef _JC_H_
#define _JC_H_

namespace JC{
	using namespace cv;

	void shiftEndPoint(std::vector<endPoint> &Contour, cv::Point p){
		for(int i = 0; i < Contour.size(); i++){
			Contour[i].x-=p.x; 		
			Contour[i].y-=p.y;
		}
	}

	void shiftCtlpoint(std::vector<ctlPoint> &Contour, cv::Point p){
		for(int i = 0; i < Contour.size(); i++){
			Contour[i].x-=p.x; 		
			Contour[i].y-=p.y;
		}
	}

	void shiftPoint(std::vector<cv::Point> &Contour, cv::Point p){
		for(int i = 0; i < Contour.size(); i++)
			Contour[i] -= p; 		
	}

	void shiftPointI(std::vector<cv::Point2i> &Contour, cv::Point2i p){
		for(int i = 0; i < Contour.size(); i++)
			Contour[i] -= p; 		
	}

	void drawContour( cv::Mat &iMat, std::vector<cv::Point> &contour, cv::Scalar color, int radius, int thickness ){
		for(int i = 0 ; i < contour.size(); i++)
			cv::circle(iMat, contour[i], radius, color, thickness );
	}

	void drawContour_idx( cv::Mat &iMat, std::vector<cv::Point> &contour, std::vector<int> &idxs, cv::Scalar color, int radius, int thickness ){
		for(int i = 0 ; i < idxs.size(); i++)
			cv::circle(iMat, contour[idxs[i]], radius, color, thickness );
	}

	void drawLineContour_idx( cv::Mat &iMat, std::vector<cv::Point> &contour, std::vector<int> &idxs, cv::Scalar color, int thickness ){
		for(int i = 0 ; i < idxs.size()-1; i++)
			cv::line(iMat, contour[idxs[i]], contour[idxs[i+1]], color, thickness);
	}

	void drawLineContour( cv::Mat &iMat, std::vector<cv::Point> &contour, cv::Scalar color, int thickness ){
		for(int i = 0 ; i < contour.size(); i++)
		{
			if( i!=contour.size()-1 )
				cv::line(iMat, contour[i], contour[i+1], color, thickness );
			else
				cv::line(iMat, contour[i], contour[0], color, thickness );
		}
	}

	void drawLineContourN( cv::Mat &iMat, std::vector<cv::Point> &contour, cv::Scalar color, int thickness ){
		for(int i = 0 ; i < contour.size()-1; i++)
		{
				cv::line(iMat, contour[i], contour[i+1], color, thickness );
		}
	}

	void drawMatch( cv::Mat &iMat, std::vector<cv::Point> &contour, std::vector<cv::Point> &contour2, std::vector<int> &idxs,  std::vector<int> &idxs2 ,cv::Scalar color, int thickness ){

		for(int i = 0 ; i < idxs.size(); i++)
		{
			cv::line(iMat, contour[idxs[i]], contour2[idxs2[i]], color, thickness );
		}
	}


	std::vector<cv::Point> transformContour( cv::Mat &matrix, std::vector<cv::Point> &contour, float addX, float addY){
		
		std::vector<cv::Point> TContour;

		for( int i = 0; i < contour.size(); i++ ){
			cv::Mat results;
			float vers[] = { contour[i].x , contour[i].y, 1 }; 
			cv::Mat ver = cv::Mat( 3, 1, CV_32FC1, vers );
			results = matrix * ver;
			TContour.push_back( cv::Point( results.at<float>(0,0) + addX, results.at<float>(1,0) + addY ) );
		}

		return TContour;

	}

	void readContour(ContourType iContour[5] ,std::string &path, int ground){
		cv::Mat iMat = cv::imread(path, 0);
		if(ground == 1){
			float sizeTerm[]={ 0.6, 0.8, 1.0, 1.2, 1.4};	
			for(int j = 0 ; j < 5; j++){
				float scale = sizeTerm[j];
				cv::Size dsize = cv::Size(iMat.cols*scale, iMat.rows*scale);
				cv::Mat scale_image = cv::Mat(dsize,CV_8UC3);
				resize(iMat, scale_image, dsize);
				Find_Contour::find_contour(iContour[j], scale_image);
				cv::flip(scale_image, scale_image, 1); 
				Find_Contour::find_contour(iContour[j+5], scale_image);
			}
		}else{
			Find_Contour::find_contour(iContour[0], iMat);
		}
	}

	void draw_convexity(cv::Mat &canvas, vector<cv::Point> &pts, vector<float> convexity , int radius= 1 , int thickness = 1 ){

		for(int i =0; i < pts.size(); i++){
			Utils_Ocv &uocv= Utils_Ocv::instance();
			cv::Vec3b color;
			uocv.getColor( color, convexity[i]*100, 100, -100 );
			cv::Scalar color_t = color;
			cv::circle( canvas, pts[i], radius, color_t, thickness);		
		}

	}

	QImage Mat2QImage(cv::Mat const& mat,  QImage::Format format)
	{
		return QImage(mat.data, mat.cols, mat.rows, 
			mat.step, format).copy();
	}

	void findFileName(std::string &InString, std::string &OutName, std::string &OutExt, std::string &path){
		
		std::stringstream ss(InString);
		std::string token;
		vector<std::string> tokens;

		for (;;)
		{
			getline(ss, token, '/');
			if (ss.fail())
				break;
			tokens.push_back(token);
			//std::cout << token << std::endl;
		}

		//std::cout <<tokens[tokens.size()-1] << std::endl;

		vector<std::string> tokens2;

		std::string o2 =  tokens[tokens.size()-1]; 
		//path = tokens[tokens.size()-2];
		std::stringstream ss2(o2);
		for (;;)
		{
			getline(ss2, token, '.');
			if (ss2.fail())
				break;
			tokens2.push_back(token);
			//std::cout << token << std::endl;
		}

		OutName = tokens2[tokens2.size()-2];
		OutExt = tokens2[tokens2.size()-1];
		

	}

	void outputTextf(std::string &fileName, std::vector<float> &contour){

		std::string outPath = fileName+".txt";
		std::fstream oFile(outPath, std::ios::out);

		for(int i =0; i < contour.size(); i++){

			oFile << contour[i] << std::endl;

		}


		oFile.close();
	}

	void outputText(std::string &fileName, std::vector<cv::Point> &contour){

		std::string outPath = fileName+".txt";
		std::fstream oFile(outPath, std::ios::out);
		
		for(int i =0; i < contour.size(); i++){

			oFile << contour[i].x << " " << contour[i].y << std::endl;

		}
		

		oFile.close();
	}

	void outputTexti(std::string &fileName, std::vector<int> &contour){

		std::string outPath = fileName+".txt";
		std::fstream oFile(outPath, std::ios::out);

		for(int i =0; i < contour.size(); i++){

			oFile << contour[i]<< std::endl;

		}


		oFile.close();
	}

	void outputData(std::vector<std::pair<float, CropType > > &cropData, FileType &fileData, int cn, int bn){

		std::ostringstream oss, oss2, oss3;

		int debuhMode = 0;
		int drawSize = 5;
		if(cropData.size()<5) drawSize = cropData.size();


		for( int i = 0; i <drawSize; i++ ){

			HungarianType &Hdata = cropData[i].second.hData;

			int r = 255 * (rand()/(1.0 + RAND_MAX));
			int g = 255 * (rand()/(1.0 + RAND_MAX));
			int b = 255 * (rand()/(1.0 + RAND_MAX));

			oss.str("");
			oss<<fileData.nameF<<"_"<<fileData.nameG<<"_rank_"<<i<<"_";

			oss2.str("");
			oss2<<bn;


			int rWidth = Hdata.boundRect.br().x - Hdata.boundRect.tl().x ;
			int rHeight = Hdata.boundRect.br().y - Hdata.boundRect.tl().y ;

			cv::Mat canvas(rHeight, rWidth , CV_8UC3, cv::Scalar(255,255,255));

			int draw_radius = 1, draw_thickness = 1;


			/*draw line whole FG contour */
			JC::drawLineContour( canvas, Hdata.compositeContour, cv::Scalar(255, 0, 0), 3 );


			std::string filePath = "../cropping/"+oss.str()+".png";
			//cv::imwrite(filePath, canvas );

			/* draw whole target points */
			JC::drawLineContour( canvas, Hdata.target, cv::Scalar(0, 0, 0), 3 );


			/* draw whole target points */
			JC::drawContour( canvas, Hdata.remainingTarget_t, cv::Scalar(0, 0, 255), 2 ,2);

			filePath = "../cropping/"+oss.str()+"1.png";

			/* no line */
			//cv::imwrite(filePath, canvas );

			/* match interested tar */
			JC::drawContour( canvas, Hdata.interested_target, cv::Scalar(0, 255, 255), 3 ,3);

			/* feature src */
			JC::drawContour( canvas, Hdata.match_src_feature, cv::Scalar(255, 0, 255), 3 ,2);

			/* feature tar */
			JC::drawContour( canvas, Hdata.match_tar_feature, cv::Scalar(0, 255, 0), 5 ,2);

if(debuhMode==1)std::cout <<"draw all contour" <<std::endl;

			filePath = "../cropping/"+oss.str()+".png";
			cv::imwrite(filePath, canvas );

			filePath = "../cropping/"+oss.str()+"result.png";
			cv::imwrite(filePath, cropData[i].second.cropMat );

			filePath = "../cropping/"+oss2.str()+".txt";
			std::fstream oFile(filePath, std::ios::app);
			
			oFile << "(" << cn <<","
				<< bn <<","
				<< i << ",'"
				<< fileData.nameF<< "','"
				<< fileData.nameG << "','"
				<<oss.str()<<"', '" 
				<< Hdata.curveRatio<<"', '"
				<< Hdata.distCost<<"', '"
				<<Hdata.lengthCost<<"', '"
				<<Hdata.orientationCost<<"', '"
				<<Hdata.totalCost<<"')";
				if(i<5){
					oFile<<"," << std::endl;
				}else{
					oFile<<";" << std::endl;
				}
				
				
				
			
// 			oFile << Hdata.curveRatio << std::endl;
// 			oFile << Hdata.distCost << std::endl;
// 			oFile << Hdata.lengthCost << std::endl;
// 			oFile << Hdata.orientationCost << std::endl;
// 			oFile << Hdata.totalCost << std::endl;
// 			oFile << Hdata.size << std::endl;
// 			oFile << fileData.nameF<< std::endl;
// 			oFile << fileData.extF << std::endl;
// 			oFile << fileData.nameG<< std::endl;
// 			oFile << fileData.extG << std::endl;
			oFile.close();

		}/* end [i] */
	}
}

#endif
