#include "stdafx.h"
#ifndef _JC_DRAW_H_
#define _JC_DRAW_H_

namespace JC_draw{
	using namespace cv;
	void drawContours(cv::Mat &iMat, std::vector<cv::Point> &contour, cv::Scalar color, int radius, int thickness){

		for(int i = 0 ; i < contour.size(); i++){
			cv::circle(iMat, contour[i], radius, color, thickness );
		}	
	}
}

#endif
