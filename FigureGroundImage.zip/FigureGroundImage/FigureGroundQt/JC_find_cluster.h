#include "stdafx.h"
#include "JC_type.h"
#include "JC_meanShift.h"
#include <fstream>
#ifndef _JC_FIND_CLUSTER_H_
#define _JC_FIND_CLUSTER_H_

namespace Cluster{

	void meanShift(std::vector<MatchType> &transform_data, clusterType &means_data){

		vector<ms_Point> pointVector;

		for( int i= 0; i < transform_data.size(); i++ ){

			int x = transform_data[i].transformData.translate_x;
			int y = transform_data[i].transformData.translate_y;
			int thetaMean = transform_data[i].transformData.theta;

			ms_Point temp;
			temp.p = cv::Point3d(x,y,thetaMean);
			temp.label = -1;
			pointVector.push_back(temp);
		}	

		vector< int > centerLabel;
		vector< cv::Point3d > centerVector;
		vector< int > centerIndex;
		vector< int > centerDist;
		centerIndex.resize(pointVector.size());
		centerVector.resize(pointVector.size());
		centerLabel.resize(pointVector.size(), -1);
		centerDist.resize(pointVector.size());
		int labelNums = 0;
		
		MeanShift::meanShift(pointVector, 25, 30, centerLabel, centerVector, centerIndex, centerDist, labelNums);

		std::vector<std::vector<MatchType> > _temp_kmean_results;
		_temp_kmean_results.resize(labelNums);
		/* store the results of mean shift  */
		for( int i= 0; i < transform_data.size(); i++ ){
			if(centerIndex[i]!=-1){
				int _index = centerLabel[centerIndex[i]]-1;
				_temp_kmean_results[_index].push_back(transform_data[i]);	
			}		
		}

		means_data.clusters = _temp_kmean_results;

	}

}

#endif
