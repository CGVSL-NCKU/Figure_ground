#include "stdafx.h"
#include "JC_type.h"
#ifndef _JC_CROP_H_
#define _JC_CROP_H_

namespace JC_crop{
	using namespace cv;
	IplImage* Imagex;//original
	IplImage* Image;//modified
	CvPoint VertexOne,VertexThree;//����Ϊ����W�I�M�k�U�I
	CvScalar Color;//�خ��C��
	int Thickness;//�خزʲ�
	int Shift;//�خؤj�p(0�����`)
	int key;//����X
	int endDrag = 0;

	void onMouse(int event,int x,int y,int flag,void* param){
		// 	printf("( %d, %d) ",x,y);
		// 	printf("The Event is : %d ",event);
		// 	printf("The flags is : %d ",flag);
		// 	printf("The param is : %d\n",param);
		// 	cout << "ed " << endDrag << endl;
		if(event==CV_EVENT_LBUTTONDOWN||event==CV_EVENT_RBUTTONDOWN){//�o�쥪�W���y��
			VertexOne=cvPoint(x,y);
		}
		if(event==CV_EVENT_LBUTTONUP||event==CV_EVENT_RBUTTONUP){//�o��k�U���y��
			VertexThree=cvPoint(x,y);
			endDrag = 1;
		}
		if(flag==CV_EVENT_FLAG_LBUTTON||flag==CV_EVENT_FLAG_RBUTTON){//�즲�ƹ�
			VertexThree=cvPoint(x,y);
			cvReleaseImage(&Image);//�p�G�S�����ܡA�O����|�ɺ�
			Image = cvCloneImage(Imagex);//cvCopy(Imagex, Image, 0);
			cvRectangle(Image,VertexOne,VertexThree,Color,Thickness,CV_AA,Shift);
			cvShowImage("Modified",Image);
		}
		// 	printf("VertexOne( %d, %d) ",VertexOne.x,VertexOne.y);
		// 	printf("VertexThree( %d, %d)\n",VertexThree.x,VertexThree.y);
	}

	void cropping(Mat &mat_image, Point &vOne, Point &vThree){

		Imagex= cvCloneImage(&(IplImage)mat_image);
		Image = cvCloneImage(Imagex);
		VertexOne=cvPoint(0,0);
		VertexThree=cvPoint(0,0);
		Color=CV_RGB(0,255,0);
		Thickness=2;
		Shift=0;
		key=0;
		cvNamedWindow("Modified",0);
		cvResizeWindow("Modified",mat_image.cols,mat_image.rows);
		cvSetMouseCallback("Modified",onMouse,NULL);//�]�w�ƹ�callback�禡

		cvShowImage("Modified", Image);

		while(true){
			int key = cv::waitKey(1);
			if(key==13){
				if(endDrag == 1)
					break;
			}
		}
		cvDestroyWindow("Modified");

		if (VertexOne.x < 0) VertexOne.x = 0;
		if (VertexOne.x > mat_image.cols) VertexOne.x = mat_image.cols;
		if (VertexThree.x < 0) VertexThree.x = 0;
		if (VertexThree.x > mat_image.cols) VertexThree.x = mat_image.cols;
		if (VertexOne.y < 0) VertexOne.y = 0;
		if (VertexOne.y > mat_image.rows) VertexOne.y = mat_image.rows;
		if (VertexThree.y < 0) VertexThree.y = 0;
		if (VertexThree.y > mat_image.rows) VertexThree.y = mat_image.rows;

		vOne = Point(VertexOne.x, VertexOne.y);
		vThree = Point(VertexThree.x, VertexThree.y);

	}

	void croppingW(Mat &inputImg){
		cv::Mat return_image = inputImg.clone();
		cv::Point vOne, vThree;
		JC_crop::cropping(inputImg, vOne, vThree);
	}
	

	cv::Mat croppingLabel_figure(QLabel *Ql, Mat &inputImg, ContourType iContours[10]){
		cv::Mat return_image = inputImg.clone();
		cv::Point vOne, vThree;
		JC_crop::cropping(inputImg, vOne, vThree);
		cv::rectangle(return_image, vOne, vThree, cv::Scalar(0, 0, 255));
		cv::cvtColor(return_image, return_image ,CV_BGR2RGB);

		/* redefine the user defined region */
		float sizeTerm = 1.0;	
		int idx = 0;

		std::vector<int> _temp_user_defined_index;
		for (int j = 0; j < iContours[idx].contour.size(); j++)
		{
			if(iContours[idx].contour[j].x >= (vOne.x*sizeTerm) && iContours[idx].contour[j].x <= (vThree.x*sizeTerm) &&
				iContours[idx].contour[j].y >= (vOne.y*sizeTerm) && iContours[idx].contour[j].y <= (vThree.y*sizeTerm) ){
					_temp_user_defined_index.push_back(j);
			}
		}
		if(_temp_user_defined_index.size()>0)iContours[idx].user_defined_index = _temp_user_defined_index;
	

// 		QImage image((uchar*)return_image.data, return_image.cols, return_image.rows, QImage::Format_RGB888);
// 		if (!image.isNull()) {
// 			image = image.scaled(Ql->size(),
// 				Qt::KeepAspectRatio,
// 				Qt::SmoothTransformation);
// 			Ql->setPixmap(QPixmap::fromImage(image));
// 		}

		return return_image;

	}


	cv::Mat croppingLabel(QLabel *Ql, Mat &inputImg, ContourType iContours[10]){
		cv::Mat return_image = inputImg.clone();
		cv::Point vOne, vThree;
		JC_crop::cropping(inputImg, vOne, vThree);
		cv::rectangle(return_image, vOne, vThree, cv::Scalar(0, 0, 255));
		cv::cvtColor(return_image, return_image ,CV_BGR2RGB);

		/* redefine the user defined region */
		float sizeTerm[]={ 0.6, 0.8, 1.0, 1.2, 1.4};	
		for(int i = 0; i < 5; i++){
			std::vector<int> _temp_user_defined_index;
			for (int j = 0; j < iContours[i].contour.size(); j++)
			{
				if(iContours[i].contour[j].x >= (vOne.x*sizeTerm[i]) && iContours[i].contour[j].x <= (vThree.x*sizeTerm[i]) &&
					iContours[i].contour[j].y >= (vOne.y*sizeTerm[i]) && iContours[i].contour[j].y <= (vThree.y*sizeTerm[i]) ){
					_temp_user_defined_index.push_back(j);
				}
			}
			if(_temp_user_defined_index.size()>0)iContours[i].user_defined_index = _temp_user_defined_index;
		}

		for(int i = 0; i < 5; i++){
			std::vector<int> _temp_user_defined_index;
			float width = inputImg.cols*sizeTerm[i];
			for (int j = 0; j < iContours[i+5].contour.size(); j++)
			{

				if(iContours[i+5].contour[j].x <= (width-(vOne.x*sizeTerm[i])) && iContours[i+5].contour[j].x >= (width-(vThree.x*sizeTerm[i])) &&
					iContours[i+5].contour[j].y >= (vOne.y*sizeTerm[i]) && iContours[i+5].contour[j].y <= (vThree.y*sizeTerm[i]) ){
						_temp_user_defined_index.push_back(j);
				}
			}
			if(_temp_user_defined_index.size()>0)iContours[i+5].user_defined_index = _temp_user_defined_index;
		}
		
// 		QImage image((uchar*)return_image.data, return_image.cols, return_image.rows, QImage::Format_RGB888);
// 		if (!image.isNull()) {
// 			image = image.scaled(Ql->size(),
// 				Qt::KeepAspectRatio,
// 				Qt::SmoothTransformation);
// 			Ql->setPixmap(QPixmap::fromImage(image));
// 		}
		return return_image;

	}


}

#endif