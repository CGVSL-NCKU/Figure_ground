#include "stdafx.h"
#include "JC_type.h"

#ifndef _JC_FIND_CONTOUR_H_
#define _JC_FIND_CONTOUR_H_

#include "JC_GaussianDistribution.h"

namespace Find_Contour{

	static bool compareLongest( std::pair<int,int> x, std::pair<int,int> y ) {return x.second > y.second;}

	void uniqueLength(std::vector<cv::Point> &input_contour, std::vector<cv::Point> &output_contour)
	{
		int unique_length = 4; ///Define the sample distance of original contour.
		std::vector<cv::Point> _output_contour;
		_output_contour.push_back(input_contour[0]);
		int pre_point = 0;
		int now_point = 1;
		while(now_point < input_contour.size())
		{
			cv::Point pre = cv::Point(input_contour[pre_point].x, input_contour[pre_point].y);
			cv::Point now = cv::Point(input_contour[now_point].x, input_contour[now_point].y);
			cv::Point vec = pre - now;
			double vec_norm = cv::norm(vec);
			if (vec_norm > unique_length)
			{
				_output_contour.push_back(input_contour[now_point]);
				pre_point = now_point;
				now_point = now_point + 1;
			}
			else
			{
				now_point++;
			}
		}
		output_contour = _output_contour;
	}

	void find_feature_index(ContourType &oContour){
		oContour.feature_index_contour.resize( oContour.feature_contour.size() );
		for( int i =0; i < oContour.feature_contour.size(); i++){
			double nearest_dist = 99999 ;
			double x1 =  oContour.feature_contour[i].x;
			double y1 =  oContour.feature_contour[i].y;
			int point_index = 0;
			for (int j = 0; j < oContour.contour.size(); j++ ){
				double x2 = oContour.contour[j].x;
				double y2 = oContour.contour[j].y;
				double dist = sqrt( abs( pow((x1-x2), 2) + pow((y1-y2), 2) ) ) ;
				if( nearest_dist > dist ){
					nearest_dist = dist;
					point_index = j;
				}						
			}
			oContour.feature_index_contour[i] = point_index;
		}
	}

	void findAngle(ContourType &oContour){

		using namespace cv;

		std::vector< std::vector<int> > approxPoly_size;
		std::vector< float > approxPoly_angle;
		approxPoly_size.resize(oContour.feature_contour.size());
		approxPoly_angle.resize(oContour.feature_contour.size());
		for( int i =0; i < approxPoly_size.size(); i++){
			approxPoly_size[i].resize(oContour.feature_contour.size());			
		}

		/* calculate the size of feature points between the two points */
		for( int i =0; i < oContour.feature_contour.size(); i++){
			if((i+1)<oContour.feature_contour.size()){
				approxPoly_size[i][i+1] = approxPoly_size[i+1][i] = (oContour.feature_index_contour[i+1] - oContour.feature_index_contour[i] + oContour.contour.size())%oContour.contour.size();
//	std::cout <<"contour size " << oContour.feature_index_contour[i+1] << "-" << oContour.feature_index_contour[i] << "="<<approxPoly_size[i][i+1]<< std::endl;
			}else{
				approxPoly_size[i][0] = approxPoly_size[0][i] = (oContour.feature_index_contour[0] -  oContour.feature_index_contour[i] + oContour.contour.size())%oContour.contour.size();
//	std::cout << "contour size " << oContour.feature_index_contour[0] << "-" << oContour.feature_index_contour[i] << "="<<approxPoly_size[i][0] << std::endl;
			}			
		}


		// draw
		// 		cv::Mat canvas (500, 500 , CV_8UC3, cv::Scalar(255,255,255));
		// 		for(int i = 0 ; i < oContour.contour.size(); i ++){
		// 			
		// 			cv::circle(canvas, oContour.contour[i], 1, cv::Scalar(0,0,0),1);
		// 
		// 		}


		for (int i = 0; i < oContour.feature_contour.size(); i++){

			int featureSize = oContour.feature_contour.size();

			int mid = ( i + featureSize ) % featureSize ;
			int first = ( i + featureSize -1 ) % featureSize ;
			int last = ( i + featureSize +1 ) % featureSize ;

			CvPoint2D32f V1,V2;
			V1 = oContour.feature_contour[first] - oContour.feature_contour[mid] ;
			V2 = oContour.feature_contour[last] - oContour.feature_contour[mid] ;

			double norm1 , norm2, dotProduct ;

			float Array1[]={ V1.x, V1.y, 0 };
			float Array2[]={ V2.x, V2.y, 0 };
			CvMat* mat1 = cvCreateMat( 1, 3, CV_32FC1 );
			CvMat* mat2 = cvCreateMat( 1, 3, CV_32FC1 );
			CvMat* cross_result = cvCreateMat( 1, 3, CV_32FC1 );

			cvSetData(mat1,Array1,mat1->step);
			cvSetData(mat2,Array2,mat2->step);

			dotProduct = cvDotProduct ( mat1, mat2 );
			cvCrossProduct( mat1, mat2, cross_result );
			norm1 = cvNorm( mat1, NULL, CV_L2 );
			norm2 = cvNorm( mat2, NULL, CV_L2 );

			double theta = acos( dotProduct / ( norm1 * norm2) ) * 180 / 3.1415;

			//		cv::Mat canvas2 = canvas.clone();

			if( cvGet2D(cross_result,0,2).val[0] < 0 ) { 
				approxPoly_angle[mid] =  -(180.0 - theta) / 180.0;
			}else{ // �w�� (<0)
				approxPoly_angle[mid] =  (180.0 - theta) / 180.0;
			}

			// 			std::ostringstream oss2;
			// 			cv::circle(canvas2, oContour.feature_contour[i], 2, cv::Scalar(0,0,255),2);
			// 			oss2 << theta << " " << approxPoly_angle[mid];
			// 			cv::putText(canvas2, oss2.str(), oContour.feature_contour[i], cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(255, 0, 0), 1);
			// 
			// 			std::ostringstream oss;
			// 			oss.str("");
			// 			oss << approxPoly_angle.size() << "_"<< i << "3.png";
			// 			cv::imwrite(oss.str(),canvas2);

		}

/*
		int startX = 100;
		double startY = -1.0;
		for(int i =0; i <= 20; i++){
			double input1 = 0.1*(double)i;
			double newY = startY + input1;
			double test1 = Gaussian::GaussianTransfer(newY,0,0.4);
			int newX = startX+10*i;
			cv::circle(MLS_canvas2, cv::Point(newX,(int)(500-test1*100)), 1, color_purple, 2);
			ostringstream oss;
			oss <<  fixed << setprecision(0)<< test1 ;
			cout << fixed << setprecision(2) << test1 <<" " <<i << endl;
			cv::putText(MLS_canvas2, oss.str(), cv::Point(newX,(int)(500-test1*2)), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar(255, 255, 0), 1);

		}
		*/

		oContour.curve_contour.resize( oContour.contour.size() , 0 );
		for (int i = 0; i < oContour.feature_contour.size(); i++){

			int lastC = (i -1  + oContour.feature_contour.size())% oContour.feature_contour.size();
			int nextC = (i +1  + oContour.feature_contour.size())% oContour.feature_contour.size();

			for (int j = 0; j < approxPoly_size[lastC][i]/2 +1; j++)
			{
				int tempj =  (oContour.feature_index_contour[i] - j)% oContour.curve_contour.size();
				double gaussian_input = 0.1 *(double)j;
				double return_transfer = Gaussian::GaussianTransfer(gaussian_input, 0, 0.4);
				oContour.curve_contour[tempj] = return_transfer *  (float)approxPoly_angle[i];
			}

			for (int j = 0; j < approxPoly_size[i][nextC]/2 +1; j++)
			{
				int tempj =  (oContour.feature_index_contour[i] + j)% oContour.curve_contour.size();
				double gaussian_input = 0.1 *(double)j;
				double return_transfer = Gaussian::GaussianTransfer(gaussian_input, 0, 0.4);
				oContour.curve_contour[tempj] = return_transfer *  (float)approxPoly_angle[i];
			}

		
		}


	}

	void find_contour(ContourType &oContour, cv::Mat &iMat){

		std::vector<std::vector<cv::Point> > contours; /* temporary results from the cv::findContours */
		cv::Mat oMat = iMat.clone();

		/* find contours */
		cv::blur(oMat, oMat, cvSize(3,3)); 
		cv::threshold(oMat, oMat, 100, 255, cv::THRESH_BINARY); ///Applies a fixed-level threshold to each array element.
		cv::findContours(oMat, contours, CV_RETR_LIST, CV_CHAIN_APPROX_NONE); ///Finds contours in a binary image.

		/* find the longest contour from all contours. */
		std::vector<cv::Point> longest_contour, contour_2nd;	
		std::vector<std::pair<unsigned int,int> > all_contours; /* temporary contours */
		for(unsigned int contour_size = 0; contour_size < contours.size(); contour_size++)	
			all_contours.push_back( std::make_pair( (int)contour_size, contours[contour_size].size() ) );
		sort(all_contours.begin(), all_contours.end(), compareLongest);
		longest_contour = contours[all_contours[0].first];

		std::vector< std::vector<cv::Point> > inner_contours;
		for (int i =1; i < contours.size(); i++)
		{
			contour_2nd = contours[all_contours[i].first];
			uniqueLength(contour_2nd, contour_2nd);
			inner_contours.push_back(contour_2nd);
			
		}
		oContour.inner_contours = inner_contours;


		/* reduce the cutter */
		uniqueLength(longest_contour, longest_contour);
		oContour.contour = longest_contour;
		
		/* find the feature points */
		std::vector<cv::Point> approxPoly_contour;
		int approxPoly_level = 5;
		cv::approxPolyDP( cv::Mat(longest_contour), approxPoly_contour, approxPoly_level, true );
		oContour.feature_contour = approxPoly_contour;


		/* find the index of feature points */
		find_feature_index(oContour);

		/* find angle */
		findAngle(oContour);

		/* default: user defined region */

		oContour.user_defined_index.resize(oContour.contour.size());
		for (int i =0; i < oContour.contour.size(); i++)
		{
			oContour.user_defined_index.push_back(i);
		}
		

// 		cv::Mat canvas(500, 500 , CV_8UC3, cv::Scalar(255,255,255));
// 		for(int i = 0 ; i < oContour.contour.size(); i ++){
// 			cv::circle(canvas, oContour.contour[i], 1, cv::Scalar(0,0,0),2);
// 		}
// 
// 		for(int i =0; i < oContour.inner_contours.size() ; i++)
// 			for (int j =0; j< oContour.inner_contours[i].size() ;j++)
// 			{
// 				cv::circle(canvas, oContour.inner_contours[i][j], 1, cv::Scalar(255,0,0),2);
// 			}
// 		std::cout <<oContour.inner_contours.size() << std::endl;
// 
// 		imshow("2nd",canvas);

		/* 2014-12-21 */
		/* temp draw contour */

// 		cv::Mat canvas(500, 500 , CV_8UC3, cv::Scalar(255,255,255));
// 		std::vector<std::vector<cv::Point>> inner_tarTarBlobs;
// 		inner_tarTarBlobs.push_back(oContour.contour);
	//	inner_tarTarBlobs.push_back(oContour.inner_contours[0]);
	//	cv::drawContours(canvas, inner_tarTarBlobs, 0,  cv::Scalar(0,0,0), CV_FILLED);
		//cv::drawContours(canvas, inner_tarTarBlobs, 1,  cv::Scalar(255,255,255), CV_FILLED);
		
// 		for(int i = 0 ; i < oContour.contour.size()-1; i ++){
// 			cv::line(canvas, oContour.contour[i], oContour.contour[i+1], cv::Scalar(0,0,255),3);
// 		}
	/*	for(int i = 0 ; i < approxPoly_contour.size(); i ++){
			cv::circle(canvas, approxPoly_contour[i], 2, cv::Scalar(0,0,255),2);
		}*/


	//	std::ostringstream oss;
		/*for(int i =0; i < oContour.contour.size(); i++){
			Utils_Ocv &uocv= Utils_Ocv::instance();
			cv::Vec3b color;
			uocv.getColor( color, oContour.curve_contour[i]*100, 100, -100 );
			cv::Scalar color_t = color;
			cv::circle( canvas, oContour.contour[i], 1, color_t, 2);		


		}*/
// 		oss << oContour.contour.size() << "_"<< ".png";
// 		cv::imwrite(oss.str(),canvas);




	}

}

#endif