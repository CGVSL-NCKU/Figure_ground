#include "stdafx.h"
#include "JC_type.h"
#include "JC_functions.h"
#include <time.h>
#include <fstream>
#ifndef _JC_FG_CROPPING_H_
#define _JC_FG_CROPPING_H_
using namespace std;

class bolbData{	
public:
	std::vector< std::vector<cv::Point2i > > blobs;
	std::vector<cv::Point2i > srcblob;
	std::vector<cv::Point2i > tarblob;
	std::vector<int> blobsColor;
	//std::vector <adjLabel> &adjacency;
	cv::Mat binary;
	double totalRatio;
	cv::Rect rect;
	int boundary;
};

namespace FG_cropping{

	static bool compareLongestf( std::pair<float,bolbData> x, std::pair<float,bolbData> y ) { return x.first > y.first; }
	static bool compareLongestMat( std::pair<float,CropType> x, std::pair<float,CropType> y ) { return x.first > y.first; }

	double distance(double x, double y, double a, double b, double c)
	{
		return fabs(a*x+b*y+c)/sqrt(a*a+b*b);
	}

	int Find_Boundary(cv::Mat &boundImg, cv::Point &p){
		
		/* 4 boundary */
		int ax[] = {1, 0, 1 , 0};
		int by[] = {0, 1, 0, 1};
		int cz[] = {0, 0 ,-boundImg.cols, -boundImg.rows};

		/*
			0 : x = 0;
			1 : y = 0;
			2 : x = boundImg.rows;
			3 . y = boundImg.cols;		
		*/

		/* find nearest boundary */
		double shortD = 99999;
		int shortI = -1;
		for (int i = 0 ; i < 4; i ++){
			double dist = distance( p.x , p.y , ax[i], by[i], cz[i]);
			if(shortD > dist){
				shortD = dist;
				shortI = i;
			} 
		}

		return shortI;
	}

	cv::Rect Find_Rect(cv::Mat &boundImg, cv::Point &p, int &shortI){
		vector<vector<int> > croppingRect;
		croppingRect.resize(4);
		int r[4][4] = {
			{p.x, 0, boundImg.cols-p.x, boundImg.rows}, // |__| -> |_|
			{0, p.y, boundImg.cols, boundImg.rows-p.y}, 
			{0, 0, p.x, boundImg.rows},
			{0, 0, boundImg.cols, p.y}
		};
		for(int i = 0 ; i < 4; i++){
			croppingRect[i].assign(r[i], r[i]+4);
		}
		cv::Rect rect (croppingRect[shortI][0], croppingRect[shortI][1], croppingRect[shortI][2], croppingRect[shortI][3]);
		return rect;
	}

	cv::Rect FindClipRect(cv::Mat &boundImg, cv::Point &p, int &shortI){
		vector<vector<int> > croppingRect;
		croppingRect.resize(4);
		int r[4][4] = {
			{0, 0, p.x, boundImg.rows}, // |__| -> |_|
			{0, 0, boundImg.cols, p.y}, 
			{p.x, 0, boundImg.cols, boundImg.rows},
			{0, p.y, boundImg.cols, boundImg.rows}
		};
		for(int i = 0 ; i < 4; i++){
			croppingRect[i].assign(r[i], r[i]+4);
		}
		cv::Rect rect (croppingRect[shortI][0], croppingRect[shortI][1], croppingRect[shortI][2], croppingRect[shortI][3]);

		return rect;
	}

	int numInRect(vector<cv::Point> & pSet, cv::Rect &rect){
		int n = 0;
		for(int i = 0; i < pSet.size(); i++){
			if ( (pSet[i].x >= rect.tl().x) && (pSet[i].x <= rect.br().x) && (pSet[i].y >= rect.tl().y) && (pSet[i].y <= rect.br().y) )
				n++;
		}
		return n;
	}

	void drawMat(cv::Mat &OMat ,std::vector<cv::Point2i> &blobs, cv::Scalar &color){
		
		for(size_t i=0; i < blobs.size(); i++) {
			int x = blobs[i].x;
			int y = blobs[i].y;
			if((x < OMat.cols) && (x >=0) && (y <OMat.rows) &&(y >=0)){
				OMat.at<cv::Vec3b>(y,x)[0] = color.val[0];
				OMat.at<cv::Vec3b>(y,x)[1] = color.val[1];
				OMat.at<cv::Vec3b>(y,x)[2] = color.val[2];
			}		
		}
	}

	void ColorBolbs(cv::Mat &OMat, bolbData &boundBlobs){

		ostringstream oss;		
		cv::Scalar color;
	
		for(size_t i=0; i < boundBlobs.blobs.size(); i++) {
			if(boundBlobs.blobsColor[i]==1)
				color = cv::Scalar(0,0,0);
			else
				color = cv::Scalar(255,255,255);			
			drawMat(OMat, boundBlobs.blobs[i], color);
		}
	}

	void checkNeighbor(cv::Point &p, cv::Mat &label_image, vector<vector<cv::Point> > &areaPoint){

		/* local blob count */
		int x[] = {p.x, p.x, p.x+1, p.x-1};
		int y[] = {p.y+1, p.y-1, p.y, p.y};
		vector<int> _blobCount;
		_blobCount.resize(areaPoint.size()); 
		for(int k = 0; k< 4; k++){
			if( (x[k] < label_image.cols) && (x[k] >=0) && (y[k] <label_image.rows) &&(y[k] >=0) ){
				int *row2 = (int*)label_image.ptr(y[k]);
				_blobCount[row2[x[k]]] = 1;
			}
		}

		/*  */
		for(int i =0 ; i < areaPoint.size(); i++){
			if(_blobCount[i] == 1){
				areaPoint[i].push_back(p);
			}			
		}
			
	}

	void FindBlobs(bolbData &boundBlobs, std::vector<cv::Point> &remainingSource, std::vector<cv::Point> &remainingTarget_t, std::vector<vector<cv::Point>> &lostPoint ){
		
		const cv::Mat &binary = boundBlobs.binary;
		std::vector< std::vector<cv::Point2i> > &blobs = boundBlobs.blobs;
		std::vector<int> &blobsColor = boundBlobs.blobsColor;
		boundBlobs.totalRatio = 0;
		blobs.clear();
		cv::Mat label_image = binary.clone();
		int label_count = 4; // starts at 2 because 0,1 are used already

		for(int y=0; y < label_image.rows; y++) {
			int *row = (int*)label_image.ptr(y);

			for(int x=0; x < label_image.cols; x++) {
				if(row[x] != 1) { // 1 white
					continue;
				}

				cv::Rect rect;
				cv::floodFill(label_image, cv::Point(x,y), label_count, &rect, 0, 0, 4);

				std::vector <cv::Point2i> blob;

				for(int i=rect.y; i < (rect.y+rect.height); i++) {
					int *row2 = (int*)label_image.ptr(i);
					for(int j=rect.x; j < (rect.x+rect.width); j++) {

						if(row2[j] != label_count) 	continue;

						blob.push_back(cv::Point2i(j,i));
					}
				}
				
				blobs.push_back(blob);
				label_count++;
			}
		}
		blobsColor.resize(blobs.size());
		vector<vector<cv::Point>> tarAreaPoint;
		vector<vector<cv::Point>> srcAreaPoint;
		tarAreaPoint.resize(label_count);
		srcAreaPoint.resize(label_count);

		/* find blobs neighbor contour */
		for(int p = 0 ; p < remainingSource.size(); p++){
			checkNeighbor(remainingSource[p], label_image, srcAreaPoint);
		}
		for(int p = 0 ; p < remainingTarget_t.size(); p++){
			checkNeighbor(remainingTarget_t[p], label_image, tarAreaPoint);
		}
		for (int p = 4 ; p < label_count; p++)
		{
			
			if(srcAreaPoint[p].size()>tarAreaPoint[p].size()){
				blobsColor[p-4] = 0;
				boundBlobs.totalRatio += srcAreaPoint[p].size();
				lostPoint.push_back(tarAreaPoint[p]);
			}else{
				blobsColor[p-4] = 1;
				//boundBlobs.totalRatio += tarAreaPoint[p].size();
				lostPoint.push_back(srcAreaPoint[p]);
			}
		}


	}

	void Find_CroppingBoundary(cv::Point &iPoint, cv::Mat &boundImg,  std::vector<std::pair<float, bolbData> > &croppingBlobs, std::vector<cv::Point> &remainingSource, std::vector<cv::Point> &remainingTarget_t){

		/* find nearest boundary */
		int shortI = Find_Boundary(boundImg, iPoint);

		/* crop */
		cv::Rect rect = Find_Rect(boundImg, iPoint, shortI);
		cv::Mat croppingImg = boundImg(rect).clone();

		/* shift */
		vector<cv::Point> _src = remainingSource;
		vector<cv::Point> _tar = remainingTarget_t;

		JC::shiftPoint(_src, rect.tl());
		JC::shiftPoint(_tar, rect.tl());

		/* find blobs */
		bolbData boundBlobs;
		boundBlobs.binary = croppingImg;
		vector<vector<cv::Point>> lostPoint;
		FindBlobs(boundBlobs, _src, _tar, lostPoint);
		boundBlobs.rect = rect;

		croppingBlobs.push_back(make_pair(boundBlobs.totalRatio,boundBlobs));

	}

	cv::Point getNearestBoundary(int ShortI, cv::Point &p, int &cols, int &rows){
		int r[4][2] = {
			{0, p.y}, // right
			{p.x, 0}, //up
			{cols, p.y}, //left
			{p.x, rows} //bottom
		};
		
		cv::Point b = cv::Point(r[ShortI][0], r[ShortI][1]);
		return b;
	}

	void CroppingProcess(std::vector<std::pair<float, HungarianType > > &candidate, std::string &fileName, CropType &cropData, int &idx){
		
		int rankSize = 5;

		if(candidate.size() < rankSize){
			rankSize = candidate.size();
		}

		
			HungarianType &Hdata = candidate[idx].second;
			ostringstream oss;
			oss<< idx <<"_size_"<<Hdata.size;
			
			int rWidth = Hdata.boundRect.br().x - Hdata.boundRect.tl().x;
			int rHeight = Hdata.boundRect.br().y - Hdata.boundRect.tl().y;
			cv::Mat boundImg(rHeight, rWidth , CV_8UC1, 1);	

			/* initial binary image */
			bolbData boundBlobs;
			cv::threshold(boundImg, boundBlobs.binary, 0.0, 1.0, cv::THRESH_BINARY);		
			boundBlobs.binary.convertTo(boundBlobs.binary, CV_32SC1);

			/* find source, target blob */
			vector<vector<cv::Point>> srcTarBlobs;
			srcTarBlobs.push_back( Hdata.compositeContour);
			srcTarBlobs.push_back( Hdata.target);

			vector<vector<cv::Point>> inner_srcTarBlobs;
			vector<vector<cv::Point>> inner_tarTarBlobs;
			for (int i =0; i < Hdata.inner_contours_src.size(); i++)
				inner_srcTarBlobs.push_back(Hdata.inner_contours_src[i]);
			for (int i =0; i < Hdata.inner_contours_tar.size(); i++)
				inner_tarTarBlobs.push_back(Hdata.inner_contours_tar[i]);

			cv::drawContours(boundBlobs.binary, srcTarBlobs, 0,  2, CV_FILLED);
			cv::drawContours(boundBlobs.binary, srcTarBlobs, 1,  3, CV_FILLED);
			cv::Mat binaryWithIni = boundBlobs.binary.clone();
			vector<vector<cv::Point>> lostPoint;
			FindBlobs(boundBlobs, Hdata.remainingSource, Hdata.remainingTarget_t, lostPoint);

			/* find the feature points */
			std::vector<cv::Point> approxPoly_contour;
			int approxPoly_level = 4;
			cv::approxPolyDP( cv::Mat(Hdata.outContour), approxPoly_contour, approxPoly_level, true );

			/* output */
// 			cv::Mat output = cv::Mat::zeros(boundImg.size(), CV_8UC3);
// 			ColorBolbs(output, boundBlobs);
// 			cv::drawContours(output, srcTarBlobs, 0,  cv::Scalar(0,0,0), CV_FILLED);
// 			cv::drawContours(output, srcTarBlobs, 1,  cv::Scalar(255,255,255), CV_FILLED);
// 
// 			/* output */
// 			string outd = "..//cropping//"+fileName+"d"+oss.str()+".png";
// 			cv::imwrite(outd, output);	
// 
// 			JC::drawContour(output, approxPoly_contour, cv::Scalar(255,0,0), 3,3);

			/* classify feature points */
			vector<vector<cv::Point>> appClassContour;
			appClassContour.resize(4);
			for(int j =0; j<approxPoly_contour.size(); j++){
				/* find nearest boundary */
				int shortI = Find_Boundary(boundImg, approxPoly_contour[j]);
				appClassContour[shortI].push_back(approxPoly_contour[j]);
			}
			
			vector<vector<cv::Point>> croppingPoints;
			croppingPoints.resize(4);
			
			/* output */
// 			string outc = "..//cropping//"+fileName+"c"+oss.str()+".png";
// 			cv::imwrite(outc, output);

			vector<int> checkBoundary;
			checkBoundary.resize(4,0);

			/* find cropping points */
			for(int j =0; j<lostPoint.size(); j++){
				
				/* find nearest boundary */
				for(int k =0 ; k<lostPoint[j].size(); k++){		
					int shortI = Find_Boundary(boundImg, lostPoint[j][k]);
					cv::Point p = getNearestBoundary(shortI, lostPoint[j][k], boundImg.cols, boundImg.rows);
//					cv::line(output, p, lostPoint[j][k], cv::Scalar(255,255,0), 1);
					if(checkBoundary[shortI] == 0){
						for(int n = 0; n < appClassContour[shortI].size(); n++){
							cv::Rect _r = FindClipRect(boundImg, appClassContour[shortI][n], shortI);
							int nInRect = numInRect(Hdata.outContour, _r);
							if (nInRect < lostPoint[j].size())
							{
								croppingPoints[shortI].push_back(appClassContour[shortI][n]);
								//std::cout << croppingPoints[shortI].size()<< std::endl;
								//cv::circle(output, appClassContour[shortI][n], 3, cv::Scalar(255,0,255), 3);
							}
						}
						checkBoundary[shortI] = 1;
					}
				}			
			}
			/* output */
// 			string outa = "..//cropping//"+fileName+"a"+oss.str()+".png";
// 			cv::imwrite(outa, output);

			vector<int> lockBoundary = checkBoundary;
			/* cropping feature points */
			std::vector<std::pair<float, bolbData > > croppingBlobs;
			for(int j = 0; j < croppingPoints.size() ; j++){
				for(int k =0; k< croppingPoints[j].size();k++ ){
					
					Find_CroppingBoundary(croppingPoints[j][k] ,binaryWithIni, croppingBlobs, Hdata.remainingSource, Hdata.remainingTarget_t);
					croppingBlobs[croppingBlobs.size()-1].second.boundary = j;
				}		
			}
			if(croppingBlobs.size() < 1){
				cv::Mat output3 = cv::Mat::zeros( boundImg.size(), CV_8UC3);
				ColorBolbs(output3, boundBlobs);	

				CropType _crop;
				_crop.cropMat = output3;
				_crop.hData = Hdata;
				_crop.rankIndex = idx;
				_crop.rect = Hdata.boundRect;

				float newCost = candidate[idx].first ;

				cropData = _crop;

			}else{
				/* heap? */

				sort(croppingBlobs.begin(), croppingBlobs.end(), compareLongestf);

				lockBoundary[croppingBlobs[0].second.boundary] = 0;
				cv::Mat output3 = cv::Mat::zeros(croppingBlobs[0].second.binary.size(), CV_8UC3);
				ColorBolbs(output3, croppingBlobs[0].second);	

				JC::shiftPoint(srcTarBlobs[0], croppingBlobs[0].second.rect.tl());
				JC::shiftPoint(srcTarBlobs[1], croppingBlobs[0].second.rect.tl());

				cv::drawContours(output3, srcTarBlobs, 1,  cv::Scalar(255,255,255), CV_FILLED);
				cv::drawContours(output3, srcTarBlobs, 0,  cv::Scalar(0,0,0), CV_FILLED);

				for (int i =0; i < Hdata.inner_contours_src.size(); i++)
					cv::drawContours(output3, inner_srcTarBlobs, i,  cv::Scalar(255,255,255), CV_FILLED);
				for (int i =0; i < Hdata.inner_contours_tar.size(); i++)
					cv::drawContours(output3, inner_tarTarBlobs, i,  cv::Scalar(0,0,0), CV_FILLED);

				int maxContour = croppingBlobs[0].second.totalRatio;
				if (boundBlobs.totalRatio>=croppingBlobs[0].second.totalRatio)
				{
					ostringstream oss3;
					oss3.str("");
					oss3 << "done";
					//cv::putText(output3, oss3.str(), cv::Point(10, 260), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 0, 255), 1);
					maxContour = boundBlobs.totalRatio;
				}


				//string out = "..//cropping//"+fileName+"b"+oss.str()+".png";
				//cv::imwrite(out, output3);

				float newCost = candidate[idx].first - croppingBlobs[0].second.totalRatio;

				CropType _crop;
				_crop.cropMat = output3;
				_crop.hData = Hdata;
				_crop.rankIndex = idx;
				_crop.rect = croppingBlobs[0].second.rect;

				cropData = _crop;
			}

	}

}

#endif