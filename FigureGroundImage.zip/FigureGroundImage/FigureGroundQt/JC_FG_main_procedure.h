#include "stdafx.h"
#include "JC_functions.h"
#include "JC_crop.h"
#include "JC_find_contour.h"
#include "JC_watched.h"
#include "JC_IS_Match.h"
#include "JC_find_transformation.h"
#include "JC_find_cluster.h"
#include "JC_find_hungarian.h"
#include "JC_svgParser.h"
#include "JC_findCropping.h"
#include <iostream>
#include <fstream>
#include <time.h>

#include <QThread>
#include <QProgressBar>
#ifndef _JC_MAIN_H_
#define _JC_MAIN_H_

class FG_procedure: public QThread {
	//Q_OBJECT

public:
	ContourType Figure_Contour;
	ContourType Ground_Contour;
	FG_Type *FG;
	int size;

	FG_procedure(ContourType _Figure_Contour, ContourType _Ground_Contour, FG_Type &_FG, int _size) {
		Figure_Contour = _Figure_Contour;
		Ground_Contour = _Ground_Contour;
		FG = &_FG;
		size = _size;
	}

protected:
	void run() {

		clock_t t1, t2;
		FG->run_time_IS_match = 0;
		FG->run_time_transformation = 0;
		FG->run_time_mean_shift = 0;
		FG->run_time_hungarian = 0;

		/* findPartialMatch */
		t1 = clock();
		IS_Match::findPartialMatch(Figure_Contour, Ground_Contour, FG->matchData);
		t2 = clock();
		FG->run_time_IS_match = (t2-t1)/(double)(CLOCKS_PER_SEC);	
		FG->size_IS_match = FG->matchData.size();

		/* find_transformation */
		t1 = clock();
		Transformation::find_transformation(FG->matchData, FG->transformedData);
		t2 = clock();
		FG->run_time_transformation = (t2-t1)/(double)(CLOCKS_PER_SEC);
		FG->size_transformation = FG->transformedData.size();

		

		if(FG->transformedData.size()>=5){
			/* findCluster */
			t1 = clock();
			Cluster::meanShift(FG->transformedData, FG->kmeans_data);
			t2 = clock();
			FG->run_time_mean_shift = (t2-t1)/(double)(CLOCKS_PER_SEC);
			FG->size_mean_shift = FG->kmeans_data.clusters.size();
		
			/* findHungarian */
			t1 = clock();
			Hungarian::findHungarian(FG, size, Ground_Contour.user_defined_index);
			t2 = clock();
			FG->run_time_hungarian = (t2-t1)/(double)(CLOCKS_PER_SEC);
			FG->size_hungarian = FG->HungarianData.size();
		}

	}


};


#endif