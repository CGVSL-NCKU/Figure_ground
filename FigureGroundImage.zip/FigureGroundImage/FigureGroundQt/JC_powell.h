#include "stdafx.h"
#ifndef _JC_DFPMIN_H_
#define _JC_DFPMIN_H_
#define _USE_MATH_DEFINES 
#include <math.h>
#include <algorithm>
#include <fstream>
#include "std.h"
#include "SchaeferMLS.h"
#include "CurveSignature.h"
#include "JC_type.h"
#include "JC_GaussianDistribution.h"
#include "JC_opt_function.h"
#include "..\nr3\nr3.h"
#include "..\nr3\ludcmp.h"
#include "..\nr3\qrdcmp.h"
#include "..\nr3\roots_multidim.h"
#include "..\nr3\mins_ndim.h"
#include "..\nr3\mins.h"
using namespace cv;
using namespace std;

namespace JC_powell{

	optType _optData;
	std::vector<cv::Point> &src = _optData.src;
	std::vector<cv::Point> &tar = _optData.tar;
	std::vector<cv::Point> &match_src = _optData.match_src;
	std::vector<cv::Point> &match_tar = _optData.match_tar;
	std::vector<float> &concave_src = _optData.concave_src;
	std::vector<float> &concave_tar = _optData.concave_tar;
	std::vector<int> &match_idx_src = _optData.match_idx_src;
	std::vector<int> &match_idx_tar = _optData.match_idx_tar;
	std::vector<int> &ctrl_idx_src = _optData.ctrl_idx_src; 
	std::vector<int> &ctrl_idx_tar = _optData.ctrl_idx_tar;
	std::vector<int> &ctrl_idx_def = _optData.ctrl_idx_def; 
	std::vector<int> &union_ctrl_src = _optData.union_ctrl_src; 
	std::vector<int> &union_ctrl_tar = _optData.union_ctrl_tar; 
	std::vector<int> &match_feature_idx_src = _optData.match_feature_idx_src;
	std::vector<int> &match_feature_idx_tar = _optData.match_feature_idx_tar;
	std::vector<int> &non_collision_match_idx_src = _optData.non_collision_match_idx_src;
	std::vector<int> &non_collision_match_idx_tar = _optData.non_collision_match_idx_tar;
	std::vector<int> &collide_idx_Src = _optData.collision_idx_src;
	std::vector<int> &collide_idx_Tar = _optData.collision_idx_tar;
	std::vector<cv::Point> match_pts_src;
	std::vector<cv::Point> match_pts_tar;
	HungarianType _Hdata;


	//for warp MLS
	vector<Point2d> src_p2d;
	vector<Point2d> tar_p2d;
	SchaeferMLS<double> smls_src;
	SchaeferMLS<double> smls_tar;
	Mat visualized_curve;
	//control state
	int addPoint;

	int warp_type_g;
	//////////////////////////////////////////////////////////////////////////


	const double Max = 9999999.0;
	SchaeferMLS<double> smls_def_src;
	vector<Point2d> def_p2d_src;
	SchaeferMLS<double> smls_def_tar;
	vector<Point2d> def_p2d_tar;

	cv::Scalar color_red(0,0,255);
	cv::Scalar color_green(0,255,0);
	cv::Scalar color_blue(255,0,0);

	cv::Scalar color_yellow(0,255,255);
	cv::Scalar color_lightBlue(255,255,0);
	cv::Scalar color_purple(255,0,255);

	cv::Scalar color_white(255,255,255);
	cv::Scalar color_black(0,0,0);

	float maxFloat = std::numeric_limits<float>::max();

	void find_feature_curve(std::vector<Point2d> &deformed_pts ,std::vector<int> &feature_idx, std::vector<double> &new_curve_value){

		std::vector< std::vector<int> > approxPoly_size;
		std::vector< float > approxPoly_angle;
		approxPoly_size.resize(feature_idx.size());
		approxPoly_angle.resize(feature_idx.size());
		for( int i =0; i < approxPoly_size.size(); i++){
			approxPoly_size[i].resize(feature_idx.size());			
		}

		/* calculate the size of feature points between the two points */
		for( int i =0; i < feature_idx.size(); i++){
			if((i+1)<feature_idx.size()){
				approxPoly_size[i][i+1] = approxPoly_size[i+1][i] = (feature_idx[i+1] - feature_idx[i] + deformed_pts.size())%deformed_pts.size();
			}else{
				approxPoly_size[i][0] = approxPoly_size[0][i] = (feature_idx[0] - feature_idx[i] + deformed_pts.size())%deformed_pts.size();
			}			
		}


		for (int i = 0; i < feature_idx.size(); i++){

			int featureSize = feature_idx.size();

			int mid = ( i + featureSize ) % featureSize ;
			int first = ( i + featureSize -1 ) % featureSize ;
			int last = ( i + featureSize +1 ) % featureSize ;

			CvPoint2D32f V1,V2;
			V1 = deformed_pts[feature_idx[first]] - deformed_pts[feature_idx[mid]];
			V2 = deformed_pts[feature_idx[last]] - deformed_pts[feature_idx[mid]] ;

			double norm1 , norm2, dotProduct ;

			float Array1[]={ V1.x, V1.y, 0 };
			float Array2[]={ V2.x, V2.y, 0 };
			CvMat* mat1 = cvCreateMat( 1, 3, CV_32FC1 );
			CvMat* mat2 = cvCreateMat( 1, 3, CV_32FC1 );
			CvMat* cross_result = cvCreateMat( 1, 3, CV_32FC1 );

			cvSetData(mat1,Array1,mat1->step);
			cvSetData(mat2,Array2,mat2->step);

			dotProduct = cvDotProduct ( mat1, mat2 );
			cvCrossProduct( mat1, mat2, cross_result );
			norm1 = cvNorm( mat1, NULL, CV_L2 );
			norm2 = cvNorm( mat2, NULL, CV_L2 );

			double theta = acos( dotProduct / ( norm1 * norm2) ) * 180 / 3.1415;

			if( cvGet2D(cross_result,0,2).val[0] < 0 ) { 
				approxPoly_angle[mid] =  -(180.0 - theta) / 180.0;
			}else{ // �w�� (<0)
				approxPoly_angle[mid] =  (180.0 - theta) / 180.0;
			}
		}

		new_curve_value.resize( deformed_pts.size() , 0 );
		for (int i = 0; i < feature_idx.size(); i++){

			int lastC = (i -1  + feature_idx.size())% feature_idx.size();
			int nextC = (i +1  + feature_idx.size())% feature_idx.size();

			for (int j = 0; j < approxPoly_size[lastC][i]/2 +1; j++)
			{
				int tempj =  (feature_idx[i] - j)% new_curve_value.size();
				double gaussian_input = 0.1 *(double)j;
				double return_transfer = Gaussian::GaussianTransfer(gaussian_input, 0, 0.4);
				new_curve_value[tempj] = return_transfer *  (float)approxPoly_angle[i];
			}

			for (int j = 0; j < approxPoly_size[i][nextC]/2 +1; j++)
			{
				int tempj =  (feature_idx[i] + j)% new_curve_value.size();
				double gaussian_input = 0.1 *(double)j;
				double return_transfer = Gaussian::GaussianTransfer(gaussian_input, 0, 0.4);
				new_curve_value[tempj] = return_transfer *  (float)approxPoly_angle[i];
			}
		}
	}

	std::vector<double> new_curve_value_src;
	std::vector<double> new_curve_value_tar;
	static int nfunc;

	struct Func {
		double operator ()(VecDoub_I & x) const
		{	

			nfunc++;
			double result_value = 0.0;

			//penalty
			// 			for(int i=0; i < 2; i++){
			// 				if(x[i] > 1 || x[i] < 0){
			// 					return Max;			
			// 				}
			// 			}

			//deform control points
			vector<Point2d> &ctrl_pts_src = smls_def_src.GetDeformedControlPts();
			vector<Point2d> &ctrl_pts_tar = smls_def_tar.GetDeformedControlPts();
			cv::Point2d estimatePoint_tar,estimatePoint_src;
			estimatePoint_tar =  Point2d(x[0],x[1]);
			estimatePoint_src =  Point2d(x[2],x[3]);
			ctrl_pts_src[1] = estimatePoint_src;
			ctrl_pts_tar[1] = estimatePoint_tar;
			//deform control points
			estimatePoint_tar =  Point2d(x[4],x[5]);
			estimatePoint_src =  Point2d(x[6],x[7]);
			ctrl_pts_src[0] = estimatePoint_src;
			ctrl_pts_tar[0] = estimatePoint_tar;

			//update MLS
			smls_def_src.UpdateRigid();
			smls_def_tar.UpdateRigid();

			vector<Point2d> deformed_ptsd_src =  smls_def_src.GetDeformedPts() ;
			vector<Point2d> deformed_ptsd_tar =  smls_def_tar.GetDeformedPts() ;
			//new concave-convex value
			find_feature_curve( deformed_ptsd_src , ctrl_idx_src, new_curve_value_src );
			find_feature_curve( deformed_ptsd_tar , ctrl_idx_tar, new_curve_value_tar );

			vector<Point> deformed_pts_src;
			ConvertCurve(deformed_ptsd_src, deformed_pts_src);
			vector<Point> deformed_pts_tar;
			ConvertCurve(deformed_ptsd_tar, deformed_pts_tar);

			for(int i =0; i < ctrl_idx_src.size(); i++){

				double curve_mtp, abs_difference;

				curve_mtp = concave_tar[ctrl_idx_tar[i]] * concave_src[ctrl_idx_src[i]];
				curve_mtp = Gaussian::GaussianTransfer(curve_mtp, -1, 0.4);
				//curve_mtp = 1;
				abs_difference = pow( norm(deformed_pts_src[ctrl_idx_src[i]] - deformed_pts_tar[ctrl_idx_tar[i]]), 2.0);

				result_value += curve_mtp*abs_difference;	
			}

			return result_value;
		}
	};

	void init_MLS(){
		//initial MLS
		ConvertCurve(tar, def_p2d_tar);
		ConvertCurve(src, def_p2d_src);

		smls_def_src.Init(def_p2d_src, union_ctrl_src);
		smls_def_src.UpdateRigid();

		smls_def_tar.Init(def_p2d_tar, union_ctrl_tar);
		smls_def_tar.UpdateRigid();
	}

	VecDoub init_nonPowell(){
		const int NDIM = 8; 
		VecDoub p(NDIM);
		Func func;
		Powell<Func> powell(func);
		int iter;
		nfunc = 0;

		//initial parameter
		p[0] = tar[ctrl_idx_tar[0]].x;  
		p[1] = tar[ctrl_idx_tar[0]].y;
		p[2] = src[ctrl_idx_src[0]].x; 
		p[3] = src[ctrl_idx_src[0]].y;
		p[4] = tar[ctrl_idx_tar[ctrl_idx_tar.size()-1]].x;  
		p[5] = tar[ctrl_idx_tar[ctrl_idx_tar.size()-1]].y;
		p[6] = src[ctrl_idx_src[ctrl_idx_src.size()-1]].x;  
		p[7] = src[ctrl_idx_src[ctrl_idx_src.size()-1]].y;

		return p;
	}

	VecDoub init_powell(){
		//powell	
		const int NDIM = 8; 
		VecDoub p(NDIM);
		Func func;
		Powell<Func> powell(func);
		int iter;
		nfunc = 0;

		//initial parameter
		p[0] = tar[ctrl_idx_tar[0]].x;  
		p[1] = tar[ctrl_idx_tar[0]].y;
		p[2] = src[ctrl_idx_src[0]].x; 
		p[3] = src[ctrl_idx_src[0]].y;
		p[4] = tar[ctrl_idx_tar[ctrl_idx_tar.size()-1]].x;  
		p[5] = tar[ctrl_idx_tar[ctrl_idx_tar.size()-1]].y;
		p[6] = src[ctrl_idx_src[ctrl_idx_src.size()-1]].x;  
		p[7] = src[ctrl_idx_src[ctrl_idx_src.size()-1]].y;
		p=powell.minimize(p);

		//output
		// 		for(int i=0; i < NDIM; i++)
		// 			std::cout << i << " : " << p[i] << std::endl;
		// 		cout << "Func value at solution = " <<scientific << powell.fret << endl << endl;
		// 		cout <<  noshowpos;
		// 		cout << "Number of Iterations   = " << setw(3) << iter << endl;
		// 		cout << "Number of Func evals   = " << setw(3) << nfunc << endl;

		return p;
	}

	class end_points{
		public:
			cv::Point2d front, back;
	};

	class match_remain_pts{
	public:
		vector<cv::Point> remaining_pts;
		vector<cv::Point> match_pts;
		vector<cv::Point> composite_pts;
		vector<int> match_idx;
	};

	end_points get_end_points(VecDoub &p){
		end_points _end_points;
		cv::Point2d estimatePoint_front, estimatePoint_back;
		int feature_size_src = match_feature_idx_src.size();
		int feature_size_tar = match_feature_idx_tar.size();
		if(feature_size_src > feature_size_tar){
			//cout<< "warp to src" << endl;
			estimatePoint_front =  Point2d(p[2],p[3]);
			estimatePoint_back  =  Point2d(p[6],p[7]);
		}else{
			//cout<< "warp to tar" << endl;
			estimatePoint_front =  Point2d(p[0],p[1]);
			estimatePoint_back  =  Point2d(p[4],p[5]);
		}

		_end_points.front = estimatePoint_front;
		_end_points.back = estimatePoint_back;

		return _end_points;
	}

	end_points get_end_points_source(VecDoub &p){
		end_points _end_points;
		cv::Point2d estimatePoint_front, estimatePoint_back;
		estimatePoint_front =  Point2d(p[2],p[3]);
		estimatePoint_back  =  Point2d(p[6],p[7]);	
		_end_points.front = estimatePoint_front;
		_end_points.back = estimatePoint_back;
		return _end_points;
	}

	end_points get_end_points_target(VecDoub &p){
		end_points _end_points;
		cv::Point2d estimatePoint_front, estimatePoint_back;
		estimatePoint_front =  Point2d(p[0],p[1]);
		estimatePoint_back  =  Point2d(p[4],p[5]);	
		_end_points.front = estimatePoint_front;
		_end_points.back = estimatePoint_back;
		return _end_points;
	}

	vector<Point> get_match_pts(match_remain_pts &src_pts, match_remain_pts &tar_pts){

		vector<Point> match_pts;
		int feature_size_src = match_feature_idx_src.size();
		int feature_size_tar = match_feature_idx_tar.size();

		if(feature_size_src > feature_size_tar)
			match_pts = src_pts.match_pts;
		else
			match_pts = tar_pts.match_pts;
		
		return match_pts;
	}

	void warp_together(VecDoub &p){

		vector<Point2d> &ctrl_pts_src = smls_def_src.GetDeformedControlPts();
		vector<Point2d> &ctrl_pts_tar = smls_def_tar.GetDeformedControlPts();
		//warp together
		ctrl_pts_src[1] = get_end_points(p).front;
		ctrl_pts_tar[1] = get_end_points(p).front;
		ctrl_pts_src[0] = get_end_points(p).back;
		ctrl_pts_tar[0] = get_end_points(p).back;
	}

	vector<vector<Point> > get_warped_pts(){
		vector<vector<Point> > warped_pts;
		vector<Point2d> warped_pts_tar_t = smls_def_tar.GetDeformedPts() ;
		vector<Point2d> warped_pts_src_t = smls_def_src.GetDeformedPts() ;
		vector<Point> warped_pts_tar_i;
		vector<Point> warped_pts_src_i;
		ConvertCurve(warped_pts_tar_t, warped_pts_tar_i);
		ConvertCurve(warped_pts_src_t, warped_pts_src_i);
		warped_pts.push_back(warped_pts_tar_i);
		warped_pts.push_back(warped_pts_src_i);
		return warped_pts;
	};

	vector<vector<Point> > get_warped_pts_edit(){
		vector<vector<Point> > warped_pts;
		vector<Point2d> warped_pts_tar_t = smls_tar.GetDeformedPts() ;
		vector<Point2d> warped_pts_src_t = smls_src.GetDeformedPts() ;
		vector<Point> warped_pts_tar_i;
		vector<Point> warped_pts_src_i;
		ConvertCurve(warped_pts_tar_t, warped_pts_tar_i);
		ConvertCurve(warped_pts_src_t, warped_pts_src_i);
		warped_pts.push_back(warped_pts_tar_i);
		warped_pts.push_back(warped_pts_src_i);
		return warped_pts;
	};

	match_remain_pts get_remaining_pts(std::vector<cv::Point> &contour, std::vector<cv::Point> &contour2, std::vector<int> &non_collision_match_idx, std::vector<int> &match_idx, std::vector<int> &match_idx2, int warp_type, int now_type){

		if (warp_type==2) warp_type = 1;
		match_remain_pts return_pts;
		std::vector<int>::iterator it_front =  find(match_idx.begin(), match_idx.end(), non_collision_match_idx.front());
		std::vector<int>::iterator it_back  =  find(match_idx.begin(), match_idx.end(), non_collision_match_idx.back());
		//find the collision front & back in the match idx
		int non_collision_idx_front = std::distance(match_idx.begin(), it_front);
		int non_collision_idx_back = std::distance(match_idx.begin(), it_back);

		std::vector<int> match_idx_temp; 

		for(int i=0; i<contour.size(); i++){

			std::vector<int>::iterator it = find(non_collision_match_idx.begin(), non_collision_match_idx.end(), i);
			std::vector<int>::iterator it_match_idx = find(match_idx.begin(), match_idx.end(), i);
			int match_idx_dist = std::distance(match_idx.begin(), it_match_idx);
			//i != non_collision_match_idx
			if( (it==non_collision_match_idx.end()) ){

				std::vector<int>::iterator it_match = find(match_idx.begin(), match_idx.end(), i);
				if(it_match!=match_idx.end()){
					int i_to_match_idx = std::distance(match_idx.begin(), it_match);
					bool is_mid = JC_OPT::is_mid_pt(i_to_match_idx, non_collision_idx_front, non_collision_idx_back);

					if(is_mid==true){
						return_pts.match_pts.push_back(contour[i]);
						match_idx_temp.push_back(i);

						if (warp_type==now_type){
							return_pts.composite_pts.push_back(contour[match_idx[match_idx_dist]]);
						}
						else{
							return_pts.composite_pts.push_back(contour2[match_idx2[match_idx_dist]]);
						}
							

						continue;
					}
				}
				return_pts.remaining_pts.push_back(contour[i]);	
				return_pts.composite_pts.push_back(contour[i]);
			}else{
				match_idx_temp.push_back(i);
				return_pts.match_pts.push_back(contour[i]);

				if (warp_type==now_type){
					return_pts.composite_pts.push_back(contour[match_idx[match_idx_dist]]);
				}
					
				else{
					return_pts.composite_pts.push_back(contour2[match_idx2[match_idx_dist]]);
				}
			}
							
		}

		for (int i =0; i < match_idx.size(); i++){
			std::vector<int>::iterator it = find(match_idx_temp.begin(), match_idx_temp.end(), match_idx[i]);
			if (it!=match_idx_temp.end())
			{
				return_pts.match_idx.push_back(match_idx[i]);
			}
		}





		return return_pts;
	}

	vector<cv::Point> get_append_contour(std::vector<cv::Point> &contour, std::vector<cv::Point> &contour2){
		std::vector<cv::Point> _contour = contour;
		_contour.insert(_contour.begin(), contour2.begin(), contour2.end());
		return _contour;
	}

	void shiftPts(HungarianType &Hdata){
		cv::Rect boundRect;
		boundRect = boundingRect( cv::Mat(Hdata.twoContour) );
		cv::Point shiftP = boundRect.tl() - cv::Point(0,0); 
		JC::shiftPoint(Hdata.source, shiftP);
		for (int i =0; i < Hdata.inner_contours_src.size(); i++)
			JC::shiftPoint(Hdata.inner_contours_src[i], shiftP);
		for (int i =0; i < Hdata.inner_contours_tar.size(); i++)
			JC::shiftPoint(Hdata.inner_contours_tar[i], shiftP);
		JC::shiftPoint(Hdata.remainingSource, shiftP);
		JC::shiftPoint(Hdata.target, shiftP);
		JC::shiftPoint(Hdata.match_src, shiftP);
		JC::shiftPoint(Hdata.match_tar, shiftP);
		JC::shiftPoint(Hdata.compositeContour, shiftP);
		JC::shiftPoint(Hdata.compositeContour_tar, shiftP);
		JC::shiftPoint(Hdata.remainingTarget_t, shiftP);
		JC::shiftPoint(Hdata.twoContour, shiftP);
		JC::shiftPoint(Hdata.outContour, shiftP);
		JC::shiftPoint(Hdata.match_src_feature, shiftP);
		JC::shiftPoint(Hdata.match_tar_feature, shiftP);
		Hdata.boundRect_shift = boundRect; 
		boundRect = boundingRect( cv::Mat(Hdata.twoContour) );
		Hdata.boundRect = boundRect;
	}

	void warp_to_source(){

	}

	void MLSUpdate(HungarianType &Hdata) {
		static int framenum = 0;

		smls_src.UpdateRigid();
		smls_tar.UpdateRigid();


		vector<Point2d> deformed_tar =  smls_tar.GetDeformedPts() ;
		vector<Point2d> deformed_src =  smls_src.GetDeformedPts() ;

		visualized_curve.setTo(0);
		smls_src.DrawCurve_ex_match(visualized_curve, cv::Scalar(255,0,255), Hdata.nSelf_match_idx_src);
		smls_tar.DrawCurve_ex_match(visualized_curve, cv::Scalar(255,255,0), Hdata.nSelf_match_idx_tar);

		if(warp_type_g == 1){
			for(int i =0; i < Hdata.nSelf_match_idx_src.size()-1; i++)
				cv::line(visualized_curve, deformed_src[Hdata.nSelf_match_idx_src[i]], deformed_src[Hdata.nSelf_match_idx_src[i+1]], color_red, 2);	
		}else{
			for(int i =0; i < Hdata.nSelf_match_idx_tar.size()-1; i++)
				cv::line(visualized_curve, deformed_tar[Hdata.nSelf_match_idx_tar[i]], deformed_tar[Hdata.nSelf_match_idx_tar[i+1]], color_red, 2);			
		}

		smls_src.DrawControl(visualized_curve, cv::Scalar(0,255,255));
		smls_tar.DrawControl(visualized_curve, cv::Scalar(0,255,0));
		

		//imshow("MLS", visualized_curve);


		waitKey(1);			
	}	

	void onMouse( int event, int x, int y, int flags, void* )
	{
		static Point2d start_touch(-1,-1);
		static Point2d last_touch(-1,-1);
		static int touch_control_point = -1;

		static int touch_curve_point = -1;
		static int touch_curve =0;

		Point2d touch(x,y);
		if( event == CV_EVENT_LBUTTONDOWN ) {
			//		cout << "mouse down\n";
			start_touch = last_touch = touch;
			double minDist = 99999;
			const vector<Point2d>& ctrl_pts_src = smls_src.GetDeformedControlPts();
			const vector<Point2d>& ctrl_pts_tar = smls_tar.GetDeformedControlPts();
			for (int i=0; i<ctrl_pts_src.size(); i++) {
				double tempDist = norm(touch - ctrl_pts_src[i]);
				if ((tempDist < minDist) && tempDist<10) {
					//touching point i
					minDist = tempDist;
					touch_control_point = i;
					touch_curve = 0;
				}
			}
			for (int i=0; i<ctrl_pts_tar.size(); i++) {
				double tempDist = norm(touch - ctrl_pts_tar[i]);
				if ((tempDist < minDist) && tempDist<10) {
					//touching point i
					minDist = tempDist;
					touch_control_point = i;
					touch_curve = 1;
				}
			}

			if (touch_control_point >= 0) {
				cout << "selected point " << touch_control_point << endl;
			}
		}else if( event == CV_EVENT_LBUTTONUP ) {

			touch_control_point = -1;	
			touch_curve_point = -1;

		} // left drag 
		else if (event == CV_EVENT_MOUSEMOVE && flags == CV_EVENT_FLAG_LBUTTON) {
			static int touch_control_point_tar = -1;
			static int touch_control_point_src = -1;
			if (touch_control_point >= 0) {
				//source
				if(touch_curve == 0){
					std::vector<int>::iterator it =  find(ctrl_idx_src.begin(), ctrl_idx_src.end(), _Hdata.ctrl_idx_src_warp[touch_control_point]);
					if (it!=ctrl_idx_src.end())
					{
						vector<Point2d>& def_ctrl_pts_tar = smls_tar.GetDeformedControlPts();
						vector<Point2d>& def_ctrl_pts = smls_src.GetDeformedControlPts();
							
						double minDist = 99999;
						for (int i=0; i<def_ctrl_pts_tar.size(); i++) {
							double tempDist = norm(def_ctrl_pts[touch_control_point] - def_ctrl_pts_tar[i]);
							if ((tempDist < minDist) && tempDist<10) {
								//touching point i
								minDist = tempDist;
								touch_control_point_tar = i;
							}
						}

						def_ctrl_pts_tar[touch_control_point_tar] += touch - last_touch;	
						def_ctrl_pts[touch_control_point] += touch - last_touch;
						last_touch = touch;
						
					}
									
				}else{
					std::vector<int>::iterator it =  find(ctrl_idx_tar.begin(), ctrl_idx_tar.end(), _Hdata.ctrl_idx_tar_warp[touch_control_point]);
					if (it!=ctrl_idx_tar.end())
					{
						vector<Point2d>& def_ctrl_pts_src = smls_src.GetDeformedControlPts();
						vector<Point2d>& def_ctrl_pts = smls_tar.GetDeformedControlPts();

						double minDist = 99999;
						for (int i=0; i<def_ctrl_pts_src.size(); i++) {
							double tempDist = norm(def_ctrl_pts[touch_control_point] - def_ctrl_pts_src[i]);
							if ((tempDist < minDist) && tempDist<10) {
								//touching point i
								minDist = tempDist;
								touch_control_point_src = i;
							}
						}	

						def_ctrl_pts_src[touch_control_point_src] += touch - last_touch;	
						def_ctrl_pts[touch_control_point] += touch - last_touch;
						last_touch = touch;
					}
				}		

				MLSUpdate(_Hdata);
			}
		}

	}

	void edit_warp(HungarianType &Hdata, int warp_type){
		warp_type_g = warp_type;
		ConvertCurve(Hdata.compositeContour_tar, tar_p2d);
		ConvertCurve(Hdata.compositeContour, src_p2d);

		std::cout << "Hdata.ctrl_idx_src_warp "<<Hdata.ctrl_idx_src_warp.size() << std::endl;
		std::cout << "Hdata.ctrl_idx_tar_warp "<<Hdata.ctrl_idx_tar_warp.size() << std::endl;

		smls_src.Init(src_p2d, Hdata.ctrl_idx_src_warp);
		smls_src.UpdateRigid();
		smls_tar.Init(tar_p2d, Hdata.ctrl_idx_tar_warp);
		smls_tar.UpdateRigid();

		int rWidth = Hdata.boundRect.br().x - Hdata.boundRect.tl().x;
		int rHeight = Hdata.boundRect.br().y - Hdata.boundRect.tl().y;

		visualized_curve.create( rHeight, rWidth, CV_8UC3);
		visualized_curve.setTo(0);
		_Hdata = Hdata;
		MLSUpdate(Hdata);

		addPoint = 0;

		bool loop = true;
		while(loop){
			int key = cv::waitKey(1);
			if(key==13){
				vector<vector<Point> > warped_pts = get_warped_pts_edit();

				match_remain_pts src_pts = get_remaining_pts(warped_pts[1], warped_pts[0], non_collision_match_idx_src, match_idx_src, match_idx_tar, warp_type, 0);
				match_remain_pts tar_pts = get_remaining_pts(warped_pts[0], warped_pts[1], non_collision_match_idx_tar, match_idx_tar, match_idx_src, warp_type, 1);

				Hdata.source = warped_pts[1];
				Hdata.target = warped_pts[0];
				Hdata.compositeContour = src_pts.composite_pts;
				Hdata.compositeContour_tar = tar_pts.composite_pts;
				Hdata.remainingSource = src_pts.remaining_pts;
				Hdata.remainingTarget_t = tar_pts.remaining_pts;
				Hdata.outContour = get_append_contour(tar_pts.remaining_pts, src_pts.remaining_pts);
				Hdata.twoContour = get_append_contour(Hdata.source, Hdata.target);
				Hdata.union_ctrl_src = _optData.union_ctrl_src;
				Hdata.union_ctrl_tar = _optData.union_ctrl_tar;
				Hdata.ctrl_idx_src_warp = _optData.union_ctrl_src_warp;
				Hdata.ctrl_idx_tar_warp = _optData.union_ctrl_tar_warp;
				Hdata.nSelf_match_idx_src = src_pts.match_idx;
				Hdata.nSelf_match_idx_tar = tar_pts.match_idx;

				shiftPts(Hdata);
				cv::Mat warpImg(800, 800, CV_8UC3);
				JC::drawContour(warpImg, Hdata.compositeContour, color_green, 2, 2);
/*				t1 = clock();*/
				ostringstream oss;
				oss << src_pts.composite_pts.size() << "_" <<0 ;

// 				imwrite("../warped/"+oss.str()+".png", warpImg);
// 				char* nameb1 = "button1";
// 				char* nameb2 = "button2";
// 				cvCreateButton(nameb1,callbackButton,nameb1,CV_CHECKBOX,1);

				loop = false;
				break;
			}
			namedWindow("warping editing");
			setMouseCallback("warping editing", onMouse, NULL);

			imshow("warping editing", visualized_curve);
		}
		destroyWindow("warping editing");
		waitKey();

	}

	void get_powell(optType &optData, int warp_idx, HungarianType &Hdata, int warp_type){
		warp_type_g = warp_type;
		_optData = optData;

		init_MLS();
		VecDoub p;

		switch (warp_type)
		{
		case 0:
			p = init_powell();
			get_end_points(p);
			
			break;

		case 1:
			p = init_nonPowell();
			get_end_points_source(p);
			break;

		case 2:
			p = init_nonPowell();
			get_end_points_target(p);
			break;

		default:
			p = init_nonPowell();
			get_end_points_target(p);
			break;
		}
		
		warp_together(p);

		cv::Mat warpImg(800, 800, CV_8UC3);

		//draw before deform
		smls_def_tar.DrawCurve(warpImg, color_red);
		smls_def_src.DrawCurve(warpImg, color_green);

		//deform 
		smls_def_src.UpdateRigid();
		smls_def_tar.UpdateRigid();

 		vector<vector<Point> > warped_pts = get_warped_pts();
// 
// 		smls_def_tar.DrawCurve(warpImg, color_lightBlue);
// 		smls_def_tar.DrawControl(warpImg, color_red);
// 		smls_def_src.DrawCurve(warpImg, color_purple);
// 		smls_def_src.DrawControl(warpImg, color_yellow);
// 
// 		JC::drawContour(warpImg, Hdata.match_tar, color_blue, 2, 2);
	
		match_remain_pts src_pts = get_remaining_pts(warped_pts[1], warped_pts[0], non_collision_match_idx_src, match_idx_src, match_idx_tar, warp_type, 0);
		match_remain_pts tar_pts = get_remaining_pts(warped_pts[0], warped_pts[1], non_collision_match_idx_tar, match_idx_tar, match_idx_src, warp_type ,1);

		ostringstream oss;
		oss << optData.src.size() << "_" <<warp_idx ;

		warpImg.setTo(color_white);
		// 		JC::drawLineContour(warpImg, Hdata.compositeContour, color_black,  3);
		// 		JC::drawLineContour(warpImg, Hdata.compositeContour_tar, color_blue,   3);
		JC::drawLineContourN(warpImg, Hdata.source, color_black,   2);
		JC::drawLineContourN(warpImg, Hdata.target, color_black,  2);
		JC::drawLineContour_idx(warpImg, Hdata.source ,Hdata.match_index_src, color_black,   2);
		JC::drawLineContour_idx(warpImg, Hdata.target ,Hdata.match_index_tar, color_black,  2);

		imwrite("../warped/"+oss.str()+"before.png", warpImg);

		Hdata.source = warped_pts[1];
		Hdata.target = warped_pts[0];
 		Hdata.compositeContour = src_pts.composite_pts;
		Hdata.compositeContour_tar = tar_pts.composite_pts;
		Hdata.remainingSource = src_pts.remaining_pts;
		Hdata.remainingTarget_t = tar_pts.remaining_pts;
 		Hdata.outContour = get_append_contour(tar_pts.remaining_pts, src_pts.remaining_pts);
		Hdata.twoContour = get_append_contour(Hdata.source, Hdata.target);
		Hdata.union_ctrl_src = _optData.union_ctrl_src;
		Hdata.union_ctrl_tar = _optData.union_ctrl_tar;
		Hdata.ctrl_idx_src_warp = _optData.union_ctrl_src_warp;
		Hdata.ctrl_idx_tar_warp = _optData.union_ctrl_tar_warp;
		Hdata.nSelf_match_idx_src = src_pts.match_idx;
		Hdata.nSelf_match_idx_tar = tar_pts.match_idx;
	
		shiftPts(Hdata);



/*		JC::drawContour(warpImg, Hdata.remainingSource, color_blue, 2, 2);*/
// 		JC::drawContour(warpImg, Hdata.compositeContour_tar, color_blue, 2, 2);
// 		imwrite("../warped/"+oss.str()+"_tar.png", warpImg);
		
		warpImg.setTo(color_white);

		JC::drawLineContour(warpImg, Hdata.compositeContour, color_black,  2);
		JC::drawLineContour(warpImg, Hdata.compositeContour_tar, color_black,   2);
		
		imwrite("../warped/"+oss.str()+"2.png", warpImg);
		warpImg.setTo(color_white);
// 		JC::drawLineContour(warpImg, Hdata.compositeContour, color_black,  3);
// 		JC::drawLineContour(warpImg, Hdata.compositeContour_tar, color_blue,   3);
 		JC::drawLineContour(warpImg, Hdata.source, color_black, 3);
 		JC::drawLineContour(warpImg, Hdata.target, color_blue, 3);
		JC::drawLineContour_idx( warpImg, Hdata.source, Hdata.nSelf_match_idx_src, color_purple, 3 );
		JC::drawLineContour_idx( warpImg, Hdata.target, Hdata.nSelf_match_idx_tar, color_lightBlue, 3 );

		imwrite("../warped/"+oss.str()+".png", warpImg);


	}



}
#endif