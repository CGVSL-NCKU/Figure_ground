#include "stdafx.h"
#include "JC_type.h"
#ifndef _JC_EDIT_H_
#define _JC_EDIT_H_

namespace JC_window_editing{
	using namespace cv;
	IplImage* Imagex;//original
	IplImage* Image;//modified
	CvPoint VertexOne,VertexThree;//����Ϊ����W�I�M�k�U�I
	CvScalar Color;//�خ��C��
	int Thickness;//�خزʲ�
	int Shift;//�خؤj�p(0�����`)
	int key;//����X
	int endDrag = 0;
	Rect input_rect;
	int edit_v = -1;
	int border = 6;
	//x1,y1---x3,y1 -> 0
	//x1,y1---x1,y3 -> 1

	void onMouse(int event,int x,int y,int flag,void* param){
		// 	printf("( %d, %d) ",x,y);
		// 	printf("The Event is : %d ",event);
		// 	printf("The flags is : %d ",flag);
		// 	printf("The param is : %d\n",param);
		// 	cout << "ed " << endDrag << endl;
		if(event==CV_EVENT_LBUTTONDOWN||event==CV_EVENT_RBUTTONDOWN){//�o�쥪�W���y��
			//VertexOne=cvPoint(x,y);
			if (x > VertexThree.x-border && x < VertexThree.x+border &&  y >= VertexOne.y && y <= VertexThree.y)
				edit_v = 3;
			if (x >= VertexOne.x && x <= VertexThree.x &&  y > VertexOne.y-border && y < VertexOne.y+border)
				edit_v = 0;
			if (x > VertexOne.x-border && x < VertexOne.x+border &&  y >= VertexOne.y && y <= VertexThree.y)
				edit_v = 1;
			if (x >= VertexOne.x && x <= VertexThree.x &&  y > VertexThree.y-border && y < VertexThree.y+border)
				edit_v = 2;

		}
		if(event==CV_EVENT_LBUTTONUP||event==CV_EVENT_RBUTTONUP){//�o��k�U���y��
			//VertexThree=cvPoint(x,y);
			endDrag = 1;
			edit_v = -1;
		}
		if(flag==CV_EVENT_FLAG_LBUTTON||flag==CV_EVENT_FLAG_RBUTTON){//�즲�ƹ�
		
			switch(edit_v){
				case 0:
					if(y < VertexThree.y && y >= 0)
						VertexOne.y = y;
					break;
				case 1:
					if(x < VertexThree.x && x >= 0)
						VertexOne.x = x;
					break;
				case 2:
					if(y < Image->height && y >= VertexOne.y)
						VertexThree.y = y;
					break;
				case 3:
					if(x < Image->width && y >= VertexOne.x)
						VertexThree.x = x;
					break;
			}
			cvReleaseImage(&Image);//�p�G�S�����ܡA�O����|�ɺ�
			Image = cvCloneImage(Imagex);//cvCopy(Imagex, Image, 0);
			cvRectangle(Image,VertexOne,VertexThree,Color,Thickness,CV_AA,Shift);
			cvShowImage("Modified",Image);
		}
// 		 	printf("VertexOne( %d, %d) ",VertexOne.x,VertexOne.y);
// 		 	printf("VertexThree( %d, %d)\n",VertexThree.x,VertexThree.y);
	}

	void cropping(Mat &mat_image, Point &vOne, Point &vThree, Rect &rect){

		input_rect = rect;
		Imagex= cvCloneImage(&(IplImage)mat_image);
		Image = cvCloneImage(Imagex);
		
		VertexOne = rect.tl();
		VertexThree = rect.br();
		Color = CV_RGB(0,255,0);
		Thickness = 4;
		Shift = 0;
		key = 0;
		cvRectangle(Image,VertexOne,VertexThree,Color,Thickness,CV_AA,Shift);
		cvNamedWindow("Modified",0);
		cvResizeWindow("Modified",mat_image.cols+15,mat_image.rows+15);
		cvSetMouseCallback("Modified",onMouse,NULL);//�]�w�ƹ�callback�禡

		cvShowImage("Modified", Image);

		while(true){
			int key = cv::waitKey(1);
			if(key==13){
				if(endDrag == 1)
					break;
			}
		}
		cvDestroyWindow("Modified");

		if (VertexOne.x < 0) VertexOne.x = 0;
		if (VertexOne.x > mat_image.cols) VertexOne.x = mat_image.cols;
		if (VertexThree.x < 0) VertexThree.x = 0;
		if (VertexThree.x > mat_image.cols) VertexThree.x = mat_image.cols;
		if (VertexOne.y < 0) VertexOne.y = 0;
		if (VertexOne.y > mat_image.rows) VertexOne.y = mat_image.rows;
		if (VertexThree.y < 0) VertexThree.y = 0;
		if (VertexThree.y > mat_image.rows) VertexThree.y = mat_image.rows;

		vOne = Point(VertexOne.x, VertexOne.y);
		vThree = Point(VertexThree.x, VertexThree.y);

	}
		

}

#endif