#include "stdafx.h"
#ifndef __ivManipulation__Utils_Ocv__
#define __ivManipulation__Utils_Ocv__

class Utils_Ocv {
private:
    cv::Mat colormap;
    
private:
    Utils_Ocv();
    ~Utils_Ocv(){}
    Utils_Ocv(const Utils_Ocv &);
	Utils_Ocv& operator=(const Utils_Ocv&);
	static Utils_Ocv inst;

public:
    static Utils_Ocv& instance(){return inst;}
    
    //get color
    void getColor( cv::Vec3b &color, int value,
                  int maxValue, int minValue );
    
 
};
#endif /* defined(__ivManipulation__Utils_Ocv__) */
