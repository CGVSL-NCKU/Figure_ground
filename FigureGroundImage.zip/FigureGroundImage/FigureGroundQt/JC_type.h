#include "stdafx.h"
#ifndef _JC_TYPE_H_
#define _JC_TYPE_H_


struct Descriptor{	
	std::vector<std::vector<int> > matrix;
};

struct curPos{
	float x;
	float y;
};

struct endPoint{
	int first;
	float x;
	float y;
	char type;
	int ctl_size;
	int ctl_idx[2];
};
struct ctlPoint{
	float x;
	float y;
};

class TransformedType{
public:
	cv::Mat transformed_matrix;
	float translate_x;
	float translate_y;
	float add_x;
	float add_y;
	float theta;
	float cos_theta;
};

class ContourType{
public:
	std::vector<cv::Point> contour;
	std::vector< std::vector<cv::Point> > inner_contours;
	std::vector<cv::Point> feature_contour;
	std::vector<int> feature_index_contour;
	std::vector<float> curve_contour;

	/* find_transformation */
	std::vector<cv::Point> contour_t;

	std::vector<int> user_defined_index;
	std::vector<cv::Point> IS_contour;

	std::vector <endPoint> endPoints;
	std::vector <ctlPoint> ctlPoints;

	std::string fileName;
};

class MatchType{
public:

	/* IS_Match */
	std::vector<cv::Point> match_source;
	std::vector<cv::Point> match_target;
	std::vector<int> match_index_source;
	std::vector<int> match_index_target;
	std::vector<cv::Point> match_IS_source;
	std::vector<cv::Point> match_IS_target;
	std::vector<int>	   match_IS_index_source;
	std::vector<int>	   match_IS_index_target;
	std::vector<cv::Point> interested_IS_target;
	std::vector<int>	   interested_IS_index_target;
	std::vector<cv::Point> remaining_source;
	std::vector<cv::Point>  FG_contour;
	int match_IS_length;
	double IS_cost;
	float interested_IS_ratio;
	float match_source_ratio;

	/* find_transformation */
	std::vector<cv::Point> transformed_match_target;
	std::vector<cv::Point> transformed_match_IS_target;
	std::vector<cv::Point> transformed_interested_IS_target;
	TransformedType transformData;

	std::vector<int> IS_idx_src;
	std::vector<int> IS_idx_tar;

	ContourType source;
	ContourType target;

	/* clustering */
	int length3d;

		/* find_hungarian */
	float cost_dist;
	float cost_interested;
	float cost_length;;
	
};


class clusterType
{
public:
	std::vector<std::vector<MatchType> > clusters;
	double  mean;
	double  stddev;
};

class HungarianType{

public:

	int size;
	double distCost;
	double orientationCost;
	double lengthCost;
	double tarlengthCost;
	double curveSourceCost;
	double curveTargetCost;
	double curveSum;
	double curveMSum;
	double curveAbsSrc;
	double curveAbsTar;
	double curveAbsSum;
	double curveAbsAve;
	double curveRatio;
	double totalCost;

	std::vector<std::vector<int> > countNum;
	std::vector<std::vector<double> > cost;
	std::vector<int> count;
	std::vector<int> list_src;
	std::vector<int> list_tar;

	cv::Mat averageMatrix;
	float addx;
	float addy;
	std::vector<int> srcToTar;
	std::vector<int> tarToSrc;

	std::vector<float> curveSource;
	std::vector<float> curveTarget;

	std::vector<cv::Point> source;
	std::vector< std::vector<cv::Point> > inner_contours_src;
	std::vector<cv::Point> target; //transformed
	std::vector< std::vector<cv::Point> > inner_contours_tar;
	std::vector<cv::Point> oriTarget;

	//  [12/30/2014 jolly]
	int interested_length;
	std::vector<cv::Point> interested_target;
	std::vector<int> interested_IS_index_target;

	int featureNumSrc;
	int featureNumTar;
	std::vector<cv::Point> match_src_feature;
	std::vector<cv::Point> match_tar_feature;
	std::vector<int> feature_index_src;
	std::vector<int> feature_index_tar;
	std::vector<cv::Point> match_src;
	std::vector<cv::Point> match_tar;
	std::vector<int> match_index_src;
	std::vector<int> match_index_tar;

	std::vector<cv::Point> compositeContour;
	std::vector<cv::Point> compositeContour_tar;
	std::vector<cv::Point> remainingTarget_t;
	std::vector<cv::Point> remainingSource;
	std::vector<cv::Point> twoContour;
	std::vector<cv::Point> outContour;

	//  [4/8/2015 jollytrees]
	std::vector<int> IS_idx_src;
	std::vector<int> IS_idx_tar;

	//non intersection
	std::vector<int> nSelf_match_idx_src;
	std::vector<int> nSelf_match_idx_tar;

	cv::Rect boundRect;
	cv::Rect boundRect_shift;

	cv::Mat rankMat;

	//for powel;
	std::vector<int> union_ctrl_src;
	std::vector<int> union_ctrl_tar;
	std::vector<int> ctrl_idx_src_warp; 
	std::vector<int> ctrl_idx_tar_warp;

};

class FG_Type{
public:
	ContourType Figure_Contour;
	ContourType Ground_Contour;

	std::vector<MatchType> matchData;
	std::vector<MatchType> transformedData;
	clusterType kmeans_data;
	std::vector<std::pair<float, int > > rank;
	std::vector<HungarianType> HungarianData;
	std::vector<std::pair<float, HungarianType > > candidate;

	double run_time_IS_match;
	double run_time_transformation;
	double run_time_mean_shift;
	double run_time_hungarian;
	int size_IS_match;
	int size_transformation;
	int size_mean_shift;
	int size_hungarian;
	

	double w_length;
	double w_orientation;
	double w_deformation;
	double w_convexity;

	void setWeight(
		double _length,
		double _orientation,
		double _deformation,
		double _convexity){
			w_length = _length;
			w_orientation = _orientation;
			w_deformation = _deformation;
			w_convexity = _convexity;
	}

};

class IS_Type{

public:
	/* PartialMatch : Initial the contour of Partial Match. */
	std::vector<cv::Point> IS_contour_source;
	std::vector<cv::Point> IS_contour_target;
	std::vector<int> IS_ist_index_tar;
	std::vector<int> IS_ist_index_src;
	/* initDescriptor */
	std::vector<Descriptor> descriptor_source;
	std::vector<Descriptor> descriptor_target;

	//  [4/8/2015 jollytrees]
	std::vector<int> IS_idx_src;
	std::vector<int> IS_idx_tar;

	/* initDiffMatrix */
	std::vector<Descriptor > descriptor_diff;

	/* initCostMatrix */
	std::vector<std::vector<double> > cost_matrix;
};


class CropType{
public:
	HungarianType hData;
	int rankIndex;
	cv::Mat cropMat;
	cv::Rect rect;
};

class FileType{
public:
	std::string pathF;
	std::string pathG;
	std::string nameF;
	std::string nameG;
	std::string extF;
	std::string extG;
};

class optType{
public:

	std::vector<cv::Point> src;
	std::vector<cv::Point> tar;
	std::vector<cv::Point> match_src;
	std::vector<cv::Point> match_tar;
	std::vector<float> concave_src;
	std::vector<float> concave_tar;
	std::vector<int> feature_idx_src;
	std::vector<int> feature_idx_tar;
	std::vector<int> match_idx_src; 
	std::vector<int> match_idx_tar;
	std::vector<int> match_feature_idx_src; 
	std::vector<int> match_feature_idx_tar;
	std::vector<int> ctrl_idx_src; 
	std::vector<int> ctrl_idx_tar;
	std::vector<int> ctrl_idx_def; 
	std::vector<int> MLS_ctrl_src;
	std::vector<int> MLS_ctrl_tar;
	std::vector<int> union_ctrl_src;
	std::vector<int> union_ctrl_tar;
	std::vector<int> non_collision_match_idx_src;
	std::vector<int> non_collision_match_idx_tar;
	std::vector<int> collision_idx_src;
	std::vector<int> collision_idx_tar;
	std::vector<int> union_ctrl_src_warp;
	std::vector<int> union_ctrl_tar_warp;

	optType(
		std::vector<cv::Point> &src,
		std::vector<cv::Point> &tar,
		std::vector<cv::Point> &match_src,
		std::vector<cv::Point> &match_tar,
		std::vector<float> &concave_src,
		std::vector<float> &concave_tar,
		std::vector<int> &feature_idx_src,
		std::vector<int> &feature_idx_tar,
		std::vector<int> &match_idx_src,
		std::vector<int> &match_idx_tar,
		std::vector<int> &match_feature_idx_src,
		std::vector<int> &match_feature_idx_tar,
		std::vector<int> &ctrl_idx_src,
		std::vector<int> &ctrl_idx_tar,
		std::vector<int> &ctrl_idx_def,
		std::vector<int> &MLS_ctrl_src,
		std::vector<int> &MLS_ctrl_tar,
		std::vector<int> &union_ctrl_src,
		std::vector<int> &union_ctrl_tar,
		std::vector<int> &non_collision_match_idx_src,
		std::vector<int> &non_collision_match_idx_tar,
		std::vector<int> &collision_idx_src,
		std::vector<int> &collision_idx_tar,
		std::vector<int> &union_ctrl_src_warp,
		std::vector<int> &union_ctrl_tar_warp
		){
			this->src = src;
			this->tar = tar;
			this->match_src = match_src;
			this->match_tar = match_tar;
			this->concave_src = concave_src;
			this->concave_tar = concave_tar;
			this->feature_idx_src = feature_idx_src;
			this->feature_idx_tar = feature_idx_tar;
			this->match_idx_src = match_idx_src;
			this->match_idx_tar = match_idx_tar;
			this->match_feature_idx_src = match_feature_idx_src;
			this->match_feature_idx_tar = match_feature_idx_tar;
			this->ctrl_idx_src = ctrl_idx_src;
			this->ctrl_idx_tar = ctrl_idx_tar;
			this->ctrl_idx_def = ctrl_idx_def;
			this->MLS_ctrl_src = MLS_ctrl_src;
			this->MLS_ctrl_tar = MLS_ctrl_tar;
			this->union_ctrl_src = union_ctrl_src;
			this->union_ctrl_tar = union_ctrl_tar;
			this->non_collision_match_idx_src = non_collision_match_idx_src;
			this->non_collision_match_idx_tar = non_collision_match_idx_tar;
			this->collision_idx_src = collision_idx_src;
			this->collision_idx_tar = collision_idx_tar;
			this->union_ctrl_src_warp = union_ctrl_src_warp;
			this->union_ctrl_tar_warp = union_ctrl_tar_warp;
	}

	optType(){

	};

};


#endif