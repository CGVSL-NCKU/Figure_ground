#include "stdafx.h"
#include "JC_crop.h"
#include "JC_find_contour.h"
#include "JC_functions.h"
#include "JC_svgParser.h"
#ifndef _JC_WATCHED_H_
#define _JC_WATCHED_H_


namespace Watched{

	void renew_label( QLabel *label,  cv::Mat &cropping, ContourType iContour[10], int ground, double size){
		string path = iContour[0].fileName;
		cv::Mat iMat = cv::imread(path, 0);
		float scale = size;
		cv::Size d_size = cv::Size(iMat.cols*scale, iMat.rows*scale);
		cv::Mat scale_iMat = cv::Mat(d_size,CV_8UC3);
		resize(iMat, scale_iMat, d_size);

		if(ground == 1){
			float sizeTerm[]={ 0.6, 0.8, 1.0, 1.2, 1.4};	
			for(int j = 0 ; j < 5; j++){
				float scale = sizeTerm[j];
				cv::Size dsize = cv::Size(scale_iMat.cols*scale, scale_iMat.rows*scale);
				cv::Mat scale_image = cv::Mat(dsize,CV_8UC3);
				resize(scale_iMat, scale_image, dsize);
				Find_Contour::find_contour(iContour[j], scale_image);
				cv::flip(scale_image, scale_image, 1); 
				Find_Contour::find_contour(iContour[j+5], scale_image);
			}
		}else{
			iContour[0].fileName = path;
			Find_Contour::find_contour(iContour[0], scale_iMat);
		}

		cv::Mat Mat_color = cv::imread(path, CV_LOAD_IMAGE_COLOR);
		cropping = cv::Mat(d_size,CV_8UC3);
		resize(Mat_color, cropping, d_size);

		//////////////////////////////////////////////////////////////////////////
		QImage image = JC::Mat2QImage(cropping, QImage::Format_RGB888);
		//image = image.scaled(label->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
		label->setPixmap(QPixmap::fromImage(image));
	}

	bool watched_label(QEvent *event, QLabel *label, cv::Mat &cropping, int &lockDrop, ContourType iContour[10], int ground, double size){
		if (event->type() == QEvent::MouseButtonPress && lockDrop == 1) {
			
			cv::Mat returnImg;
			if (ground==1){
				returnImg = JC_crop::croppingLabel(label, cropping, iContour);
			}else{
				returnImg = JC_crop::croppingLabel_figure(label, cropping, iContour);
			}
			
			QImage image = JC::Mat2QImage(returnImg, QImage::Format_RGB888);
			//image = image.scaled(label->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
			label->setPixmap(QPixmap::fromImage(image));

			return true;
		}

		if (event->type() == QEvent::DragEnter) {
			/* [2] : when the mouse is above on label, agree the drag & drop */
			QDragEnterEvent *dee = dynamic_cast<QDragEnterEvent *>(event);
			dee->acceptProposedAction();
			return true;

		} else if (event->type() == QEvent::Drop) {	
			/* [3] : get the drop data */
			
			QDropEvent *de = dynamic_cast<QDropEvent *>(event);
			QList<QUrl> urls = de->mimeData()->urls();
			std::string path;

			if (urls.isEmpty()) { 
				QByteArray encoded = de->mimeData()->data("application/x-qabstractitemmodeldatalist");
				QDataStream strm(&encoded, QIODevice::ReadOnly);


				QString str;
				while(!strm.atEnd()){
					int row, col;
					QMap<int,  QVariant> data;
					strm >> row >> col >> data;
					//de->s(data[0].toString());
					str = data[0].toString();
				}
				path =  "..\\inputs\\" + str.toStdString() + ".bmp";
				
				//return true;
			}else{
				QString qpath = urls.first().toLocalFile();
				path = qpath.toStdString();
			}
			
			
			/* [4] : show the image on the label */
			/* original contour */
			cv::Mat iMat = cv::imread(path, 0);
			float scale = size;
			cv::Size d_size = cv::Size(iMat.cols*scale, iMat.rows*scale);
			cv::Mat scale_iMat = cv::Mat(d_size,CV_8UC3);
			resize(iMat, scale_iMat, d_size);

			if(ground == 1){
				float sizeTerm[]={ 0.6, 0.8, 1.0, 1.2, 1.4};	
				for(int j = 0 ; j < 5; j++){
					float scale = sizeTerm[j];
					cv::Size dsize = cv::Size(scale_iMat.cols*scale, scale_iMat.rows*scale);
					cv::Mat scale_image = cv::Mat(dsize,CV_8UC3);
					resize(scale_iMat, scale_image, dsize);
					Find_Contour::find_contour(iContour[j], scale_image);
					cv::flip(scale_image, scale_image, 1); 
					Find_Contour::find_contour(iContour[j+5], scale_image);
					iContour[j].fileName = path;
					iContour[j+5].fileName = path;
				}
			}else{
				iContour[0].fileName = path;
				Find_Contour::find_contour(iContour[0], scale_iMat);
			}

			cv::Mat Mat_color = cv::imread(path, CV_LOAD_IMAGE_COLOR);
			cropping = cv::Mat(d_size,CV_8UC3);
			resize(Mat_color, cropping, d_size);

			lockDrop = 1;
			//////////////////////////////////////////////////////////////////////////
			//QString qstr = QString::fromStdString(path);

			QImage image = JC::Mat2QImage(cropping, QImage::Format_RGB888);
			//image = image.scaled(label->size(),	Qt::KeepAspectRatio, Qt::SmoothTransformation);
			label->setPixmap(QPixmap::fromImage(image));


// 			QImage image(qstr);
// 			if (!image.isNull()) {
// 				image = image.scaled(label->size(),
// 					Qt::KeepAspectRatio,
// 					Qt::SmoothTransformation);
// 				label->setPixmap(QPixmap::fromImage(image));
// 			}
			
			return true;
		}
	}


}

#endif