// Longest Increasing Subsequence.cpp : Defines the entry point for the console application.
#include "stdafx.h"
#include <vector>
#include <fstream>
#include <string>
#include "JC_type.h"
using namespace std;
#ifndef _JC_SVG_
#define _JC_SVG_


curPos cPos;
// vector <endPoint> endPoints ;
// vector <ctlPoint> ctlPoints ;
//IplImage *image = 0 ;   
int Bcount = 0;

namespace svgParser{

	void move_end( int idx ,float x,float y, vector <endPoint> &endPoints, vector <ctlPoint> &ctlPoints){

		for(int i = 0 ; i < endPoints[idx].ctl_size; i++){
			float dx = x - endPoints[idx].x;
			float dy = y - endPoints[idx].y;
			ctlPoints[endPoints[idx].ctl_idx[i]].x += dx;
			ctlPoints[endPoints[idx].ctl_idx[i]].y += dy;
		}
		endPoints[idx].x = x;
		endPoints[idx].y = y;

	}

	void split_bezier(cv::Point2f *p, int curve_len, vector <endPoint> &endPoints, vector <ctlPoint> &ctlPoints){
		cv::Point2f c[10];
		c[0] = p[0];
		c[1] = p[1];
		c[2] = p[2];
		c[3] = p[3];
		c[4] = (c[0]+c[1]); c[4].x /= 2; c[4].y /= 2;
		c[5] = (c[1]+c[2]); c[5].x /= 2; c[5].y /= 2;
		c[6] = (c[2]+c[3]); c[6].x /= 2; c[6].y /= 2;
		c[7] = (c[4]+c[5]); c[7].x /= 2; c[7].y /= 2;
		c[8] = (c[5]+c[6]); c[8].x /= 2; c[8].y /= 2;
		c[9] = (c[7]+c[8]); c[9].x /= 2; c[9].y /= 2;

		cv::Point2f p1 = c[9] - c[0];
		float len1 = (p1.x)*(p1.x) + (p1.y)*(p1.y);
		cv::Point2f a[4];
		a[0] = c[0];
		a[1] = c[4];
		a[2] = c[7];
		a[3] = c[9];

		if(len1 > curve_len){
			split_bezier(a, curve_len, endPoints, ctlPoints);
		}else{
			ctlPoint tmpC1,tmpC2;
			tmpC1.x = a[1].x; tmpC1.y = a[1].y;
			tmpC2.x = a[2].x; tmpC2.y = a[2].y;

			ctlPoints.push_back(tmpC1);
			ctlPoints.push_back(tmpC2);

			endPoint tmpP;
			tmpP.type = 'c';
			tmpP.x = a[3].x;
			tmpP.y = a[3].y;
			tmpP.ctl_size = 1;
			tmpP.ctl_idx[0] = ctlPoints.size()-1;

			int c_size = endPoints[endPoints.size()-1].ctl_size;
			endPoints[endPoints.size()-1].ctl_idx[c_size] = ctlPoints.size()-2;
			endPoints[endPoints.size()-1].ctl_size++;

			endPoints.push_back(tmpP);
		}


		cv::Point2f p2 = c[3] - c[9];
		float len2 = (p2.x)*(p2.x) + (p2.y)*(p2.y);

		a[0] = c[9];
		a[1] = c[8];
		a[2] = c[6];
		a[3] = c[3];
		if(len2 > curve_len){
			split_bezier(a, curve_len, endPoints, ctlPoints);
		}else{
			ctlPoint tmpC1,tmpC2;
			tmpC1.x = a[1].x; tmpC1.y = a[1].y;
			tmpC2.x = a[2].x; tmpC2.y = a[2].y;

			ctlPoints.push_back(tmpC1);
			ctlPoints.push_back(tmpC2);

			endPoint tmpP;
			tmpP.type = 'c';
			tmpP.x = a[3].x;
			tmpP.y = a[3].y;
			tmpP.ctl_size = 1;
			tmpP.ctl_idx[0] = ctlPoints.size()-1;	

			int c_size = endPoints[endPoints.size()-1].ctl_size;
			endPoints[endPoints.size()-1].ctl_idx[c_size] = ctlPoints.size()-2;
			endPoints[endPoints.size()-1].ctl_size++;

			endPoints.push_back(tmpP);
		}

	};

	void construct_svg(std::string path, int curve_len, vector <endPoint> &endPoints, vector <ctlPoint> &ctlPoints){

		endPoints.clear();
		ctlPoints.clear();

		fstream file;
		file.open(path.c_str(), ios::in);
		if(!file){
			std::cout <<"no file" <<std::endl;
			std::cout << path << std::endl;
		}

		string str;
		char m;
		int x,y;


		file >> str;
		while( str!="<path" ){
			file >> str;
		}
		cout << str << endl;
		file >> m;
		file >> m;
		file >> m;
		file >> m;
		file >> x;
		file >> y;
		cout << x<<","<< y<< endl;


		cPos.x = x*0.1;
		cPos.y = y*-0.1+500;

		endPoint tmpP;
		tmpP.type = 'm';
		tmpP.x = cPos.x;
		tmpP.y = cPos.y;
		tmpP.ctl_size = 0;

		ctlPoint tmpC1,tmpC2;

		endPoints.push_back(tmpP);
		char state = 'm';
		while( file >> str){
			size_t found_line = str.find("c");
			int find_num = 0;
			if (found_line!=std::string::npos){
				state = 'c';
				find_num = 1;
				//cout << "c: " << found_line << '\n';
				string str2 = str.substr (found_line+1);
				stringstream a(str2);
				cv::Point2f c[4];
				a >> x; file >> y;
// 				cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
// 				cout << x << "," << y << endl;
				tmpC1.x = c[1].x = cPos.x + x*0.1;
				tmpC1.y = c[1].y = cPos.y - y*0.1;

				file >> x >> y ;
// 				cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
// 				cout << x << "," << y << endl;
				tmpC2.x = c[2].x = cPos.x + x*0.1;
				tmpC2.y = c[2].y = cPos.y - y*0.1;

				file >> x >> y ;
// 				cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
// 				cout << x << "," << y << endl;
// 				cout << endl;

				cPos.x = cPos.x + x*0.1;
				cPos.y = cPos.y - y*0.1;

				//tmpP.clear();
				tmpP.type = 'c';
				tmpP.x = c[3].x = cPos.x;
				tmpP.y = c[3].y = cPos.y;

				c[0].x = endPoints[endPoints.size()-1].x;
				c[0].y = endPoints[endPoints.size()-1].y;

				cv::Point2f p1 = c[3] - c[0];
				float len1 = (p1.x)*(p1.x) + (p1.y)*(p1.y);

				if(len1 < curve_len){
					ctlPoints.push_back(tmpC1);
					ctlPoints.push_back(tmpC2);


					tmpP.ctl_size = 1;
					tmpP.ctl_idx[0] = ctlPoints.size()-1;

					int c_size = endPoints[endPoints.size()-1].ctl_size;
					endPoints[endPoints.size()-1].ctl_idx[c_size] = ctlPoints.size()-2;
					endPoints[endPoints.size()-1].ctl_size++;

					endPoints.push_back(tmpP);

				}else{
					split_bezier(c, curve_len, endPoints, ctlPoints);
				}



			}
			found_line = str.find("l");
			if (found_line!=std::string::npos){
				state = 'l';
				find_num = 1;
				//cout << "l: " << found_line << '\n';
				string str2 = str.substr (found_line+1);
				stringstream a(str2);
				a >> x;
				file >> y;
				//cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
				cPos.x = cPos.x + x*0.1;
				cPos.y = cPos.y - y*0.1;

				tmpP.type = 'l';
				tmpP.x = cPos.x;
				tmpP.y = cPos.y;
				tmpP.ctl_size = 0;
				//tmpP.ctl_idx[0] = ctlPoints.size()-1;
				endPoints.push_back(tmpP);
			}
			if(str == "z\"/>"){
				//cout << str << endl;
				break;
			}
			if(find_num==0){
				stringstream a(str);
				if(state == 'c'){
					cv::Point2f c[4];
					a >> x; file >> y;
					//cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
					tmpC1.x = c[1].x = cPos.x + x*0.1;
					tmpC1.y = c[1].y = cPos.y - y*0.1;

					file >> x >> y ;
					//cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
					tmpC2.x = c[2].x = cPos.x + x*0.1;
					tmpC2.y = c[2].y = cPos.y - y*0.1;

					file >> x >> y ;
					//cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
					//cout << endl;

					cPos.x = cPos.x + x*0.1;
					cPos.y = cPos.y - y*0.1;

					//tmpP.clear();
					tmpP.type = 'c';
					tmpP.x = c[3].x = cPos.x;
					tmpP.y = c[3].y = cPos.y;

					c[0].x = endPoints[endPoints.size()-1].x;
					c[0].y = endPoints[endPoints.size()-1].y;

					cv::Point2f p1 = c[3] - c[0];
					float len1 = (p1.x)*(p1.x) + (p1.y)*(p1.y);

					if(len1 < curve_len){
						ctlPoints.push_back(tmpC1);
						ctlPoints.push_back(tmpC2);


						tmpP.ctl_size = 1;
						tmpP.ctl_idx[0] = ctlPoints.size()-1;

						int c_size = endPoints[endPoints.size()-1].ctl_size;
						endPoints[endPoints.size()-1].ctl_idx[c_size] = ctlPoints.size()-2;
						endPoints[endPoints.size()-1].ctl_size++;

						endPoints.push_back(tmpP);
					}else{
						split_bezier(c, curve_len, endPoints, ctlPoints);
					}

				}else if (state =='l'){
					a >> x;
					file >>  y;
					cout << cPos.x + x*0.1<< "," << cPos.y-y*0.1<< endl;
					cPos.x = cPos.x + x*0.1;
					cPos.y = cPos.y - y*0.1;

					tmpP.type = 'l';
					tmpP.x = cPos.x;
					tmpP.y = cPos.y;
					tmpP.ctl_size = 0;
					//tmpP.ctl_idx[0] = ctlPoints.size()-1;
					endPoints.push_back(tmpP);
				}


			}


		}

	}

	CvPoint3D32f pointAdd(CvPoint3D32f p, CvPoint3D32f q)   
	{  
		p.x += q.x; p.y += q.y; p.z += q.z;  
		return p;  
	}  
	CvPoint3D32f pointTimes(float c, CvPoint3D32f p)   
	{  
		p.x *= c; p.y *= c; p.z *= c;  
		return p;  
	}  
	CvPoint3D32f Bernstein(float u, CvPoint3D32f *p)   
	{  
		CvPoint3D32f a, b, c, d, r;  

		a = pointTimes(pow(u,3), p[0]);  
		b = pointTimes(3*pow(u,2)*(1-u), p[1]);  
		c = pointTimes(3*u*pow((1-u),2), p[2]);  
		d = pointTimes(pow((1-u),3), p[3]);   
		r = pointAdd(pointAdd(a, b), pointAdd(c, d));  

		return r;  
	} 

	CvPoint3D32f GetDerivate(float u, CvPoint3D32f *p)   
	{  
		CvPoint3D32f r;  

		double s0 = -3 + 6 * u - 3 * pow(u,2);
		double s1 = 3 - 12 * u + 9 * pow(u,2);
		double s2 = 6 * u - 9 * pow(u,2);
		double s3 = 3 * pow(u,2);
		double resultX = p[0].x * s0 + p[1].x * s1 + p[2].x * s2 + p[3].x * s3;
		double resultY = p[0].y * s0 + p[1].y * s1 + p[2].y * s2 + p[3].y* s3;
		r.x = resultX;
		r.y = resultY;;

		return r;  
	} 

	CvPoint3D32f GetSecondDerivate(float u, CvPoint3D32f *p)   
	{  
		CvPoint3D32f r;  

		double s0 = 6 - 6 * u;
		double s1 = -12 + 18 * u;
		double s2 = 6 - 18 * u;
		double s3 = 6 * u;
		double resultX = p[0].x * s0 + p[1].x * s1 + p[2].x * s2 + p[3].x * s3;
		double resultY = p[0].y * s0 + p[1].y * s1 + p[2].y * s2 + p[3].y* s3;
		r.x = resultX;
		r.y = resultY;;

		return r;  
	}

	double GetCurvatureRadius(float u, CvPoint3D32f *p)
	{
		CvPoint3D32f d1 = GetDerivate(u, p);
		CvPoint3D32f d2 = GetSecondDerivate(u, p);

		double r1 = sqrt(pow(d1.x * d1.x + d1.y * d1.y, 3));
		double r2 = abs(d1.x * d2.y - d2.x * d1.y);
		return r1 / r2;
	}

	void ecvDrawBezier(cv::Mat image, CvPoint3D32f* points)  
	{  
		
		CvPoint pt_pre=cvPoint(points[0].x,points[0].y);  
		CvPoint pt_now;  
		int precision = 10;  
		for (int i=0;i<=precision;i++)   
		{  
			Bcount++;
			cv::Mat image2 = image.clone();

			float u = (float)i/precision;  
			CvPoint3D32f newPt = Bernstein(u,points);   
			double radius = GetCurvatureRadius(u,points); 
			ostringstream oss,oss2;
			oss << radius;
			oss2 << Bcount;
			pt_now.x = (int)newPt.x;  
			pt_now.y = (int)newPt.y;  


			if(i>0) {
				cv::line(image, pt_now, pt_pre, CV_RGB(255,255,255),1); 
// 				cv::putText(image2, oss.str(), cv::Point(newPt.x, newPt.y), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 0, 255), 1);
// 				std::cout << oss.str() << std::endl;
// 				std::string file_name = oss2.str() + ".png";
				//cv::imwrite(file_name, image2);
				
			} 

			pt_pre = pt_now;  
		}  
		//DrawControlLine(points);  
	}  

	void drawBezierCurveWithPoints(cv::Mat image, vector <endPoint> &endPoints, vector <ctlPoint> &ctlPoints){
		static CvPoint3D32f points[4]; 


		for(int i = 0 ; i < endPoints.size()-1; i++){
			
			if( (endPoints[i].type == 'c') && (endPoints[i-1].ctl_size >=1) ){
				points[0].x = endPoints[i-1].x;
				points[0].y = endPoints[i-1].y;
				points[1].x = ctlPoints[endPoints[i-1].ctl_idx[endPoints[i-1].ctl_size-1]].x;  
				points[1].y = ctlPoints[endPoints[i-1].ctl_idx[endPoints[i-1].ctl_size-1]].y;  
				points[2].x = ctlPoints[endPoints[i].ctl_idx[0]].x;  
				points[2].y = ctlPoints[endPoints[i].ctl_idx[0]].y;  
				points[3].x = endPoints[i].x;
				points[3].y = endPoints[i].y;

				cv::circle(image,cvPoint(points[3].x,points[3].y), 1, CV_RGB(255,0,0), 2 );
				//cvLine(image,cvPoint(points[0].x,points[0].y), cvPoint(points[3].x,points[3].y) ,CV_RGB(255,0,0),1,CV_AA,0);  
				ecvDrawBezier(image,points); 

			}else if(endPoints[i].type == 'l'){
				CvPoint pc[2];  
				pc[0].x = endPoints[i].x;
				pc[0].y = endPoints[i].y;
				pc[1].x = endPoints[i-1].x;
				pc[1].y = endPoints[i-1].y; 

				cv::line(image, pc[0],pc[1],CV_RGB(0,0,255),1); 
				cv::circle(image, cvPoint(pc[0].x,pc[0].y), 1, CV_RGB(0,255,255), 2 );
				//ecvDrawBezier(image,points); 
			}
		}
	}

	void drawBezierCurve(cv::Mat image, vector <endPoint> &endPoints, vector <ctlPoint> &ctlPoints){
		static CvPoint3D32f points[4]; 

		for(int i = 0 ; i < endPoints.size()-1; i++){

			if( (endPoints[i].type == 'c') && (endPoints[i-1].ctl_size >=1) ){
				points[0].x = endPoints[i-1].x;
				points[0].y = endPoints[i-1].y;
				points[1].x = ctlPoints[endPoints[i-1].ctl_idx[endPoints[i-1].ctl_size-1]].x;  
				points[1].y = ctlPoints[endPoints[i-1].ctl_idx[endPoints[i-1].ctl_size-1]].y;  
				points[2].x = ctlPoints[endPoints[i].ctl_idx[0]].x;  
				points[2].y = ctlPoints[endPoints[i].ctl_idx[0]].y;  
				points[3].x = endPoints[i].x;
				points[3].y = endPoints[i].y;

				cv::circle(image,cvPoint(points[3].x,points[3].y), 1, CV_RGB(255,0,0), 2 );
				//cvLine(image,cvPoint(points[0].x,points[0].y), cvPoint(points[3].x,points[3].y) ,CV_RGB(255,255,255),1,CV_AA,0);  
				ecvDrawBezier(image,points); 

			}else if(endPoints[i].type == 'l'){
				CvPoint pc[2];  
				pc[0].x = endPoints[i].x;
				pc[0].y = endPoints[i].y;
				pc[1].x = endPoints[i-1].x;
				pc[1].y = endPoints[i-1].y; 

				cv::line(image, pc[0],pc[1],CV_RGB(0,0,255),1); 
				cv::circle(image, cvPoint(pc[0].x,pc[0].y), 1, CV_RGB(0,255,255), 2 );
// 				cvLine(image,pc[0],pc[1],CV_RGB(255,255,255),1,CV_AA,0);  
// 				cvCircle(image,cvPoint(pc[0].x,pc[0].y),1,CV_RGB(0,255,255),2); 
// 				ecvDrawBezier(image,points); 
			}
		}
	}

	void movePoints( vector <cv::Point> &src, vector <cv::Point> &tar  , vector <endPoint> &endPoints, vector <ctlPoint> &ctlPoints ){
	
		for(int j = 0 ; j < endPoints.size(); j++){
			float minDist = 99999;
			int minIdx = -1;
			for(int i =0; i < src.size(); i++){
				float dists;
				dists = sqrt(pow((src[i].x - endPoints[j].x),2)+pow((src[i].y - endPoints[j].y),2) );
				if(dists <= minDist){
					minDist =dists;
					minIdx = i;
				} 
			}

			if(minIdx!=-1 && minDist < 2) {
				move_end(j, tar[minIdx].x, tar[minIdx].y, endPoints, ctlPoints);	
			}
		}


	}

}

#endif
