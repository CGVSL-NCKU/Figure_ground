#include "stdafx.h"
#include "Utils_Ocv.h"

Utils_Ocv Utils_Ocv::inst;

Utils_Ocv::Utils_Ocv()
{
    cv::Mat depmap = cv::Mat::ones(100, 256, CV_8UC1);
    
    for(int j=0;j<256;j++)
        for(int i=0;i<100;i++)
            depmap.at<uchar>(i,j) = j%256;
    
    // Apply the colormap:
    cv::applyColorMap( depmap, colormap, cv::COLORMAP_JET );
}

void Utils_Ocv::getColor
( cv::Vec3b &color, int value, int maxValue, int minValue)
{
    float colorID = 0;
    
    if( maxValue > minValue && value >= minValue && maxValue >= value )
        colorID = (float)( value - minValue )*255.0f / ( maxValue - minValue );

    color = colormap.at<cv::Vec3b>(0,(int)colorID);
}
