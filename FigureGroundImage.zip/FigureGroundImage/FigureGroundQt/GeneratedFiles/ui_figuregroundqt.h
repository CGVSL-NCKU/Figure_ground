/********************************************************************************
** Form generated from reading UI file 'figuregroundqt.ui'
**
** Created by: Qt User Interface Compiler version 5.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FIGUREGROUNDQT_H
#define UI_FIGUREGROUNDQT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FigureGroundQtClass
{
public:
    QAction *actionParameter;
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QListWidget *listWidget;
    QSpinBox *spinBox_tar;
    QSpinBox *spinBox_src;
    QSlider *horizontalSlider_src;
    QSlider *horizontalSlider;
    QWidget *tab_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_15;
    QWidget *tab_3;
    QPushButton *pushButton_2;
    QLabel *label_8;
    QPushButton *pushButton_3;
    QPushButton *pushButton_edit_warp;
    QPushButton *pushButton_save;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *FigureGroundQtClass)
    {
        if (FigureGroundQtClass->objectName().isEmpty())
            FigureGroundQtClass->setObjectName(QStringLiteral("FigureGroundQtClass"));
        FigureGroundQtClass->resize(1125, 613);
        actionParameter = new QAction(FigureGroundQtClass);
        actionParameter->setObjectName(QStringLiteral("actionParameter"));
        centralWidget = new QWidget(FigureGroundQtClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 1091, 561));
        tabWidget->setIconSize(QSize(32, 32));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        label = new QLabel(tab);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 110, 400, 400));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(240, 240, 240, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 255, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush2);
        QBrush brush3(QColor(127, 127, 127, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush3);
        QBrush brush4(QColor(170, 170, 170, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush4);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush2);
        QBrush brush5(QColor(255, 255, 220, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush5);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        label->setPalette(palette);
        label->setAcceptDrops(true);
        label->setStyleSheet(QLatin1String("background-color: rgb(240, 240, 240);\n"
"border:1px dashed black;"));
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(450, 110, 400, 400));
        label_2->setStyleSheet(QLatin1String("background-color: rgb(240, 240, 240);\n"
"border:1px dashed black;"));
        pushButton = new QPushButton(tab);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(860, 30, 112, 70));
        pushButton->setIconSize(QSize(48, 48));
        listWidget = new QListWidget(tab);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(860, 110, 211, 400));
        spinBox_tar = new QSpinBox(tab);
        spinBox_tar->setObjectName(QStringLiteral("spinBox_tar"));
        spinBox_tar->setGeometry(QRect(810, 70, 41, 22));
        spinBox_tar->setMinimum(40);
        spinBox_tar->setMaximum(100);
        spinBox_tar->setValue(90);
        spinBox_src = new QSpinBox(tab);
        spinBox_src->setObjectName(QStringLiteral("spinBox_src"));
        spinBox_src->setGeometry(QRect(380, 70, 41, 22));
        spinBox_src->setMinimum(40);
        spinBox_src->setMaximum(100);
        spinBox_src->setValue(90);
        horizontalSlider_src = new QSlider(tab);
        horizontalSlider_src->setObjectName(QStringLiteral("horizontalSlider_src"));
        horizontalSlider_src->setGeometry(QRect(20, 70, 351, 22));
        horizontalSlider_src->setMinimum(40);
        horizontalSlider_src->setMaximum(100);
        horizontalSlider_src->setValue(90);
        horizontalSlider_src->setOrientation(Qt::Horizontal);
        horizontalSlider = new QSlider(tab);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(450, 70, 351, 22));
        horizontalSlider->setMinimum(40);
        horizontalSlider->setMaximum(100);
        horizontalSlider->setValue(90);
        horizontalSlider->setOrientation(Qt::Horizontal);
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        label_3 = new QLabel(tab_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 220, 200, 200));
        label_3->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border:1px dashed black;"));
        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(220, 220, 200, 200));
        label_4->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border:1px dashed black;"));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(430, 220, 200, 200));
        label_5->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border:1px dashed black;"));
        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(640, 220, 200, 200));
        label_6->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border:1px dashed black;"));
        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(850, 220, 200, 200));
        label_7->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border:1px dashed black;"));
        horizontalLayoutWidget = new QWidget(tab_2);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(90, 160, 1041, 41));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(horizontalLayoutWidget);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout->addWidget(label_9);

        label_10 = new QLabel(horizontalLayoutWidget);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout->addWidget(label_10);

        label_11 = new QLabel(horizontalLayoutWidget);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout->addWidget(label_11);

        label_12 = new QLabel(horizontalLayoutWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout->addWidget(label_12);

        label_13 = new QLabel(horizontalLayoutWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout->addWidget(label_13);

        label_15 = new QLabel(tab_2);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(450, 60, 361, 16));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        pushButton_2 = new QPushButton(tab_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(140, 50, 131, 70));
        pushButton_2->setIconSize(QSize(48, 48));
        label_8 = new QLabel(tab_3);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(320, 50, 400, 400));
        label_8->setAutoFillBackground(false);
        label_8->setStyleSheet(QLatin1String("background-color: rgb(145, 145, 145);\n"
"border:1px dashed black;"));
        pushButton_3 = new QPushButton(tab_3);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(770, 140, 131, 70));
        pushButton_3->setIconSize(QSize(48, 48));
        pushButton_edit_warp = new QPushButton(tab_3);
        pushButton_edit_warp->setObjectName(QStringLiteral("pushButton_edit_warp"));
        pushButton_edit_warp->setGeometry(QRect(770, 50, 131, 70));
        pushButton_save = new QPushButton(tab_3);
        pushButton_save->setObjectName(QStringLiteral("pushButton_save"));
        pushButton_save->setGeometry(QRect(770, 230, 131, 70));
        tabWidget->addTab(tab_3, QString());
        FigureGroundQtClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(FigureGroundQtClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1125, 21));
        FigureGroundQtClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(FigureGroundQtClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        FigureGroundQtClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(FigureGroundQtClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        FigureGroundQtClass->setStatusBar(statusBar);

        retranslateUi(FigureGroundQtClass);
        QObject::connect(pushButton, SIGNAL(clicked()), FigureGroundQtClass, SLOT(click_next1()));
        QObject::connect(pushButton_2, SIGNAL(clicked()), FigureGroundQtClass, SLOT(click_previous()));
        QObject::connect(pushButton_3, SIGNAL(clicked()), FigureGroundQtClass, SLOT(click_edit1()));
        QObject::connect(pushButton_edit_warp, SIGNAL(clicked()), FigureGroundQtClass, SLOT(editWarp()));
        QObject::connect(pushButton_save, SIGNAL(clicked()), FigureGroundQtClass, SLOT(saveImg()));
        QObject::connect(spinBox_src, SIGNAL(valueChanged(int)), FigureGroundQtClass, SLOT(figure_change()));
        QObject::connect(spinBox_tar, SIGNAL(valueChanged(int)), FigureGroundQtClass, SLOT(ground_change()));
        QObject::connect(horizontalSlider_src, SIGNAL(valueChanged(int)), spinBox_src, SLOT(setValue(int)));
        QObject::connect(horizontalSlider, SIGNAL(valueChanged(int)), spinBox_tar, SLOT(setValue(int)));

        tabWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(FigureGroundQtClass);
    } // setupUi

    void retranslateUi(QMainWindow *FigureGroundQtClass)
    {
        FigureGroundQtClass->setWindowTitle(QApplication::translate("FigureGroundQtClass", "Figure-Ground Imgaes", 0));
        actionParameter->setText(QApplication::translate("FigureGroundQtClass", "parameter", 0));
        label->setText(QApplication::translate("FigureGroundQtClass", "drag and drop the figure image", 0));
        label_2->setText(QApplication::translate("FigureGroundQtClass", "drag and drop the ground image", 0));
        pushButton->setText(QApplication::translate("FigureGroundQtClass", "Next", 0));
        spinBox_tar->setSuffix(QString());
        spinBox_src->setSuffix(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("FigureGroundQtClass", "Input Images", 0));
        label_3->setText(QApplication::translate("FigureGroundQtClass", "TextLabel", 0));
        label_4->setText(QApplication::translate("FigureGroundQtClass", "TextLabel", 0));
        label_5->setText(QApplication::translate("FigureGroundQtClass", "TextLabel", 0));
        label_6->setText(QApplication::translate("FigureGroundQtClass", "TextLabel", 0));
        label_7->setText(QApplication::translate("FigureGroundQtClass", "TextLabel", 0));
        label_9->setText(QApplication::translate("FigureGroundQtClass", "Rank 1", 0));
        label_10->setText(QApplication::translate("FigureGroundQtClass", "Rank 2", 0));
        label_11->setText(QApplication::translate("FigureGroundQtClass", "Rank 3", 0));
        label_12->setText(QApplication::translate("FigureGroundQtClass", "Rank 4", 0));
        label_13->setText(QApplication::translate("FigureGroundQtClass", "Rank 5", 0));
        label_15->setText(QApplication::translate("FigureGroundQtClass", "Click any image to process warping", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("FigureGroundQtClass", "Matching Ranking", 0));
        pushButton_2->setText(QApplication::translate("FigureGroundQtClass", "Previous", 0));
        label_8->setText(QApplication::translate("FigureGroundQtClass", "TextLabel", 0));
        pushButton_3->setText(QApplication::translate("FigureGroundQtClass", "edit cropping", 0));
        pushButton_edit_warp->setText(QApplication::translate("FigureGroundQtClass", "edit warping", 0));
        pushButton_save->setText(QApplication::translate("FigureGroundQtClass", "save image", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("FigureGroundQtClass", "Result", 0));
    } // retranslateUi

};

namespace Ui {
    class FigureGroundQtClass: public Ui_FigureGroundQtClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FIGUREGROUNDQT_H
