#include "stdafx.h"
#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>

#ifndef _JC_LIST_
#define _JC_LIST_

namespace JC_List{

	void buildList(int &firstIndex, int &lastIndex ,std::vector<int> &newList, std::vector<cv::Point> &contour){
		for(int i = 0; i < contour.size(); i++){
			int index = (firstIndex + i)% contour.size();
			newList.push_back(index);
			if(index == lastIndex){
				break;
			}
		}
	}

	int contourDist(int &firstIndex, int &searchIndex ,std::vector<cv::Point> &contour){
		int dist = 0;
		for(int i = 1; i < contour.size(); i++){
			int index = (firstIndex + i)% contour.size();
			dist++;
			if(index == searchIndex){
				break;
			}
		}
		return dist;
	}

	void addList( std::vector<int> &inputList, std::vector<int> &longerstList, std::vector<cv::Point> &contour){

		if(longerstList.size()==0){
			longerstList = inputList;
			return;
		}

		std::vector<int> notFindList;
		std::vector<int>::iterator it;
		/* collect the data that not find */
		for(int i = 0 ; i < inputList.size(); i ++){
			it = find(longerstList.begin(), longerstList.end(), inputList[i]);
			if(it==longerstList.end()){
				notFindList.push_back(inputList[i]);
			}else{

				/* ex: [2,3,4] [3,4] */
				notFindList.clear();
				int head = i-1;
				int tail = i+1;

				while(head >= 0){
					longerstList.insert ( longerstList.begin() , inputList[head] );
					head--;
				}

				while(tail < inputList.size()){
					it = find(longerstList.begin(), longerstList.end(), inputList[tail]);
					if(it==longerstList.end()){
						longerstList.push_back(inputList[tail]);
					}
					tail++;
				}
				break;
			}
		}

		/* ex: [2,3,4] [6,7] */
		if(notFindList.size() > 0){
			int insertHead = contourDist( inputList[inputList.size()-1], longerstList[0], contour );
			int insertTail = contourDist( longerstList[longerstList.size()-1], inputList[0], contour );

			std::vector<int> _longerstList;
			if(insertHead < insertTail) {
				buildList(inputList[0], longerstList[longerstList.size()-1], _longerstList, contour);
				longerstList = _longerstList;
			}else{
				buildList(longerstList[0], inputList[inputList.size()-1], _longerstList, contour);
				longerstList = _longerstList;
			}
		}else{
			return;
		}

	}

}

#endif
