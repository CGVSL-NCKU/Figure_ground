﻿#include "figuregroundqt.h"
#include <QtWidgets/QApplication>
#include <QApplication>
#include <QTabWidget>
#include <QLabel>
#include <QIcon>
#include <QPushButton>
#include <QTextEdit>


int main(int argc, char *argv[])
{
	
	QApplication a(argc, argv);
	FigureGroundQt w;

	w.setWindowIcon(QIcon("../icons/icon.png"));
	w.show();

	return a.exec();
}
