#include "stdafx.h"
#include "JC_find_contour.h"
#include "JC_functions.h"
#include "JC_window_edit.h"
#include "JC_svgParser.h"
#ifndef _JC_USER_CROP_H_
#define _JC_USER_CROP_H_


namespace JC_user_crop{

	void checkNeighbor(cv::Point &p, cv::Mat &label_image, vector<vector<cv::Point> > &areaPoint){

		/* local blob count */
		int x[] = {p.x, p.x, p.x+1, p.x-1};
		int y[] = {p.y+1, p.y-1, p.y, p.y};
		vector<int> _blobCount;
		_blobCount.resize(areaPoint.size()); 
		for(int k = 0; k< 4; k++){
			if( (x[k] < label_image.cols) && (x[k] >=0) && (y[k] <label_image.rows) &&(y[k] >=0) ){
				int *row2 = (int*)label_image.ptr(y[k]);
				_blobCount[row2[x[k]]] = 1;
			}
		}

		/*  */
		for(int i =0 ; i < areaPoint.size(); i++){
			if(_blobCount[i] == 1){
				areaPoint[i].push_back(p);
			}			
		}

	}

	void FindBlobs(bolbData &boundBlobs, std::vector<cv::Point> &remainingSource, std::vector<cv::Point> &remainingTarget_t, std::vector<vector<cv::Point>> &lostPoint ){

		const cv::Mat &binary = boundBlobs.binary;
		std::vector< std::vector<cv::Point2i> > &blobs = boundBlobs.blobs;
		std::vector<int> &blobsColor = boundBlobs.blobsColor;
		boundBlobs.totalRatio = 0;
		blobs.clear();
		cv::Mat label_image = binary.clone();
		int label_count = 4; // starts at 2 because 0,1 are used already

		for(int y=0; y < label_image.rows; y++) {
			int *row = (int*)label_image.ptr(y);

			for(int x=0; x < label_image.cols; x++) {
				if(row[x] != 1) { // 1 white
					continue;
				}

				cv::Rect rect;
				cv::floodFill(label_image, cv::Point(x,y), label_count, &rect, 0, 0, 4);

				std::vector <cv::Point2i> blob;

				for(int i=rect.y; i < (rect.y+rect.height); i++) {
					int *row2 = (int*)label_image.ptr(i);
					for(int j=rect.x; j < (rect.x+rect.width); j++) {

						if(row2[j] != label_count) 	continue;

						blob.push_back(cv::Point2i(j,i));
					}
				}

				blobs.push_back(blob);
				label_count++;
			}
		}
		blobsColor.resize(blobs.size());
		vector<vector<cv::Point>> tarAreaPoint;
		vector<vector<cv::Point>> srcAreaPoint;
		tarAreaPoint.resize(label_count);
		srcAreaPoint.resize(label_count);

		/* find blobs neighbor contour */
		for(int p = 0 ; p < remainingSource.size(); p++){
			checkNeighbor(remainingSource[p], label_image, srcAreaPoint);
		}
		for(int p = 0 ; p < remainingTarget_t.size(); p++){
			checkNeighbor(remainingTarget_t[p], label_image, tarAreaPoint);
		}
		for (int p = 4 ; p < label_count; p++)
		{

			if(srcAreaPoint[p].size()>tarAreaPoint[p].size()){
				blobsColor[p-4] = 0;
				boundBlobs.totalRatio += srcAreaPoint[p].size();
				lostPoint.push_back(tarAreaPoint[p]);
			}else{
				blobsColor[p-4] = 1;
				//boundBlobs.totalRatio += tarAreaPoint[p].size();
				lostPoint.push_back(srcAreaPoint[p]);
			}
		}

	}


	void drawMat(cv::Mat &OMat ,std::vector<cv::Point2i> &blobs, cv::Scalar &color){

		for(size_t i=0; i < blobs.size(); i++) {
			int x = blobs[i].x;
			int y = blobs[i].y;
			if((x < OMat.cols) && (x >=0) && (y <OMat.rows) &&(y >=0)){
				OMat.at<cv::Vec3b>(y,x)[0] = color.val[0];
				OMat.at<cv::Vec3b>(y,x)[1] = color.val[1];
				OMat.at<cv::Vec3b>(y,x)[2] = color.val[2];
			}		
		}
	}

	void ColorBolbs(cv::Mat &OMat, bolbData &boundBlobs){

		ostringstream oss;		
		cv::Scalar color;

		for(size_t i=0; i < boundBlobs.blobs.size(); i++) {
			if(boundBlobs.blobsColor[i]==1)
				color = cv::Scalar(0,0,0);
			else
				color = cv::Scalar(255,255,255);			
			drawMat(OMat, boundBlobs.blobs[i], color);
		}
	}

	void crop_by_rect(std::vector<std::pair<float, HungarianType > > &candidate, std::string &fileName, CropType &cropData, int idx){
		HungarianType &Hdata = candidate[idx].second;
		ostringstream oss;
		oss<< idx <<"_size_"<<Hdata.size;

		int rWidth = Hdata.boundRect.br().x - Hdata.boundRect.tl().x;
		int rHeight = Hdata.boundRect.br().y - Hdata.boundRect.tl().y;

		cv::Mat warpImg(rHeight, rWidth, CV_8UC3, 1);

		JC::drawLineContour(warpImg, Hdata.compositeContour, cv::Scalar(255,0,0),  2);
		JC::drawLineContour(warpImg, Hdata.target, cv::Scalar(255,255,0), 2);
		cv::Point vOne, vThree;
		//JC_window_editing::cropping(warpImg, vOne, vThree, cropData.rect);
		vOne = cropData.rect.tl();
		vThree = cropData.rect.br();

		cv::Mat boundImg(rHeight, rWidth , CV_8UC1, 1);	
		cv::rectangle(boundImg, vOne, vThree, 0);

		/* initial binary image */
		bolbData boundBlobs;
		cv::threshold(boundImg, boundBlobs.binary, 0.0, 1.0, cv::THRESH_BINARY);		
		boundBlobs.binary.convertTo(boundBlobs.binary, CV_32SC1);

		/* find source, target blob */
		vector<vector<cv::Point>> srcTarBlobs;
		srcTarBlobs.push_back( Hdata.compositeContour);
		srcTarBlobs.push_back( Hdata.target);
		vector<vector<cv::Point>> inner_srcTarBlobs;
		vector<vector<cv::Point>> inner_tarTarBlobs;
		for (int i =0; i < Hdata.inner_contours_src.size(); i++)
			inner_srcTarBlobs.push_back(Hdata.inner_contours_src[i]);
		for (int i =0; i < Hdata.inner_contours_tar.size(); i++)
			inner_tarTarBlobs.push_back(Hdata.inner_contours_tar[i]);

		cv::drawContours(boundBlobs.binary, srcTarBlobs, 0,  2, CV_FILLED);
		cv::drawContours(boundBlobs.binary, srcTarBlobs, 1,  3, CV_FILLED);
		cv::Mat binaryWithIni = boundBlobs.binary.clone();
		vector<vector<cv::Point>> lostPoint;
		FindBlobs(boundBlobs, Hdata.remainingSource, Hdata.remainingTarget_t, lostPoint);


		/* output */
		cv::Mat output = cv::Mat::zeros(boundImg.size(), CV_8UC3);
		ColorBolbs(output, boundBlobs);
		cv::drawContours(output, srcTarBlobs, 1,  cv::Scalar(255,255,255), CV_FILLED);
		cv::drawContours(output, srcTarBlobs, 0,  cv::Scalar(0,0,0), CV_FILLED);

		for (int i =0; i < Hdata.inner_contours_src.size(); i++)
			cv::drawContours(output, inner_srcTarBlobs, i,  cv::Scalar(255,255,255), CV_FILLED);
		for (int i =0; i < Hdata.inner_contours_tar.size(); i++)
			cv::drawContours(output, inner_tarTarBlobs, i,  cv::Scalar(0,0,0), CV_FILLED);

		vOne.x = vOne.x + 1;
		vOne.y = vOne.y + 1;
		cv::Rect rect(vOne, vThree);
		cv::Mat croppingImg = output(rect).clone();

		cropData.cropMat = croppingImg;
		cropData.rect = rect;
		//cv::imshow("candidtae", croppingImg);
	}

	void user_crop(std::vector<std::pair<float, HungarianType > > &candidate, std::string &fileName, CropType &cropData, int idx){

		
		
		HungarianType &Hdata = candidate[idx].second;
		ostringstream oss;
		oss<< idx <<"_size_"<<Hdata.size;

		int rWidth = Hdata.boundRect.br().x - Hdata.boundRect.tl().x;
		int rHeight = Hdata.boundRect.br().y - Hdata.boundRect.tl().y;

		cv::Mat warpImg(rHeight, rWidth, CV_8UC3, 1);

		JC::drawLineContour(warpImg, Hdata.compositeContour, cv::Scalar(255,0,0),  2);
		JC::drawLineContour(warpImg, Hdata.target, cv::Scalar(255,255,0), 2);
		cv::Point vOne, vThree;
		JC_window_editing::cropping(warpImg, vOne, vThree, cropData.rect);

		cv::Mat boundImg(rHeight, rWidth , CV_8UC1, 1);	
		cv::rectangle(boundImg, vOne, vThree, 0);

		/* initial binary image */
		bolbData boundBlobs;
		cv::threshold(boundImg, boundBlobs.binary, 0.0, 1.0, cv::THRESH_BINARY);		
		boundBlobs.binary.convertTo(boundBlobs.binary, CV_32SC1);

		/* find source, target blob */
		vector<vector<cv::Point>> srcTarBlobs;
		srcTarBlobs.push_back( Hdata.compositeContour);
		srcTarBlobs.push_back( Hdata.target);
		vector<vector<cv::Point>> inner_srcTarBlobs;
		vector<vector<cv::Point>> inner_tarTarBlobs;
		for (int i =0; i < Hdata.inner_contours_src.size(); i++)
			inner_srcTarBlobs.push_back(Hdata.inner_contours_src[i]);
		for (int i =0; i < Hdata.inner_contours_tar.size(); i++)
			inner_tarTarBlobs.push_back(Hdata.inner_contours_tar[i]);

		cv::drawContours(boundBlobs.binary, srcTarBlobs, 0,  2, CV_FILLED);
		cv::drawContours(boundBlobs.binary, srcTarBlobs, 1,  3, CV_FILLED);
		cv::Mat binaryWithIni = boundBlobs.binary.clone();
		vector<vector<cv::Point>> lostPoint;
		FindBlobs(boundBlobs, Hdata.remainingSource, Hdata.remainingTarget_t, lostPoint);


		/* output */
		cv::Mat output = cv::Mat::zeros(boundImg.size(), CV_8UC3);
		ColorBolbs(output, boundBlobs);
		cv::drawContours(output, srcTarBlobs, 1,  cv::Scalar(255,255,255), CV_FILLED);
		cv::drawContours(output, srcTarBlobs, 0,  cv::Scalar(0,0,0), CV_FILLED);

		for (int i =0; i < Hdata.inner_contours_src.size(); i++)
			cv::drawContours(output, inner_srcTarBlobs, i,  cv::Scalar(255,255,255), CV_FILLED);
		for (int i =0; i < Hdata.inner_contours_tar.size(); i++)
			cv::drawContours(output, inner_tarTarBlobs, i,  cv::Scalar(0,0,0), CV_FILLED);

		vOne.x = vOne.x + 1;
		vOne.y = vOne.y + 1;
		cv::Rect rect(vOne, vThree);
		cv::Mat croppingImg = output(rect).clone();

		cropData.cropMat = croppingImg;
		cropData.rect = rect;
		//cv::imshow("candidtae", croppingImg);

	}

}

#endif
