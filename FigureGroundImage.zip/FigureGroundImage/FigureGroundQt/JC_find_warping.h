// Longest Increasing Subsequence.cpp : Defines the entry point for the console application.
#include "stdafx.h"
#define _USE_MATH_DEFINES 
using namespace cv;
using namespace std;
#include <math.h>
#include "SchaeferMLS.h"
#include "CurveSignature.h"
#include "std.h"
#include "JC_functions.h"
#include "JC_powell.h"
#include "JC_type.h"
#include "JC_GaussianDistribution.h"
#include "JC_opt_function.h"

#ifndef _JC_WARP_
#define _JC_WARP_

namespace JC_warping{

	void drawMatch(vector<cv::Point> &p1, vector<cv::Point> &p2 ,cv::Mat &OutImage, cv::Scalar &color){

		for(int i = 0 ; i < p1.size(); i++)
		{			
			cv::line(OutImage, p1[i], p2[i], color, 1 );
		}
	}

	void opt_warp(std::vector<std::pair<float, HungarianType > > &candidate, int warp_idx, int warp_type){
		HungarianType &Hdata = candidate[warp_idx].second;

		//for deformation input
		std::vector<cv::Point> &src = Hdata.source;
		std::vector<cv::Point> &tar = Hdata.target;
		std::vector<cv::Point> &match_src = Hdata.match_src;
		std::vector<cv::Point> &match_tar = Hdata.match_tar;
		std::vector<float> &concave_src = Hdata.curveSource; 
		std::vector<float> &concave_tar = Hdata.curveTarget;
		std::vector<int> &match_idx_src = Hdata.match_index_src; 
		std::vector<int> &match_idx_tar = Hdata.match_index_tar;
		std::vector<int> &feature_idx_src = Hdata.feature_index_src;
		std::vector<int> &feature_idx_tar = Hdata.feature_index_tar;
		std::vector<int> match_feature_idx_src;
		std::vector<int> match_feature_idx_tar;
		std::vector<int> match_feature_num_src;
		std::vector<int> match_feature_num_tar;
		std::vector<int> IS_idx_src = Hdata.IS_idx_src;
		std::vector<int> IS_idx_tar = Hdata.IS_idx_tar;

		//for MLS
		vector<Point2d> src_p2d;
		vector<Point2d> tar_p2d;
		vector<int> ctPoints_src;
		vector<int> ctPoints_tar;
		SchaeferMLS<double> smls_src;
		SchaeferMLS<double> smls_tar;

		//remove intersection
		std::vector<cv::Point> non_collision_match_src;
		std::vector<cv::Point> non_collision_match_tar; 
		std::vector<int> collision_idx_src;
		std::vector<int> collision_idx_tar;
		std::vector<int> non_collision_match_idx_src;
		std::vector<int> non_collision_match_idx_tar;

		//remove intersection
		JC_OPT::remove_self_collision(match_src, match_tar, match_idx_src, match_idx_tar, 
			non_collision_match_src, non_collision_match_tar, 
			non_collision_match_idx_src, non_collision_match_idx_tar,
			collision_idx_src, collision_idx_tar);

		JC_OPT::find_match_feature_idx(non_collision_match_idx_src, feature_idx_src, match_feature_idx_src, match_feature_num_src);
		JC_OPT::find_match_feature_idx(non_collision_match_idx_tar, feature_idx_tar, match_feature_idx_tar, match_feature_num_tar);

// 		cv::Mat canvas(700, 600, CV_8UC3);
// 		drawMatch( match_src, match_tar, canvas, cv::Scalar(0,0,255));
// 		drawMatch( non_collision_match_src, non_collision_match_tar, canvas, cv::Scalar(0,255,255));
// 		imshow("canvas", canvas);

		std::vector<int> ctrl_idx_src; 
		std::vector<int> ctrl_idx_tar;
		std::vector<int> ctrl_idx_def; 

		//find the match segment correspondence ctrl points and endpoint
		JC_OPT::find_ctrl_idx(ctrl_idx_src, ctrl_idx_tar, ctrl_idx_def, non_collision_match_idx_src, non_collision_match_idx_tar, 
			match_feature_num_src, match_feature_num_tar);

// 		JC_OPT::find_ctrl_idx_from_IS_Match(ctrl_idx_src, ctrl_idx_tar, ctrl_idx_def, non_collision_match_idx_src, non_collision_match_idx_tar, 
// 			IS_idx_src, IS_idx_tar);
		

		std::vector<int> MLS_ctrl_src(0);
		std::vector<int> MLS_ctrl_tar(0);

		//MLS_ctrl : MLS_dectect_ctrl - discovered point and remove the match segment
		JC_OPT::add_MLS_ctrls(src, tar, ctrl_idx_src, ctrl_idx_tar, MLS_ctrl_src, MLS_ctrl_tar, non_collision_match_idx_src, non_collision_match_idx_tar,match_idx_src,match_idx_tar);

		//remove the nearest points
// 		if(MLS_ctrl_src.size() >= 2){
// 			JC_OPT::remove_nearest_ctrl(non_collision_match_idx_src.front(), src, MLS_ctrl_src, src);
// 			JC_OPT::remove_nearest_ctrl(non_collision_match_idx_src.back(), src, MLS_ctrl_src, src);
// 		}
// 
// 		if(MLS_ctrl_tar.size() >= 2){
// 			JC_OPT::remove_nearest_ctrl(non_collision_match_idx_tar.front(), tar, MLS_ctrl_tar, tar);
// 			JC_OPT::remove_nearest_ctrl(non_collision_match_idx_tar.back(), tar, MLS_ctrl_tar, tar);
// 		}
		std::vector<int> union_ctrl_src_warp = MLS_ctrl_src;
		std::vector<int> union_ctrl_tar_warp = MLS_ctrl_tar;


		std::vector<int>::iterator it = union_ctrl_src_warp.begin();
		union_ctrl_src_warp.insert(it, ctrl_idx_src.begin(), ctrl_idx_src.end());	

		it = union_ctrl_tar_warp.begin();
		union_ctrl_tar_warp.insert(it, ctrl_idx_tar.begin(), ctrl_idx_tar.end());	

		std::vector<int> union_ctrl_src = MLS_ctrl_src;
		std::vector<int> union_ctrl_tar = MLS_ctrl_tar;
		//union_ctrl : ctrl_idx + MLS_ctrl
		it = union_ctrl_src.begin();
		it = union_ctrl_src.insert(it, ctrl_idx_src.front());	
		union_ctrl_src.insert(it, ctrl_idx_src.back());

		it = union_ctrl_tar.begin();
		it = union_ctrl_tar.insert(it, ctrl_idx_tar.front());
		union_ctrl_tar.insert(it, ctrl_idx_tar.back());

		optType optData(src, tar, match_src, match_tar, concave_src, concave_tar, 
			feature_idx_src, feature_idx_tar, match_idx_src, match_idx_tar, 
			match_feature_idx_src, match_feature_idx_tar, ctrl_idx_src, ctrl_idx_tar, 
			ctrl_idx_def, MLS_ctrl_src, MLS_ctrl_tar, union_ctrl_src, union_ctrl_tar,
			non_collision_match_idx_src, non_collision_match_idx_tar, collision_idx_src, collision_idx_tar,
			union_ctrl_src_warp, union_ctrl_tar_warp);

//  [4/29/2015 jollytrees]

		/*
		 		cv::Scalar color_red(0,0,255);
		 		cv::Scalar color_green(0,255,0);
		 		cv::Scalar color_blue(255,0,0);
		 
		 		cv::Scalar color_yellow(0,255,255);
		 		cv::Scalar color_lightBlue(255,255,0);
		 		cv::Scalar color_purple(255,0,255);
		 
		 		cv::Scalar color_white(255,255,255);
				cv::Scalar color_black(0,0,0);

		 		cv::Mat MLS_canvas(Size(700,700), CV_8UC3);
		  		cv::Mat MLS_canvas2(Size(700,700), CV_8UC3);
		 
				MLS_canvas2.setTo(color_white);
	
				JC::drawLineContour(MLS_canvas2, Hdata.target, color_blue, 2);
				JC::drawLineContourN(MLS_canvas2, Hdata.source, color_black, 2);
				JC::drawLineContourN(MLS_canvas2, non_collision_match_src, color_lightBlue, 2);
				JC::drawLineContourN(MLS_canvas2, non_collision_match_tar, color_purple, 2);
		 
		imshow("controlmap", MLS_canvas2);	*/
		

		JC_powell::get_powell(optData, warp_idx, Hdata, warp_type);


	}


}

#endif
