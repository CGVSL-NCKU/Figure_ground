#include "stdafx.h"
#pragma comment(linker, "/SUBSYSTEM:CONSOLE /ENTRY:WinMainCRTStartup")  ///show the console windows.
#ifndef FIGUREGROUNDQT_H
#define FIGUREGROUNDQT_H

#include <QtWidgets/QMainWindow>
#include "ui_figuregroundqt.h"
#include "JC_type.h"
#include <QtGui/QPixmap>
#include <QtGui/QDragEnterEvent>
#include <QtGui/QDropEvent>
#include <QMimeData>
#include <QLabel>
#include <QEvent>
#include <QTableWidget>
#include <QRadioButton>

class FigureGroundQt : public QMainWindow
{
	Q_OBJECT

public:
	FigureGroundQt(QWidget *parent = 0);
	~FigureGroundQt();
	void clickCandidte(int idx, QLabel *label, QTabWidget *tabWidget);
	void outputTime();
	int lockDrop_src;
	int lockDrop_tar;
	double size_src;
	double size_tar;
	int click_candidate;
	int warp_type;

	cv::Mat cropping_src;
	cv::Mat cropping_tar;

	double first_step_time;
	double warp_time;
	double crop_time;

	ContourType Figure_Contour;
	ContourType Ground_Contour;
	ContourType Figure_Contours[10];
	ContourType Ground_Contours[10];

	FG_Type FG[10];
	std::vector<std::pair<float, HungarianType > > g_candidate;
	CropType g_cropData[5];

	int clickCount;
	int processDone;

	double w_length;
	double w_orientation;
	double w_deformation;
	double w_convexity;

protected:
	bool eventFilter(  QObject *watched, QEvent *event);

private:
	void createActions();
	void createMenus();

	Ui::FigureGroundQtClass ui;
	QAction *aboutQtAct;
	QMenu *fileMenu;
	QLineEdit *length_para;
	QLineEdit *orientation_para;
	QLineEdit *deformation_para;
	QLineEdit *convexity_para;
	QRadioButton *auto_warping;
	QRadioButton *warp_to_target;
	QRadioButton *warp_to_source;
	std::vector<int> ctrl_idx_src; 
		std::vector<int> ctrl_idx_tar;
	QWidget *window;

private slots:
	void click_next1();
	void click_edit1();
	void click_previous();
	void radio_auto();
	void radio_source();
	void radio_target();
	void parameter();
	void setWeight();
	void editWarp();
	void saveImg();
	void figure_change();
	void ground_change();
};

#endif // FIGUREGROUNDQT_H
