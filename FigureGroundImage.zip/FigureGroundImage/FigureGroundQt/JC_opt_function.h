// Longest Increasing Subsequence.cpp : Defines the entry point for the console application.
#include "stdafx.h"
using namespace std;
using namespace cv;
#include <fstream>
#include "SchaeferMLS.h"
#include "CurveSignature.h"
#include "std.h"
#include "Utils_Ocv.h"
#include <math.h>

#ifndef _JC_OPT_
#define _JC_OPT_

namespace JC_OPT{
	template<class T>
	static void removeT(std::vector<T> &v, int i)
	{
		std::vector<T>::iterator it = v.begin();
		std::advance(it, i);
		v.erase(it);
	}

	bool test_connect_collision( int &tIndex, cv::Point &b  ,vector<cv::Point> &src, vector<cv::Point> &tar){
		bool collide = false;
		cv::Point &a = src[tIndex];

		for(int i =0; i < src.size(); i++){
			if(i== tIndex)continue;

			cv::Point &c = src[i];
			cv::Point &d = tar[i];
			float den = ((d.y-c.y)*(b.x-a.x)-(d.x-c.x)*(b.y-a.y));
			float num1 = ((d.x - c.x)*(a.y-c.y) - (d.y- c.y)*(a.x-c.x));
			float num2 = ((b.x-a.x)*(a.y-c.y)-(b.y-a.y)*(a.x-c.x));
			float u1 = num1/den;
			float u2 = num2/den;

			// The two lines are coincidences 
			if (den == 0 && num1  == 0 && num2 == 0)
				collide = true;

			// The two lines are parallel
			if (den == 0)
				collide = false;

			// Lines do not collide/
			if (u1 <0 || u1 > 1 || u2 < 0 || u2 > 1)
				collide = false;

			if (collide==false) continue;

			// Lines DO collide
			collide = true;
			break;

		}
		return collide;
	}

	bool test_self_collision(int tIndex, cv::Point &b , vector<cv::Point> &src){
		bool collide = false;
		cv::Point &a = src[tIndex];
		for(int i =0; i < src.size()-1; i++){
			if(i==tIndex || (i+1) == tIndex) continue;
			cv::Point &c = src[i];
			cv::Point &d = src[i+1];
			float den = ((d.y-c.y)*(b.x-a.x)-(d.x-c.x)*(b.y-a.y));
			float num1 = ((d.x - c.x)*(a.y-c.y) - (d.y- c.y)*(a.x-c.x));
			float num2 = ((b.x-a.x)*(a.y-c.y)-(b.y-a.y)*(a.x-c.x));
			float u1 = num1/den;
			float u2 = num2/den;

			// The two lines are coincidences 
			if (den == 0 && num1  == 0 && num2 == 0){
				collide = true;
				continue;
			}


			// The two lines are parallel
			if (den == 0){
				collide = false;
				continue;
			}


			// Lines do not collide/
			if (u1 <0 || u1 > 1 || u2 < 0 || u2 > 1){
				collide = false;
				continue;
			}

			// Lines DO collide
			collide = true;
			break;

		}
		return collide;
	}

	void remove_self_collision(
		vector<cv::Point> match_src, vector<cv::Point> match_tar, 
		vector<int> &match_idx_src, vector<int> &match_idx_tar,
		vector<cv::Point> &non_collision_src, vector<cv::Point> &non_collision_tar, 
		vector<int> &non_collision_match_idx_src, vector<int> &non_collision_match_idx_tar,
		vector<int> &collision_idx_src, vector<int> &collision_idx_tar)
	{
		

		//self intersection
		for(int i=0; i < match_src.size(); i++){
			bool collision_flag_src = test_self_collision(i, match_tar[i], match_src);
			bool collision_flag_tar = test_self_collision(i, match_src[i], match_tar);
			if(collision_flag_src||collision_flag_tar){
				collision_idx_src.push_back(i);
				collision_idx_tar.push_back(i);
				//cv::line(canvas, match_tar[i], match_src[i], cv::Scalar(0,255,0), 1 );
				continue;
			}
			//cv::line(canvas, match_tar[i], match_src[i], cv::Scalar(0,255,255), 1 );
			non_collision_src.push_back(match_src[i]);
			non_collision_tar.push_back(match_tar[i]);	
			non_collision_match_idx_src.push_back(match_idx_src[i]);
			non_collision_match_idx_tar.push_back(match_idx_tar[i]);
		}

		//connect intersection
		for(int i=0; i < non_collision_src.size(); i++){

			bool collide = test_connect_collision(i, non_collision_tar[i] , non_collision_src, non_collision_tar);
			if (collide)
			{
				removeT<cv::Point>(non_collision_src, i);
				removeT<cv::Point>(non_collision_tar, i);
				removeT<int>(non_collision_match_idx_src, i);
				removeT<int>(non_collision_match_idx_tar, i);
				collision_idx_src.push_back(non_collision_match_idx_src[i]);
				collision_idx_tar.push_back(non_collision_match_idx_tar[i]);
				i--;
			}else{
				cv::Point vec = non_collision_src[i] - non_collision_tar[i];
				double vec_norm = cv::norm(vec);
				if (vec_norm > 20)
				{
					removeT<cv::Point>(non_collision_src, i);
					removeT<cv::Point>(non_collision_tar, i);
					removeT<int>(non_collision_match_idx_src, i);
					removeT<int>(non_collision_match_idx_tar, i);
					collision_idx_src.push_back(non_collision_match_idx_src[i]);
					collision_idx_tar.push_back(non_collision_match_idx_tar[i]);
					i--;
				}
			}
		}
		
	}

	void find_match_feature_idx( vector<int> &match_idx, vector<int> &feature_idx, vector<int> &ctrl_idx, vector<int> &match_feature_num){

		for( int i=0; i < match_idx.size(); i++ ){
			std::vector<int>::iterator it;
			it = find(feature_idx.begin(), feature_idx.end(), match_idx[i]);

			if(it!=feature_idx.end()){
				std::vector<int>::iterator it_ctrl;
				it_ctrl = find(ctrl_idx.begin(), ctrl_idx.end(), match_idx[i]);

				if(it_ctrl==ctrl_idx.end()){
					ctrl_idx.push_back(match_idx[i]);
					match_feature_num.push_back(i);
				}
			} 
		}

	}
	bool is_mid_pt(int idx, int f, int b){

		//front & back
		int eq1 = abs(idx-f) + abs(idx-b) ;
		int eq2 = abs(f-b);
		if(eq1==eq2)
			return true;
		return false;
	}

	bool is_remaining_pts(int idx, std::vector<int> &non_collision_match_idx, std::vector<int> &match_idx){

		std::vector<int>::iterator it_front =  find(match_idx.begin(), match_idx.end(), non_collision_match_idx.front());
		std::vector<int>::iterator it_back  =  find(match_idx.begin(), match_idx.end(), non_collision_match_idx.back());
		//find the collision front & back in the match idx
		int non_collision_idx_front = std::distance(match_idx.begin(), it_front);
		int non_collision_idx_back = std::distance(match_idx.begin(), it_back);


		std::vector<int>::iterator it = find(non_collision_match_idx.begin(), non_collision_match_idx.end(), idx);
		std::vector<int>::iterator it_match_idx = find(match_idx.begin(), match_idx.end(), idx);
		int match_idx_dist = std::distance(match_idx.begin(), it_match_idx);

		//i != non_collision_match_idx
		if( (it==non_collision_match_idx.end()) ){

			std::vector<int>::iterator it_match = find(match_idx.begin(), match_idx.end(), idx);
			if(it_match!=match_idx.end()){
				int i_to_match_idx = std::distance(match_idx.begin(), it_match);
				bool is_mid = is_mid_pt(i_to_match_idx, non_collision_idx_front, non_collision_idx_back);
				if(is_mid==true)
					return false;		
			}
			// not in non_collision_match_idx & not in match_idx -> not match segment
			return true;
		}else{
			// is match points
			return false;
		}

		
	}

	//match_feature_num : non_collision_match_idx
	void add_MLS_ctrls(vector<cv::Point> &src, vector<cv::Point> &tar, vector<int> &ctrl_idx_src, vector<int> &ctrl_idx_tar, 
		vector<int> &MLS_ctrl_src, vector<int> &MLS_ctrl_tar, std::vector<int> &match_feature_num_src, std::vector<int> &match_feature_num_tar, std::vector<int> &match_idx_src, std::vector<int> &match_idx_tar){

			vector<Point2d> src_p2d, tar_p2d;
			ConvertCurve(src, src_p2d);
			ConvertCurve(tar, tar_p2d);
			vector<Point2d> src_p2d_smoothed;
			vector<Point2d> tar_p2d_smoothed;
			vector<pair<char,int> > stringrep_src = CurvatureExtrema(src_p2d, src_p2d_smoothed, 0.025, 3.0);
			vector<pair<char,int> > stringrep_tar = CurvatureExtrema(tar_p2d, tar_p2d_smoothed, 0.025, 3.0);

			vector<int> temp_ctrl_src;
			vector<int> temp_ctrl_tar;
			for(int i=0; i<stringrep_src.size(); i++)
				temp_ctrl_src.push_back(stringrep_src[i].second);

			for(int i=0; i< stringrep_tar.size(); i++)
				temp_ctrl_tar.push_back(stringrep_tar[i].second);

			//put the undiscovered points to MLS_ctrl
			for (int i=0; i<temp_ctrl_src.size(); i++)
			{
				std::vector<int> ::iterator it;
				it = find(ctrl_idx_src.begin(), ctrl_idx_src.end(), temp_ctrl_src[i]);
				if(it == ctrl_idx_src.end()){
					std::vector<int> ::iterator it_match;
					it_match = find(match_feature_num_src.begin(), match_feature_num_src.end(), temp_ctrl_src[i]);
					bool is_remaining =  is_remaining_pts(temp_ctrl_src[i], match_feature_num_src, match_idx_src);
					if (it_match == match_feature_num_src.end() && is_remaining)
						MLS_ctrl_src. push_back(temp_ctrl_src[i]);
				}
					
			}
			for (int i=0; i<temp_ctrl_tar.size(); i++)
			{
				std::vector<int> ::iterator it;
				it = find(ctrl_idx_tar.begin(), ctrl_idx_tar.end(), temp_ctrl_tar[i]);
				if(it == ctrl_idx_tar.end()){
					std::vector<int> ::iterator it_match;
					it_match = find(match_feature_num_tar.begin(), match_feature_num_tar.end(), temp_ctrl_tar[i]);
					bool is_remaining =  is_remaining_pts(temp_ctrl_tar[i], match_feature_num_tar, match_idx_tar);
					if (it_match == match_feature_num_tar.end() && is_remaining)
						MLS_ctrl_tar. push_back(temp_ctrl_tar[i]);
				}
					
			}
	}


	void find_ctrl_idx(	std::vector<int> &ctrl_idx_src, std::vector<int> &ctrl_idx_tar, std::vector<int> &ctrl_idx_def, std::vector<int> &match_idx_src, std::vector<int> &match_idx_tar,
		std::vector<int> &match_feature_num_src, std::vector<int> &match_feature_num_tar){


			//match_feature_num : match_feature_num_src + match_feature_num_tar
			std::vector<int> match_feature_num = match_feature_num_src;

			for(int i =0; i < match_feature_num_tar.size(); i++){
				std::vector<int>::iterator it;
				it = find( match_feature_num.begin(), match_feature_num.end(), match_feature_num_tar[i] );
				if(it == match_feature_num.end()){	
					match_feature_num.push_back(match_feature_num_tar[i]);
				}
			}

			//insert endpoint 0
			std::vector<int>::iterator it;
			it = find( match_feature_num.begin(), match_feature_num.end(),  0);
			if(it == match_feature_num.end()){
				match_feature_num.push_back(0);
			}

			//insert endpoint end
			it = find( match_feature_num.begin(), match_feature_num.end(),  match_idx_src.size()-1);
			if(it == match_feature_num.end()){
				match_feature_num.push_back(match_idx_src.size()-1);
			}

			sort(match_feature_num.begin(), match_feature_num.end());

			for (int i =0; i < match_feature_num.size(); i++){
				int idx = match_feature_num[i];
				ctrl_idx_src.push_back(match_idx_src[idx]);
				ctrl_idx_tar.push_back(match_idx_tar[idx]);
			}

			ctrl_idx_def = ctrl_idx_tar;	

	}

	void find_ctrl_idx_from_IS_Match(std::vector<int> &ctrl_idx_src, std::vector<int> &ctrl_idx_tar, std::vector<int> &ctrl_idx_def, std::vector<int> &match_idx_src, std::vector<int> &match_idx_tar,
		std::vector<int> &IS_idx_src, std::vector<int> &IS_idx_tar){

			for(int i=0; i <match_idx_src.size(); i++){				
				std::vector<int>::iterator it;
				it = find( IS_idx_src.begin(), IS_idx_src.end(),  match_idx_src[i]);
				if (it != IS_idx_src.end())
				{
					ctrl_idx_src.push_back(match_idx_src[i]);
					ctrl_idx_tar.push_back(match_idx_tar[i]);
				}
			}

// 			//insert endpoint 0
// 			std::vector<int>::iterator it;
// 			it = find( ctrl_idx_src.begin(), ctrl_idx_src.end(),  match_idx_src.front());
// 			if(it == ctrl_idx_src.end()){
				ctrl_idx_src.push_back(match_idx_src[0]);
				ctrl_idx_tar.push_back(match_idx_tar[0]);
			//}

				//insert endpoint end
// 				it = find( ctrl_idx_src.begin(), ctrl_idx_src.end(),  match_idx_src.back());
// 				if(it == ctrl_idx_src.end()){
				ctrl_idx_src.push_back(match_idx_src.back());
				ctrl_idx_tar.push_back(match_idx_tar.back());
			//}
			

		ctrl_idx_def = ctrl_idx_tar;	

	}

	int remove_nearest_ctrl(int &pi, vector<cv::Point> &contour, vector<int>&MLS_idx, vector<cv::Point> &MLS_contour ){

		int nearestIndex = -1;
		float minDist = 999999;

		for (int i = 0; i< MLS_idx.size(); i++){

			double diff_x = MLS_contour[MLS_idx[i]].x - contour[pi].x ;
			double diff_y = MLS_contour[MLS_idx[i]].y - contour[pi].y ;
			double tempDist = sqrt( pow(diff_x,2) + pow(diff_y,2) );	

			if(tempDist < minDist){
				minDist = tempDist;
				nearestIndex = i;

			}
		}

		removeT(MLS_idx, nearestIndex);
		return nearestIndex;
	}


	//powell




}

#endif
