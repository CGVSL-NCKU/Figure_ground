#include "stdafx.h"
#ifndef _JC_GAUSSIAN_
#define _JC_GAUSSIAN_

namespace Gaussian{
	
	double GaussianTransfer(double &x, double u, double stddev){

		double PI = 3.14159;
		double transferValue;
		transferValue = ( 1/(stddev*sqrt(2*PI)) ) * exp( -pow((x-u),2)/ (2*pow(stddev,2)) );

		return transferValue;
	}

}

#endif
