 #include "stdafx.h"
#include "JC_type.h"
#include "JC_functions.h"
#ifndef _JC_IS_MATCH_H_
#define _JC_IS_MATCH_H_

namespace IS_Match{

	/* set the used parameters */
	int sample_point= 7;
	int IS_match_delta = 3;


	/************************************************************************/
	/*	_IS_contour : IS_contour_source / IS_contour_target;                                                            
	/*  _descriptor : initialed descriptor;
	/************************************************************************/
	void initDescriptor(std::vector<cv::Point> &_IS_contour , std::vector<Descriptor > &_descriptor){

		/* i define the first point*/
		_descriptor.resize( _IS_contour.size() );
		for( int i = 0 ; i < _IS_contour.size() ; i++ ){
			int _contour_size = _IS_contour.size();

			std::vector<cv::Point> _temp_contour;
			for( int k = i ; k < _contour_size ; k++ ) _temp_contour.push_back( _IS_contour[k] );
			for( int k = 0 ; k < i ; k++ ) _temp_contour.push_back( _IS_contour[k] );

			_descriptor[i].matrix.resize( _contour_size );
			for( int j = 0 ; j < _contour_size ; j++ ){
				_descriptor[i].matrix[j].resize( _contour_size );
				for(int k = 0 ; k < _contour_size ; k++ ){	
					int delta_index = ( k - IS_match_delta + _contour_size) % _contour_size; 

					cv::Point _vec1 = _temp_contour[j] - _temp_contour[k];
					cv::Point _vec2 = _temp_contour[delta_index] - _temp_contour[k];
					double _norm1 = cv::norm(_vec1);
					double _norm2 = cv::norm(_vec2);
					double _dotProduct = _vec1.dot(_vec2) ;
					cv::Point3d _vec3d_1 = cv::Point3d(_vec1.x, _vec1.y, 0);
					cv::Point3d _vec3d_2 = cv::Point3d(_vec2.x, _vec2.y, 0);
					cv::Point3d _crossProduct = _vec3d_1.cross(_vec3d_2);

					double theta  = acos( _dotProduct / ( _norm1 * _norm2) ) * 180 / 3.1415;

					if( theta<0 || theta>180 ) theta = 0;
					if( _crossProduct.z > 0 ) theta = 360 -theta;

					_descriptor[i].matrix[j][k] = (int)theta ;

				}

			}

		}

	}

	/************************************************************************/
	/*	_descriptor1 : descriptor_source / descriptor_target (the bigger size one.);                                                        
	/*  _descriptor2 : descriptor_source / descriptor_target (the smaller size one.);
	/*  _diff		 : descriptor_diff;
	/************************************************************************/
	void initDiffMatrix(std::vector<Descriptor> &_descriptor1, std::vector<Descriptor> &_descriptor2, std::vector<Descriptor> &_diff){

		_diff.resize( _descriptor1.size() * _descriptor2.size() );	

		for(int i = 0 ; i < _descriptor1.size() ; i++){
			for(int j = 0 ; j <_descriptor2.size() ; j++){

				int index = i*_descriptor2.size() + j;
				_diff[index].matrix = _descriptor1[0].matrix;
				for(int k = 0 ; k < _descriptor1[i].matrix.size(); k ++){
					for(int n = 0 ; n < _descriptor1[i].matrix[k].size() ; n++){

						_diff[index].matrix[k][n]=   (_descriptor1[i].matrix[k][n] - _descriptor2[j].matrix[k][n])*(_descriptor1[i].matrix[k][n] - _descriptor2[j].matrix[k][n]);

					}

				}
			}
		}
	}

	/************************************************************************/
	/*	_diff		 : descriptor_diff;                                                        
	/************************************************************************/
	void initSummedAreaTable(std::vector<Descriptor > &_diff){

		std::vector<Descriptor > _temp = _diff;
		std::vector<Descriptor > _rows = _diff;
		/* i ���ܲĴX���I�}�Y��difference ->�n���i�I�}�Y��Summed Area Table */
		for(int i = 0 ; i < _diff.size() ; i++){
			for(int j = 0 ; j < _diff[i].matrix.size() ; j++){
				for(int k = 0 ; k < _diff[i].matrix[j].size() ; k++){

					if( k!=0 ) _rows[i].matrix[j][k] = _rows[i].matrix[j][k-1] + _temp[i].matrix[j][k];
					if( (j-1)>=0 && (k-1)>=0 ) _diff[i].matrix[j][k] = _diff[i].matrix[j-1][k] + _rows[i].matrix[j][k-1] + _temp[i].matrix[j][k];
					else if( (j-1)>=0 && (k-1)<0 ) _diff[i].matrix[j][k] = _diff[i].matrix[j-1][k] + _temp[i].matrix[j][k];
					else if( (j-1)<0 && (k-1)>=0 ) _diff[i].matrix[j][k] = _rows[i].matrix[j][k-1] + _temp[i].matrix[j][k];
					else _diff[i].matrix[j][k] = _temp[i].matrix[j][k];

				}
			}
		}
	}

	/************************************************************************/
	/*	_diff		 : descriptor_diff;                                                        
	/*  _cost		 : cost_matrix;
	/************************************************************************/
	void initCostMatrix(IS_Type &IS_Data, std::vector<Descriptor > &_diff, std::vector<std::vector<double> > &_cost, std::vector<MatchType> &matchData, ContourType &_source, ContourType &_target,
		int cost_bound,	int cost_contour_length){
		_cost.resize(_diff.size());
		std::vector<MatchType> _matchData;

		/* i = the first point */
		/* j = the matching length */
		for(int i = 0; i <_diff.size(); i ++){

			_cost[i].resize( _diff[i].matrix.size());
			//int last_length = 0 ;
			for(int j = 0; j <_diff[i].matrix.size() ; j++){
				int ist_length_tar = 0 ;
				int ist_length_src = 0 ;

				_cost[i][j] = _diff[i].matrix[j][j]/( (j+1)*(j+1) );
				if(_cost[i][j] > 0 && _cost[i][j] < cost_bound && (j+1) > cost_contour_length){
					//last_length = j;
					std::vector<cv::Point> _tempSrc, _tempTar;
					std::vector<int> _tempSrc_index, _tempTar_index;
					std::vector<cv::Point> _temp_interested_source_IS;
					std::vector<int> _temp_interested_source_IS_index;

					for(int k = i/IS_Data.IS_contour_target.size() ; k < i/IS_Data.IS_contour_target.size()+j+1 ;k++){

						_tempSrc.push_back( IS_Data.IS_contour_source[ (k + IS_Data.IS_contour_source.size()) % IS_Data.IS_contour_source.size()] );
						_tempSrc_index.push_back( (k + IS_Data.IS_contour_source.size()) % IS_Data.IS_contour_source.size() );
					
						std::vector<int>::iterator it = find(IS_Data.IS_ist_index_src.begin(), IS_Data.IS_ist_index_src.end(),  (k + IS_Data.IS_contour_source.size()) % IS_Data.IS_contour_source.size());
						if(it != IS_Data.IS_ist_index_src.end() ){
							ist_length_src++;
							_temp_interested_source_IS.push_back(_tempSrc[_tempSrc.size()-1]);
							_temp_interested_source_IS_index.push_back(_tempSrc.size()-1);
						}	
					
					
					}

					std::vector<int> _temp_interested_target_IS_index;
					std::vector<cv::Point> _temp_interested_target_IS;
					//transSrc_first.push_back( i/contour_2.size() );				
					//cout<<transSrc_index.size()<<endl;
					for(int k = i%IS_Data.IS_contour_target.size() ; k < i%IS_Data.IS_contour_target.size()+j+1 ;k++){
						//circle( mat_contour2 , contour_2[(k+contour_2.size())%contour_2.size()] , 5 , Scalar(0,255,0) , 4 , 5 , 0) ;
						_tempTar.push_back( IS_Data.IS_contour_target[(k + IS_Data.IS_contour_target.size()) % IS_Data.IS_contour_target.size()] );
						_tempTar_index.push_back( (k + IS_Data.IS_contour_target.size()) % IS_Data.IS_contour_target.size() );

						std::vector<int>::iterator it = find(IS_Data.IS_ist_index_tar.begin(), IS_Data.IS_ist_index_tar.end(),  (k + IS_Data.IS_contour_target.size()) % IS_Data.IS_contour_target.size());
						if(it != IS_Data.IS_ist_index_tar.end() ){
							ist_length_tar++;
							_temp_interested_target_IS.push_back(_tempTar[_tempTar.size()-1]);
							_temp_interested_target_IS_index.push_back(_tempTar_index.size()-1);
						}	

					}

					if(  (ist_length_tar>2 )&&(ist_length_tar > IS_Data.IS_contour_source.size()/8)&& (ist_length_tar > IS_Data.IS_contour_target.size()/8) &&
						 (ist_length_src>2 )&&(ist_length_src > IS_Data.IS_contour_source.size()/8) && (ist_length_src > IS_Data.IS_contour_target.size()/8)){
						MatchType mData;
						std::vector<cv::Point>  _match_source;
						std::vector<cv::Point>  _match_target;

						std::vector<int>  _match_index_source;
						std::vector<int>  _match_index_target;

						for(int k = 0; k < (_tempSrc.size()-1)*7; k ++){
							/* target points */
							int index_tar =   (_target.contour.size()/7 - _tempTar_index[0] )*7 -k;		
							index_tar = (index_tar + _target.contour.size()) % _target.contour.size();	
							_match_target.push_back(_target.contour[index_tar]);
							_match_index_target.push_back(index_tar);
							/* source points */
							int index_src = _tempSrc_index[0]*7 + k;
							index_src = (index_src + _source.contour.size()) % _source.contour.size();
							_match_source.push_back(_source.contour[index_src]);
							_match_index_source.push_back(index_src);
						}

// 						cv::Mat canvas1(500, 500, CV_8UC3);
// 						cv::Mat canvas2(500, 500, CV_8UC3);
// 						canvas1.setTo(0);
// 						canvas2.setTo(0);

						mData.match_source = _match_source;
						mData.match_target = _match_target;	

						mData.match_index_source = _match_index_source;
						mData.match_index_target = _match_index_target;

						mData.match_IS_source = _tempSrc;
						mData.match_IS_target = _tempTar;

						mData.match_IS_index_source = _tempSrc_index;
						mData.match_IS_index_target = _tempTar_index;

						mData.interested_IS_target = _temp_interested_target_IS;
						mData.interested_IS_index_target = _temp_interested_target_IS_index;
						
						mData.match_IS_length = ist_length_tar;
						mData.interested_IS_ratio = (float)ist_length_tar / (float)IS_Data.IS_ist_index_tar.size();
						mData.match_source_ratio = (float)_match_source.size() / (float)_source.contour.size();

						mData.source = _source;
						mData.target = _target;

						mData.IS_idx_src = IS_Data.IS_idx_src;
						mData.IS_idx_tar = IS_Data.IS_idx_tar;

						mData.IS_cost = _cost[i][j];

// 						JC::drawContour(canvas1, _source.contour, cv::Scalar(255,0,0), 1, 2);
// 						JC::drawContour(canvas2, _target.contour, cv::Scalar(0,255,255), 1, 2);
// 						JC::drawContour(canvas1, _match_source, cv::Scalar(255,255,0), 1, 2);
// 						JC::drawContour(canvas2, _match_target, cv::Scalar(255,255,0), 1, 2);
// 						JC::drawContour(canvas1, _temp_interested_source_IS, cv::Scalar(0,255,0), 5, 2);
// 						JC::drawContour(canvas2, _temp_interested_target_IS, cv::Scalar(0,255,0), 5, 2);
// 						ostringstream oss;
// 						oss << i;
// 
// 						imwrite("../cost/"+oss.str()+"_src.png", canvas1);
// 						imwrite("../cost/"+oss.str()+"_tar.png", canvas2);


						_matchData.push_back(mData);

					}
				}

			}

		}

		matchData = _matchData;

	}


	void findPartialMatch(ContourType source, ContourType target, std::vector<MatchType> &matchData){

		IS_Type IS_Data;
		std::vector<cv::Point> _contour_source = source.contour;
		std::vector<cv::Point> _contour_target = target.contour;
		std::vector<int> ist_index = target.user_defined_index;
		std::vector<int> ist_index_src = source.user_defined_index;

		int cost_bound;
		int cost_contour_length;

// 		cv::Mat canvas(500,500,CV_8UC3);
// 
// 		//std::cout << ist_index_src.size() << std::endl;
// 		for( int i =0; i < ist_index_src.size(); i++){
// 
// 			cv::circle(canvas, _contour_source[ist_index_src[i]], 2, cv::Scalar(255,0,0));
// 		}
// 		ostringstream oss;
// 		oss<<_contour_source.size();
// 		imwrite("../cropping/"+ oss.str()+".png", canvas);
// 		std::cout << "cout ist src" << std::endl;

		/* Initialize the contour of Partial Match. */
		for( int i = 0 ; i < _contour_source.size() ; i++ ){
			if((i % sample_point) == 0) {
				IS_Data.IS_contour_source.push_back( _contour_source[i] );
				IS_Data.IS_idx_src.push_back(i);
				std::vector<int>::iterator it = find(ist_index_src.begin(), ist_index_src.end(), i);
				if(it != ist_index_src.end() ){
					IS_Data.IS_ist_index_src.push_back(IS_Data.IS_contour_source.size()-1);
				}		
			}
		}

		for( int i = 0 ; i < _contour_target.size() ; i++ ){
			if((i % sample_point) == 0) {
				IS_Data.IS_idx_tar.push_back(i);
				IS_Data.IS_contour_target.push_back( _contour_target[i] );
				std::vector<int>::iterator it = find(ist_index.begin(), ist_index.end(), i);
				if(it != ist_index.end() ){
					IS_Data.IS_ist_index_tar.push_back(IS_Data.IS_contour_target.size()-1);
				}		
			}
		}

		/* 2014-12-17 */
		/* temp draw source */
// 		cv::Mat canvas(500, 500 , CV_8UC3, cv::Scalar(255,255,255));
// 		for(int i = 0 ; i < source.contour.size(); i ++){
// 			cv::circle(canvas, source.contour[i], 1, cv::Scalar(0,0,0),2);
// 		}
// 		for(int i = 0 ; i < IS_Data.IS_contour_source.size(); i ++){
// 			cv::circle(canvas, IS_Data.IS_contour_source[i], 4, cv::Scalar(0,0,255),4);
// 		}
// 
// 		cv::imwrite("source.png",canvas);
// 
// 		/* temp draw target */
// 		cv::Mat canvas2(500, 500 , CV_8UC3, cv::Scalar(255,255,255));
// 		for(int i = 0 ; i < target.contour.size(); i ++){
// 			cv::circle(canvas2, target.contour[i], 1, cv::Scalar(0,0,0),2);
// 		}
// 		for(int i = 0 ; i < IS_Data.IS_contour_target.size(); i ++){
// 			cv::circle(canvas2, IS_Data.IS_contour_target[i], 4, cv::Scalar(0,0,255),4);
// 		}
// 
// 		cv::imwrite("target.png",canvas2);


		cost_bound = 15000;

		int length_base_contour = _contour_source.size() < _contour_target.size() ? _contour_source.size() : _contour_target.size();
		cost_contour_length = (int)(length_base_contour*0.01);

// 		std::cout <<" _contour_source.size()"<< _contour_source.size()<< std::endl;
// 		std::cout <<" _contour_target.size()"<< _contour_target.size()<< std::endl;
// 		std::cout <<" cost_contour_length"<< cost_contour_length<< std::endl;
// 		std::cout <<" length_base_contour"<< length_base_contour<< std::endl;

		for( int i = 0 ; i < IS_Data.IS_ist_index_tar.size(); i ++){
			IS_Data.IS_ist_index_tar[i] = IS_Data.IS_contour_target.size() - IS_Data.IS_ist_index_tar[i] - 1;		
		}
		
		reverse(IS_Data.IS_contour_target.begin(), IS_Data.IS_contour_target.end());

		/* Initialize the descriptor of Partial Match. */
		initDescriptor(IS_Data.IS_contour_source, IS_Data.descriptor_source);
		initDescriptor(IS_Data.IS_contour_target, IS_Data.descriptor_target);

		/* Initialize the difference matrix of Partial Match. */
		if( IS_Data.descriptor_source[0].matrix.size() < IS_Data.descriptor_target[0].matrix.size() ){
			initDiffMatrix(IS_Data.descriptor_source, IS_Data.descriptor_target, IS_Data.descriptor_diff);
		}else{
			initDiffMatrix(IS_Data.descriptor_target, IS_Data.descriptor_source, IS_Data.descriptor_diff);
		}

		/* Initialize the summed area table. */
		initSummedAreaTable(IS_Data.descriptor_diff);

		source.IS_contour = IS_Data.IS_contour_source;
		target.IS_contour = IS_Data.IS_contour_target;

		/* Initialize the cost matrix with cost bound and length limitation of match contour . */
		initCostMatrix(IS_Data, IS_Data.descriptor_diff, IS_Data.cost_matrix, matchData , source, target,
			cost_bound, cost_contour_length);



// 		for (int i =0; i < matchData.size(); i++)
// 		{
// 			cv::Mat canvas(500, 500, CV_8UC3);
// 			canvas.setTo(255);
// 
// 			JC::drawContour(canvas, matchData[i].source.contour, cv::Scalar(0,0,0) , 1, 2);
// 			JC::drawContour(canvas, matchData[i].match_IS_source, cv::Scalar(0,0,255) , 6, 2);
// 
// 			ostringstream oss;
// 			oss << i ;
// 
// 			imwrite("../cost/"+ oss.str()+"1.png", canvas);
// 
// 		}
// 
// 		for (int i =0; i < matchData.size(); i++)
// 		{
// 			cv::Mat canvas(500, 500, CV_8UC3);
// 			canvas.setTo(255);
// 
// 			JC::drawContour(canvas, matchData[i].target.contour, cv::Scalar(0,0,0) , 1, 2);
// 			JC::drawContour(canvas, matchData[i].match_IS_target, cv::Scalar(255,0,255) , 6, 2);
// 
// 			ostringstream oss;
// 			oss << i ;
// 
// 			imwrite("../cost/"+ oss.str()+"2.png", canvas);
// 
// 		}



	};


}
#endif 
