#include "stdafx.h"
#include <fstream>
#include <math.h>
#ifndef MEANSHIFT
#define MEANSHIFT

struct ms_Point{
	cv::Point3d p;
	int label;
};

void print3d(cv::Point3d &p){
	std::cout << p.x << " " << p.y << " " << p.z << std::endl;
}

namespace MeanShift{

	double euclidean3D(cv::Point3d a, cv::Point3d b){
		/* a.z - b.z */
		int thataAB = ((int)(a.z - b.z) + 360) % 360;

		/* b.z - a.z */
		int thetaBA = ((int)(b.z - a.z) + 360) & 360;

		int diffTheta = 0;
		thataAB < thetaBA ? diffTheta = thataAB : diffTheta = thetaBA;

		int length = (int) sqrt( (double)(pow(a.x - b.x, 2) + pow(a.y - b.y, 2 ) + pow((double)diffTheta, 2)));
		return length;
	}

	boolean is_Inner(cv::Point3d a, cv::Point3d b, int Scale, int theta, int& outputDelta)
	{
		int length = (int) sqrt( (double)(pow(a.x - b.x, 2) + pow(a.y - b.y, 2 ) ));
		
		/* a.z - b.z */
		int thataAB = ((int)(a.z - b.z) + 360) % 360;

		/* b.z - a.z */
		int thetaBA = ((int)(b.z - a.z) + 360) & 360;

		int diffTheta = 0;
		thataAB < thetaBA ? diffTheta = thataAB : diffTheta = thetaBA;
		thataAB < thetaBA ? outputDelta = -thataAB: outputDelta = thetaBA;

		if( (length <= Scale) && (diffTheta <= theta) ){
			return true;
		}else
			return false;
	}

	void meanShift(vector<ms_Point> &pointVector, int Scale, int theta, vector<int> &centerLabel, vector<cv::Point3d> &centerVector, std::vector< int > &centerIndex, std::vector< int > &centerDist , int &labelNums){
		
		ostringstream oss;

		int TerminateC = 20;
		for(int i = 0 ; i < pointVector.size() ; i++)
		{
			int comx, comy, comTheta, meanTheta, m;
			cv::Point3d a = pointVector[i].p;
			cv::Point3d ta = a;
			int termination =0;

			while(true)
			{
				comx = 0;
				comy = 0;
				comTheta = 0;
				meanTheta = 0;
				m = 0;
				int newLabel = 0;
				/* find inner points for mean shift */
				for(int j=0 ; j < pointVector.size() ; j++)
				{
					cv::Point3d b = pointVector[j].p;
					int diffTheta;
					if(is_Inner(ta ,b , Scale , theta , diffTheta))
					{
						comx+=b.x;
						comy+=b.y;
						comTheta += diffTheta;
						m++;
					}
				}

				/* mean center */
				if(m > 0){
					comx/=m;
					comy/=m;	
					meanTheta = (int)((comTheta/m) + ta.z)%360 ;
				}

				/* Termination condition */
				if(((comx-ta.x) > 2)||(comy - ta.y) > 2|| (meanTheta-ta.z) > 4 ){
					//print3d(ta);
					ta.x=comx;
					ta.y=comy;
					ta.z=meanTheta;
					//std::cout << "com " << comx << " "<< comy << " " << meanTheta << std::endl;
					
					termination++;
					if(termination > TerminateC){
						centerVector[i] = ta;
						//std::cout <<"final" << termination << std::endl;
						break;
					}
				}else{
					centerVector[i] = ta;
					//std::cout << "final " ;
					//print3d(ta);
					
					break;
				}					
			}//while
		}//for vector points : finding center

		/* cluster centers */
		int labelNum = 0;
		for(int i = 0 ; i < centerVector.size() ; i++)
		{
			cv::Point3d ta = centerVector[i];

			if(centerLabel[i] == -1){
				labelNum++;

				for(int j=0 ; j < centerVector.size() ; j++)
				{
					cv::Point3d b = centerVector[j];

					if(centerLabel[j] == -1){
						int diffTheta;
						if(is_Inner(ta ,b , Scale , theta , diffTheta))
						{
							centerLabel[j] = labelNum;
						}
					}else{
						//std::cout << "i " << i << std::endl;
					}
				}/* for inner test */
			}/* no label */
		}/* cluster center */


		/* find nearest centers */
		for(int i = 0 ; i < pointVector.size() ; i++)
		{
			double dist = 0;
			double minDist = 99999;
			int minIndex = 0;
			for(int j = 0; j < centerVector.size(); j++){

				dist = euclidean3D(pointVector[i].p, centerVector[j]);
				if(dist < minDist){
					minDist = dist;
					minIndex = j;
				} 
			}
			int d;
			if(is_Inner(pointVector[i].p ,centerVector[minIndex] , Scale , theta , d) ){
				centerIndex[i] = minIndex;
				centerDist[i] = minDist;
			}else{
				centerIndex[i] = -1;
				centerDist[i] = -1;
			}
	
		}

		//std::cout << labelNum << std::endl;
		labelNums = labelNum;
	}//meanShift

}//namespace

#endif